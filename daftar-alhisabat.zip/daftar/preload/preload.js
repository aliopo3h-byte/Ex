'use strict';
// واجهة صغيرة ومحددة بين الواجهة والعملية الرئيسية. لا وصول لـ Node من الواجهة.
const { contextBridge, ipcRenderer } = require('electron');

const on = (ch) => (cb) => { const f = (e, data) => cb(data); ipcRenderer.on(ch, f); return () => ipcRenderer.removeListener(ch, f); };

contextBridge.exposeInMainWorld('api', {
  loadDb: () => ipcRenderer.invoke('db:load'),
  saveDb: (json) => ipcRenderer.invoke('db:save', json),
  saveDbSync: (json) => ipcRenderer.sendSync('db:saveSync', json),
  setLocal: (patch) => ipcRenderer.invoke('local:set', patch),

  saveText: (name, text, kind) => ipcRenderer.invoke('file:saveText', { name, text, kind }),
  saveXlsx: (name, sheets) => ipcRenderer.invoke('file:saveXlsx', { name, sheets }),
  saveImage: (name, dataUrl) => ipcRenderer.invoke('file:saveImage', { name, dataUrl }),
  openBackup: () => ipcRenderer.invoke('file:openBackup'),
  openTable: () => ipcRenderer.invoke('file:openTable'),

  chooseBackupDir: () => ipcRenderer.invoke('backup:chooseDir'),
  clearBackupDir: () => ipcRenderer.invoke('backup:clearDir'),
  openBackupDir: () => ipcRenderer.invoke('backup:openDir'),
  openDataDir: () => ipcRenderer.invoke('app:openDataDir'),

  listPrinters: () => ipcRenderer.invoke('print:list'),
  printImage: (opts) => ipcRenderer.invoke('print:image', opts),
  printHtml: (html) => ipcRenderer.invoke('print:html', { html }),
  savePdf: (html, name) => ipcRenderer.invoke('print:pdf', { html, name }),
  printEscpos: (bits, width, height) => ipcRenderer.invoke('print:escpos', { bits, width, height }),

  openWa: (url) => ipcRenderer.invoke('shell:openWa', url),
  copy: (text) => ipcRenderer.invoke('clip:write', text),
  setTheme: (mode) => ipcRenderer.invoke('theme:set', mode),

  btSelect: (id) => ipcRenderer.send('bt:select', id),
  onBtDevices: on('bt:devices'),
  onBackupDone: on('backup:done'),
  onError: on('app:error')
});
