/* بروتوكول طابعات «cat printer» (MX10 وأقاربها) — نفس بايتات تطبيق الهاتف.
   الإطار: 51 78 | أمر | 00 | الطول (2 بايت LE) | الحمولة | CRC-8 (0x07) للحمولة | FF
   صف الصورة: الأمر A2، 48 بايتاً (384 نقطة)، البت 0 = أقصى اليسار، 1 = أسود. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Cat = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var W = 384, BYTES = 48;
  var ENERGY = { light: 0x3000, normal: 0x4800, dark: 0x6000 };
  var LATTICE_START = [0xAA, 0x55, 0x17, 0x38, 0x44, 0x5F, 0x5F, 0x5F, 0x44, 0x38, 0x2C];
  var LATTICE_END = [0xAA, 0x55, 0x17, 0, 0, 0, 0, 0, 0, 0, 0x17];
  var PAUSE = [0x51, 0x78, 0xAE, 0x01, 0x01, 0x00, 0x10, 0x70, 0xFF];
  var RESUME = [0x51, 0x78, 0xAE, 0x01, 0x01, 0x00, 0x00, 0x00, 0xFF];

  function crc8(bytes) {
    var c = 0;
    for (var i = 0; i < bytes.length; i++) { c ^= bytes[i]; for (var k = 0; k < 8; k++) c = (c & 0x80) ? (((c << 1) ^ 0x07) & 0xFF) : ((c << 1) & 0xFF); }
    return c;
  }
  function frame(cmd, payload) {
    var n = payload.length, f = new Uint8Array(n + 8);
    f[0] = 0x51; f[1] = 0x78; f[2] = cmd; f[3] = 0; f[4] = n & 255; f[5] = n >> 8;
    f.set(payload, 6); f[6 + n] = crc8(payload); f[7 + n] = 0xFF;
    return f;
  }
  // من بيانات RGBA (ImageData.data) إلى صفوف 48 بايت
  function rowsFromRgba(data, width, height) {
    if (width !== W) throw new Error('عرض صورة طابعة البلوتوث يجب أن يكون 384 نقطة.');
    var rows = [];
    for (var y = 0; y < height; y++) {
      var r = new Uint8Array(BYTES);
      for (var x = 0; x < width; x++) if (data[(y * width + x) * 4] < 128) r[x >> 3] |= 1 << (x & 7);
      rows.push(r);
    }
    return rows;
  }
  // المهمة كاملة كسلسلة إطارات (تغذية الورق بـ128 صفاً فارغاً)
  function frames(rows, density) {
    var out = [], en = ENERGY[density] || ENERGY.normal, P = function (cmd, p) { out.push(frame(cmd, p)); };
    P(0xA3, [0]); P(0xA3, [0]);
    P(0xA4, [0x32]);
    P(0xBD, [32]);
    P(0xAF, [en & 255, en >> 8]);
    P(0xBE, [1]);
    P(0xA9, [0]);
    P(0xA6, LATTICE_START);
    rows.forEach(function (r) { P(0xA2, r); });
    P(0xA6, LATTICE_END);
    P(0xBD, [8]);
    var blank = new Uint8Array(BYTES); for (var i = 0; i < 128; i++) P(0xA2, blank);
    P(0xA3, [0]);
    return out;
  }
  function concat(parts) {
    var total = 0, off = 0; parts.forEach(function (x) { total += x.length; });
    var out = new Uint8Array(total); parts.forEach(function (x) { out.set(x, off); off += x.length; });
    return out;
  }
  function stream(rows, density) { return concat(frames(rows, density)); }
  function chunks(bytes, size) { var out = []; for (var i = 0; i < bytes.length; i += size) out.push(bytes.subarray(i, i + size)); return out; }
  function same(a, b) { if (a.length !== b.length) return false; for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false; return true; }
  function isPause(v) { return same(v, PAUSE); }
  function isResume(v) { return same(v, RESUME); }
  return { W: W, BYTES: BYTES, ENERGY: ENERGY, LATTICE_START: LATTICE_START, LATTICE_END: LATTICE_END, PAUSE: PAUSE, RESUME: RESUME,
    crc8: crc8, frame: frame, rowsFromRgba: rowsFromRgba, frames: frames, stream: stream, chunks: chunks, isPause: isPause, isResume: isResume };
});
