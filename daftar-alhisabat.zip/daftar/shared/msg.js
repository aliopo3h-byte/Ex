/* يقرأ رسالة الاشتراك الملصوقة (واتساب أو غيره) ويستخرج حقولها لتُطبع في وصل مرتب.
   يفهم صيغتي «استلام مبلغ» و«تفعيل اشتراك»، والقيم الفارغة (......)، والأرقام العربية، والنجوم والإيموجي،
   ويتحمّل الأخطاء الإملائية الشائعة (الموضف/الموظف، تحيه/تحية). */
(function (root) {
  'use strict';

  var FIELDS = ['greet', 'user', 'name', 'sub', 'scratch', 'total', 'amount', 'remain', 'expiry', 'emp', 'status', 'inq', 'collector', 'addr', 'card', 'holder', 'phone', 'date'];

  // [الحقل، نمط الوسم من بداية السطر]. الترتيب مهم: الأخص أولاً.
  var LABELS = [
    ['greet', /^(تحي[ةه] طيب[ةه]|السلام عليكم|مرحب[اً]*)[^:：\d]*/],
    ['inq', /^للاستفسار[^:：\d]*/],
    ['collector', /^(للتواصل مع )?مندوب[^:：\d]*|^للتواصل[^:：\d]*(الجباي[ةه])[^:：\d]*/],
    ['card', /^(رقم\s*)?(ال)?(ماستر\s*كارد|ماستر|master\s*card|كي\s*كارد|زين\s*كاش|رقم\s*الحساب|الحساب)[^:：\d]*/i],
    ['holder', /^(اسم\s*)?(صاحب|المستفيد)[^:：\d]*|^باسم/],
    ['user', /^(ال)?يوزر|^اسم المستخدم/],
    ['name', /^حضرة\s*السيد(ة)?|^السيد(ة)?|^اسم المشترك|^المشترك|^(ال)?اسم(\s*(ال)?كامل)?/],
    ['emp', /^(تم\s*(ال)?(استلام|تفعيل|تسديد)\s*)?بواسطة|^[^:：\d]{0,25}بواسطة|^(ال)?مو[ظض]ف(\s*(ال)?مستلم)?|^اسم\s*(ال)?مستلم|^(ال)?مستلم/],
    ['expiry', /^تاريخ\s*(ال)?(انتهاء|إنتهاء)\s*(ال)?اشتراك|^تاريخ\s*(ال)?(انتهاء|إنتهاء)|^ينتهي/],
    ['total', /^من\s*[اأإ]صل|^مبلغ\s*(ال)?اشتراك|^سعر\s*(ال)?اشتراك|^(ال)?مبلغ\s*(ال)?(كلي|اجمالي|إجمالي)/],
    ['remain', /^و?\s*(ال)?(مبلغ\s*)?(ال)?(متبق[يى]|باق[يى])(?=\s|[:：]|$)/],
    ['amount', /^تم\s*(ال)?استلام\s*(مبلغ)?(\s*(قدره|وقدره|مقداره))?|^استلمنا(\s*مبلغ)?|^(ال)?مبلغ\s*(ال)?(مستلم|واصل|مدفوع)|^(ال)?مبلغ(?=\s|[:：])|^(ال)?واصل|^(ال)?مدفوع|^تم\s*دفع(\s*مبلغ)?/],
    ['sub', /^تم\s*تفعيل\s*(اشتراك)?\s*(ال)?(انترنت|إنترنت)?\s*(فئ[ةه]|باق[ةه])?|^(نوع\s*)?(ال)?(اشتراك|فئ[ةه]|باق[ةه])(\s*(ال)?نوع)?|^(ال)?سرع[ةه]/],
    ['scratch', /^(ال)?بطاق[ةه]/],
    ['phone', /^(رقم\s*)?(ال)?(هاتف|موبايل|جوال|واتساب)/],
    ['addr', /^(ال)?عنوان(\s*(ال)?مكتب)?|^(ال)?مكتب|^(ال)?موقع/],
    ['date', /^(ال)?تاريخ/],
    ['status', /^تم\s*(ال)?(تسديد|تفعيل|تجديد|دفع)/]
  ];
  var IGNORE = [/الشبك[ةه]\s*العراقي/, /^بعد\s*التحويل/, /ارسال\s*ص[وو]ر[ةه]/, /^لتحويل\s*(ال)?مبلغ/, /^هذا\s/, /^شكر/];

  function toEn(s) { return String(s).replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; }).replace(/[۰-۹]/g, function (d) { return d.charCodeAt(0) - 1776; }); }
  function clean(s) {
    return toEn(s).replace(/ـ/g, '').replace(/[​-‏‪-‮⁦-⁩️]/g, '')
      .replace(/[\u{1F000}-\u{1FFFF}☀-➿⬀-⯿]/gu, '').replace(/[*_~•▪◾◽►▶➖]/g, '').replace(/\s+/g, ' ').trim();
  }
  var isSep = function (s) { return /^[\s\-–—_=~.·•*ـ]+$/.test(s); };
  // القيمة المتروكة كنقاط «......» تعني فارغ
  function val(s) { s = String(s || '').replace(/^[\s:：\-–—=>|/]+/, '').replace(/[\s:：\-–—=|]+$/, '').trim(); return /^[.…·_\-–—ـ\s]*$/.test(s) ? '' : s; }
  function labelOf(text) {
    for (var i = 0; i < LABELS.length; i++) { var m = LABELS[i][1].exec(text); if (m && m[0]) return { k: LABELS[i][0], len: m[0].length }; }
    return null;
  }
  function splitAmounts(line) {
    var m = /^(.*?)(\s*[,،]?\s*و?\s*(ال)?(متبق[يى]|باق[يى]).*)$/.exec(line);
    return m && /\d/.test(m[1]) && /(استلام|مبلغ)/.test(m[1]) ? [m[1], m[2].replace(/^[\s,،]+/, '')] : [line];
  }
  function cardDigits(v) { var d = v.replace(/[^\d]/g, ''); return d.length === 16 ? d.replace(/(\d{4})(?=\d)/g, '$1 ').trim() : d.length >= 8 ? d : v; }
  function phoneIn(s) { var m = /0?7\d{9}|\d{10,11}/.exec(s.replace(/[\s-]/g, '')); return m ? m[0] : ''; }

  function parse(text) {
    var out = { kind: 'receipt', notes: [] }, lines = [], i;
    FIELDS.forEach(function (f) { out[f] = ''; });
    String(text || '').split(/\r?\n/).forEach(function (r) {
      var c = clean(r); if (!c || isSep(c)) return;
      lines = lines.concat(splitAmounts(c));
    });
    if (lines.some(function (l) { return /^تم\s*تفعيل\s*اشتراك/.test(l); })) out.kind = 'activate';
    var pending = '', transfer = false;
    for (i = 0; i < lines.length; i++) {
      var ln = lines[i], lab, v;
      if (IGNORE.some(function (re) { return re.test(ln); })) { if (/^(لتحويل|بعد\s*التحويل)/.test(ln)) transfer = true; continue; }
      // رقم هاتف في سطر وحده يتبع «للتواصل مع المندوب…»
      if (pending && /^[\d\s+()-]{8,}$/.test(ln)) { out[pending] = out[pending] || phoneIn(ln) || ln; pending = ''; continue; }
      // نص بعد «لتحويل المبلغ…»: الاسم بحروف لاتينية، والرقم أرقام
      if (transfer || out.card || out.holder) {
        if (/^[A-Za-z][A-Za-z .'-]{3,}$/.test(ln) && !out.holder) { out.holder = ln; continue; }
        if (/^[\d\s-]{8,}$/.test(ln) && !out.card) { out.card = cardDigits(ln); continue; }
      }
      // «الوسم : القيمة» أو «الوسم القيمة»
      var cm = /^([^:：]{2,45}?)\s*[:：]\s*(.*)$/.exec(ln), head = cm ? cm[1] : ln;
      lab = labelOf(head);
      if (!lab) {
        if (/^[A-Za-z][A-Za-z .'-]{3,}$/.test(ln) && !out.holder) { out.holder = ln; continue; }
        if (/^[\d\s-]{12,}$/.test(ln) && !out.card) { out.card = cardDigits(ln); continue; }
        // اسم بلا وسم بعد التحية مباشرة
        if (!out.name && out.greet && !/\d/.test(ln) && ln.split(' ').length <= 5 && !out.sub && !out.amount) { out.name = ln; continue; }
        out.notes.push(ln); continue;
      }
      v = cm ? val(cm[2]) : val(ln.slice(lab.len));
      if (lab.k === 'greet') { out.greet = out.greet || head.replace(/[:：]+$/, ''); continue; }
      if (lab.k === 'status' && /تفعيل\s*اشتراك/.test(ln)) { lab = { k: 'sub' }; v = val(ln.replace(/^تم\s*تفعيل\s*اشتراك\s*(ال)?(انترنت|إنترنت)?\s*(فئ[ةه]|باق[ةه])?/, '')); }
      if (lab.k === 'status') { out.status = out.status ? out.status + ' — ' + ln : ln; continue; }
      // سطر «للتواصل مع المندوب… الرقم» والرقم في السطر التالي
      if ((lab.k === 'inq' || lab.k === 'collector')) {
        var ph = phoneIn(ln.replace(/^[^\d٠-٩]*/, '')) || phoneIn(ln);
        if (ph) out[lab.k] = out[lab.k] || ph; else pending = lab.k;
        continue;
      }
      // الوسم وحده والقيمة في السطر التالي (ما لم يكن وسماً آخر)
      if (!v && i + 1 < lines.length && !labelOf(lines[i + 1]) && !IGNORE.some(function (re) { return re.test(lines[i + 1]); }) && !isSep(lines[i + 1])) v = val(lines[++i]);
      if (lab.k === 'card') v = cardDigits(v);
      if (lab.k === 'card' || lab.k === 'holder') transfer = true;
      if (!v) continue; // وسم فارغ في القالب (......)
      if (!out[lab.k]) out[lab.k] = v; else out.notes.push(ln);
    }
    return out;
  }

  root.Msg = { parse: parse, clean: clean, FIELDS: FIELDS };
  if (typeof module !== 'undefined') module.exports = root.Msg;
})(typeof window !== 'undefined' ? window : globalThis);
