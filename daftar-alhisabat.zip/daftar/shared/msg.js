/* يقرأ رسالة الاشتراك الملصوقة (واتساب أو غيره) ويستخرج حقولها لتُطبع في وصل مرتب.
   يتحمّل الأخطاء الإملائية الشائعة (الموضف/الموظف، تحيه/تحية) والأرقام العربية والإيموجي. */
(function (root) {
  'use strict';

  // ترتيب الفحص مهم: «الموظف المستلم» قبل «المبلغ المستلم»، و«اسم صاحب البطاقة» قبل «الاسم»
  var FIELDS = [
    ['greet', /^(تحي[ةه]|السلام عليكم|مرحب|عزيزي|عزيزتي|اهلا|أهلا)/],
    ['emp', /(ال)?مو[ظض]ف|اسم المستلم|المستلم\s*[:：]?\s*$|^المستلم(?=\s|[:：]|$)/],
    ['holder', /صاحب|باسم|اسم (صاحب )?(ال)?(ماستر|بطاق|حساب)|المستفيد/],
    ['card', /ماستر|master|بطاق[ةه]|كي ?كارد|رقم (ال)?حساب|زين ?كاش|آسيا ?حوال|اسيا ?حوال|محفظ[ةه]|تحويل/i],
    ['remain', /(ال)?متبق[يى]|(ال)?باق[يى](?=\s|[:：]|$)|المتبقى/],
    ['amount', /استلام|استلمنا|المبلغ|مبلغ|واصل|المدفوع|تم دفع/],
    ['sub', /اشتراك|الاشتراك|الباق[ةه]|السرع[ةه]|نوع/],
    ['name', /^(ال)?اسم|اسم المشترك|المشترك\s*[:：]/],
    ['phone', /هاتف|موبايل|جوال|رقم (ال)?تواصل|للتواصل|واتساب|رقم المشترك/],
    ['addr', /عنوان|العنوان|مكتب|المكتب|موقع|الموقع|فرع/],
    ['date', /تاريخ|التاريخ|ينتهي|الانتهاء|تاريخ التفعيل/],
    ['status', /تم (ال)?تسديد|تم (ال)?تفعيل|تفعيل|تجديد|تم التجديد/]
  ];
  // كلمات الوسم التي تُحذف من أول السطر لتبقى القيمة
  var LABELS = [
    /^(تحي[ةه] طيب[ةه]|السلام عليكم)[^:：]*?(عزيزي|عزيزتي)?\s*(ال)?مشترك(ة)?(\s*الكريم(ة)?)?/,
    /^(ال)?مو[ظض]ف\s*(ال)?مستلم|^اسم\s*(ال)?مستلم|^(ال)?مستلم|^(ال)?مو[ظض]ف/,
    /^(اسم\s*)?(صاحب|المستفيد)\s*(ال)?(ماستر\s*كارد|ماستر|بطاق[ةه]|حساب|كي ?كارد)?|^باسم/,
    /^(رقم\s*)?(ال)?(ماستر\s*كارد|ماستر|master\s*card|بطاق[ةه]|كي ?كارد|حساب|زين ?كاش|محفظ[ةه])(\s*(ال)?(ل|لل)?(تحويل|ماستر|كارد))*|^(رقم\s*)?(ال)?تحويل(\s*(على|الى|إلى))?/i,
    /^(و\s*)?(ال)?(متبق[يى]|باق[يى])(\s*(عليك|عليكم|من المبلغ))?/,
    /^(تم\s*)?(استلام|استلمنا)(\s*(ال)?مبلغ)?(\s*(قدره|وقدره|مقداره))?|^(ال)?مبلغ\s*(ال)?(مستلم|واصل|مدفوع)?|^(ال)?واصل|^(ال)?مدفوع|^تم دفع(\s*مبلغ)?/,
    /^(نوع\s*)?(ال)?(اشتراك|باق[ةه])(\s*(ال)?نوع)?|^(ال)?سرع[ةه]/,
    /^(اسم\s*)?(ال)?مشترك|^(ال)?اسم(\s*(ال)?كامل)?/,
    /^(رقم\s*)?(ال)?(هاتف|موبايل|جوال|تواصل|واتساب)|^للتواصل/,
    /^(ال)?عنوان(\s*(ال)?مكتب)?|^(موقع|الموقع)(\s*(ال)?مكتب)?|^(ال)?مكتب/,
    /^(ال)?تاريخ(\s*(ال)?(تفعيل|انتهاء|تسديد))?/
  ];

  function toEn(s) { return String(s).replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; }).replace(/[۰-۹]/g, function (d) { return d.charCodeAt(0) - 1776; }); }
  // ينظّف السطر: إيموجي وزخارف ونجوم واتساب وتطويل
  function clean(s) {
    return toEn(s).replace(/ـ/g, '').replace(/[​-‏‪-‮⁦-⁩️]/g, '')
      .replace(/[\u{1F000}-\u{1FFFF}☀-➿⬀-⯿]/gu, '').replace(/[*_~•▪◾◽►▶➖➡️✅✔☑]/g, '').replace(/\s+/g, ' ').trim();
  }
  function stripLabel(s) {
    var v = s;
    for (var i = 0; i < LABELS.length; i++) { var m = LABELS[i].exec(v); if (m && m[0]) { v = v.slice(m[0].length); break; } }
    return v.replace(/^[\s:：\-–—=>|/.،,]+/, '').replace(/[\s:：\-–—=|.،,]+$/, '').trim();
  }
  function kindOf(line) {
    // «تم تسديد وتفعيل الاشتراك» بلا أرقام: سطر حالة وليس نوع اشتراك
    if (!/\d/.test(line) && /(تم\s*(ال)?(تسديد|تفعيل|تجديد|الدفع))|تفعيل/.test(line) && !/^(ال)?تاريخ/.test(line)) return 'status';
    for (var i = 0; i < FIELDS.length; i++) if (FIELDS[i][1].test(line)) return FIELDS[i][0];
    return '';
  }
  // «تم استلام مبلغ 25000 والمتبقي 10000» في سطر واحد
  function splitAmounts(line) {
    var m = /^(.*?)(\s*[,،]?\s*و?\s*(ال)?(متبق[يى]|باق[يى]).*)$/.exec(line);
    return m && /\d/.test(m[1]) ? [m[1], m[2].replace(/^[\s,،]+/, '')] : [line];
  }
  function cardDigits(v) {
    var d = v.replace(/[^\d]/g, '');
    return d.length >= 8 ? d.replace(/(\d{4})(?=\d)/g, '$1 ') : v;
  }

  function parse(text) {
    var raw = String(text || '').split(/\r?\n/), lines = [], out = { greet: '', name: '', sub: '', amount: '', remain: '', emp: '', status: '', card: '', holder: '', phone: '', addr: '', date: '', notes: [] };
    raw.forEach(function (r) { var c = clean(r); if (!c) return; if (/(استلام|مبلغ)/.test(c) && /(متبق|باق[يى])/.test(c)) lines = lines.concat(splitAmounts(c)); else lines.push(c); });
    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i], k = kindOf(ln), v = k ? stripLabel(ln) : ln;
      if (k === 'greet') { out.greet = ln.replace(/[:：]+$/, ''); var rest = stripLabel(ln); if (rest && rest !== ln && !/^(ال)?مشترك/.test(rest) && rest.length < 40) out.name = out.name || rest; continue; }
      if (k === 'status') { out.status = out.status ? out.status + ' — ' + ln : ln; continue; }
      // الوسم وحده في سطر والقيمة في السطر التالي
      if (k && !v && i + 1 < lines.length && !kindOf(lines[i + 1])) v = lines[++i];
      if (k === 'card') v = cardDigits(v);
      if (k && v && !out[k]) { out[k] = v; continue; }
      if (k && v && out[k]) { out.notes.push(ln); continue; }
      if (!k) {
        // سطر بلا وسم بعد التحية مباشرة يكون غالباً الاسم
        if (!out.name && out.greet && !/\d/.test(ln) && ln.split(' ').length <= 5 && !out.sub && !out.amount) { out.name = ln; continue; }
        // رقم طويل وحده = رقم بطاقة إن ذُكرت البطاقة قبله
        if (/^[\d\s-]{12,}$/.test(ln) && !out.card) { out.card = cardDigits(ln); continue; }
        out.notes.push(ln);
      }
    }
    return out;
  }

  root.Msg = { parse: parse, clean: clean };
  if (typeof module !== 'undefined') module.exports = root.Msg;
})(typeof window !== 'undefined' ? window : globalThis);
