/* دفتر الحسابات — منطق الحساب المشترك.
   ملف واحد بلا DOM ولا Node: تحمّله الواجهة كسكربت عادي (window.Core)، وتحمّله الاختبارات بـ require.
   القواعد منقولة حرفياً من تطبيق الهاتف المرجعي حتى تبقى النسخ الاحتياطية متوافقة بالاتجاهين. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Core = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ---------- الساعة (قابلة للمحاكاة في الاختبارات) ---------- */
  var nowFn = function () { return new Date(); };
  function setNow(fn) { nowFn = fn || function () { return new Date(); }; }
  function now() { return nowFn(); }

  /* ---------- أرقام وتواريخ ---------- */
  var AD = '٠١٢٣٤٥٦٧٨٩', PD = '۰۱۲۳۴۵۶۷۸۹';
  function toEn(s) {
    return String(s == null ? '' : s)
      .replace(/[٠-٩]/g, function (d) { return AD.indexOf(d); })
      .replace(/[۰-۹]/g, function (d) { return PD.indexOf(d); });
  }
  function r2(n) { return Math.round(n * 100) / 100; }
  // يقبل 1,250.5 و ١٬٢٥٠٫٥ و 1250 ؛ يعيد 0 لكل ما ليس مبلغاً موجباً
  function parseAmt(v) {
    var t = toEn(v).replace(/[٬,\s]/g, '').replace(/٫/g, '.'), n = parseFloat(t);
    return isFinite(n) && n > 0 && /^[0-9.]+$/.test(t) ? r2(n) : 0;
  }
  function money(n) { return Number(n).toLocaleString('en-US', { maximumFractionDigits: 2 }); }
  function pad(n) { return String(n).padStart(2, '0'); }
  function iso(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function today() { return iso(now()); }
  function parseIso(s) { var p = String(s).split('-'); return new Date(+p[0], +p[1] - 1, +p[2]); }
  function addDays(s, n) { var d = parseIso(s); d.setDate(d.getDate() + n); return iso(d); }
  // رقم اليوم بلا إنشاء كائنات Date محلية (أسرع بكثير في الحلقات)
  function dayNum(s) { return Date.UTC(+s.slice(0, 4), +s.slice(5, 7) - 1, +s.slice(8, 10)) / 86400000; }
  function dayDiff(a, b) { return dayNum(a) - dayNum(b); }
  function ymOf(s) { return String(s).slice(0, 7); }
  function nextYm(m) { var p = m.split('-'), y = +p[0], mo = +p[1] + 1; if (mo > 12) { mo = 1; y++; } return y + '-' + pad(mo); }
  function prevYm(m) { var p = m.split('-'), y = +p[0], mo = +p[1] - 1; if (mo < 1) { mo = 12; y--; } return y + '-' + pad(mo); }
  // يضيف n شهراً مع تثبيت اليوم، ويضبطه لآخر الشهر عند الحاجة (31 يناير ← 28 فبراير)
  function addMonthIso(s, n, day) {
    var p = s.split('-'), y = +p[0], m = +p[1] - 1 + n;
    y += Math.floor(m / 12); m = ((m % 12) + 12) % 12;
    var dim = new Date(y, m + 1, 0).getDate();
    return y + '-' + pad(m + 1) + '-' + pad(Math.min(day || +p[2], dim));
  }
  function hm(ts) { var d = new Date(ts); return pad(d.getHours()) + ':' + pad(d.getMinutes()); }
  function isIsoDate(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')) && iso(parseIso(s)) === s; }

  /* ---------- نص عربي ---------- */
  // يتجاهل التشكيل والتطويل ويوحّد الهمزات والياء والتاء المربوطة
  function norm(s) {
    return toEn(s).toLowerCase().replace(/[\u064B-\u0652\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
      .replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/\s+/g, ' ').trim();
  }
  function digits(s) { return toEn(s).replace(/\D/g, ''); }
  // مفتاح منع التكرار: آخر 9 أرقام (يتجاهل الصفر ورمز الدولة)
  function hKey(num) { var d = digits(num); return d.length >= 7 ? d.slice(-9) : d; }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  }

  /* ---------- قاعدة البيانات ---------- */
  var DEF_TPL = 'السلام عليكم {الاسم}، نذكّركم بأن المتبقي عليكم {المبلغ} {العملة} وكان موعده {التاريخ}. نشكر لكم حسن تعاونكم. {المحل}';
  function blank() {
    return { v: 1, seq: { rec: 0, id: 0 }, customers: {}, charges: [], pays: [], subs: [],
      cfg: { shop: '', shopph: '', curr: '', foot: 'شكراً لتعاملكم معنا', pw: 384, cc: '', tpl: DEF_TPL, theme: 'auto', pre: '', dens: 'normal', printer: null },
      meta: { saved: 0, lastBackup: 0 } };
  }
  function fixDb(d) {
    var b = blank();
    d = d && typeof d === 'object' ? d : {};
    return { v: 1, seq: Object.assign(b.seq, d.seq || {}),
      customers: d.customers && typeof d.customers === 'object' && !Array.isArray(d.customers) ? d.customers : {},
      charges: Array.isArray(d.charges) ? d.charges : [], pays: Array.isArray(d.pays) ? d.pays : [], subs: Array.isArray(d.subs) ? d.subs : [],
      cfg: Object.assign(b.cfg, d.cfg || {}), meta: Object.assign(b.meta, d.meta || {}) };
  }
  function makeBackup(db) { return { app: 'ledger', v: 1, at: now().toISOString(), db: db }; }
  function validateBackup(o) {
    if (!o || typeof o !== 'object' || o.app !== 'ledger') return { ok: false, err: 'هذا الملف ليس نسخة احتياطية من دفتر الحسابات.' };
    if (!o.db || typeof o.db !== 'object' || !o.db.customers || typeof o.db.customers !== 'object' || Array.isArray(o.db.customers))
      return { ok: false, err: 'النسخة الاحتياطية تالفة: لا تحتوي قائمة العملاء.' };
    return { ok: true, n: Object.keys(o.db.customers).length };
  }
  function parseBackupText(text) {
    var o = null;
    try { o = JSON.parse(String(text).replace(/^\uFEFF/, '')); } catch (e) { return { ok: false, err: 'الملف تالف أو ليس بصيغة JSON.' }; }
    var v = validateBackup(o); v.obj = o; return v;
  }

  /* ---------- الهاتف وواتساب ---------- */
  function intl(phone, cc) {
    var t = toEn(phone).trim(), d = t.replace(/\D/g, ''); cc = String(cc || '').replace(/\D/g, '');
    if (!d) return '';
    if (t.charAt(0) === '+') return d;
    if (d.indexOf('00') === 0) return d.slice(2);
    if (cc && d.charAt(0) === '0') return cc + d.slice(1);
    if (cc && d.indexOf(cc) !== 0 && d.length <= 10) return cc + d;
    return d;
  }
  function waLink(phone, text, cc) { var n = intl(phone, cc); return n ? 'https://wa.me/' + n + '?text=' + encodeURIComponent(text || '') : ''; }
  function fill(tpl, vars) { return String(tpl).replace(/\{([^}]+)\}/g, function (m, k) { return vars[k] != null ? vars[k] : m; }); }
  function methodName(m) { return m === 'transfer' ? 'تحويل' : m === 'other' ? 'أخرى' : 'نقداً'; }

  /* ---------- CSV ---------- */
  function parseCsv(t) {
    t = String(t).replace(/^\uFEFF/, '');
    var first = t.split(/\r?\n/)[0] || '', d = ',', cnt = function (re) { return (first.match(re) || []).length; };
    if (cnt(/;/g) > cnt(/,/g)) d = ';';
    if (first.indexOf('\t') >= 0 && cnt(/\t/g) >= cnt(/,/g) && cnt(/\t/g) >= cnt(/;/g)) d = '\t';
    var rows = [], row = [], cur = '', q = false;
    for (var i = 0; i < t.length; i++) {
      var ch = t[i];
      if (q) { if (ch === '"') { if (t[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; }
      else if (ch === '"') q = true;
      else if (ch === d) { row.push(cur); cur = ''; }
      else if (ch === '\n' || ch === '\r') { if (ch === '\r' && t[i + 1] === '\n') i++; row.push(cur); cur = ''; rows.push(row); row = []; }
      else cur += ch;
    }
    if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
    return rows.filter(function (r) { return r.some(function (c) { return String(c).trim() !== ''; }); });
  }
  function csvString(rows) {
    return '\uFEFF' + rows.map(function (r) {
      return r.map(function (c) { c = String(c == null ? '' : c); return /[",\n;\r]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(',');
    }).join('\r\n');
  }
  // يقترح الأعمدة من العناوين
  function detectColumns(head) {
    var find = function (re, def) { for (var i = 0; i < head.length; i++) if (re.test(String(head[i]))) return i; return def; };
    var iName = find(/اسم|name|عميل|مشترك/i, 0), iPhone = find(/هاتف|جوال|موبايل|تلفون|رقم|phone|mobile|tel/i, 1), iBal = find(/رصيد|مبلغ|دين|متبقي|balance|amount|due/i, -1);
    if (iPhone === iName) iPhone = iName === 0 ? 1 : 0;
    if (iPhone >= head.length) iPhone = -1;
    return { name: iName, phone: iPhone, bal: iBal };
  }
  function cleanRows(aoa) {
    return (aoa || []).map(function (r) { return (r || []).map(function (c) { return String(c == null ? '' : c).trim(); }); })
      .filter(function (r) { return r.some(Boolean); });
  }

  /* ---------- الدفتر ---------- */
  function Ledger(db) { this.db = fixDb(db); this.idx = null; this.cache = {}; this.ver = 0; this.onChange = null; }
  var L = Ledger.prototype;
  L.nid = function () { return ++this.db.seq.id; };
  L.invalidate = function () { this.idx = null; this.cache = {}; this.ver++; this.td = null; this.tdn = null; };
  L.dirty = function () { this.invalidate(); if (this.onChange) this.onChange(); };
  // تعديل يخص عميلاً واحداً: نعيد بناء فهرسه وحسابه فقط بدل الكل
  L.touch = function (cid) {
    if (!this.idx) { this.invalidate(); return; }
    var ix = this.idx;
    ix.ch[cid] = this.db.charges.filter(function (c) { return c.cid === cid && !c.void; });
    ix.allPy[cid] = this.db.pays.filter(function (p) { return p.cid === cid; });
    ix.py[cid] = ix.allPy[cid].filter(function (p) { return !p.void; });
    delete this.cache[cid]; this.ver++;
  };
  L.dirtyCid = function (cid) { this.touch(cid); if (this.onChange) this.onChange(); };
  L.replace = function (db) { this.db = fixDb(db); this.dirty(); };
  L.ensure = function () {
    if (this.idx) return this.idx;
    var ix = { ch: {}, py: {}, allPy: {} };
    this.db.charges.forEach(function (c) { if (!c.void) (ix.ch[c.cid] = ix.ch[c.cid] || []).push(c); });
    this.db.pays.forEach(function (p) { (ix.allPy[p.cid] = ix.allPy[p.cid] || []).push(p); if (!p.void) (ix.py[p.cid] = ix.py[p.cid] || []).push(p); });
    this.idx = ix; return ix;
  };
  // التسديدات تُوزَّع على المستحقات الأقدم استحقاقاً أولاً؛ كل ما عدا ذلك مشتق منها
  L.acct = function (cid) {
    var c = this.cache[cid]; if (c) return c;
    var ix = this.ensure(), ch = (ix.ch[cid] || []).slice(), py = ix.py[cid] || [], td = this.td || (this.td = today()), tdn = this.tdn || (this.tdn = dayNum(td));
    ch.sort(function (a, b) { return a.due < b.due ? -1 : a.due > b.due ? 1 : a.id - b.id; });
    var paid = 0, total = 0, last = 0;
    py.forEach(function (p) { paid += p.amt; if (p.ts > last) last = p.ts; });
    paid = r2(paid);
    var rem = paid, items = [], overdue = 0, maxLate = 0, next = null, nextLeft = 0, oldestLate = null;
    ch.forEach(function (x) {
      total += x.amt;
      var got = r2(Math.min(x.amt, Math.max(0, rem))); rem = r2(rem - got);
      var left = r2(x.amt - got), late = left > 0.004 && x.due < td;
      if (late) { overdue += left; if (!oldestLate) { oldestLate = x.due; maxLate = tdn - dayNum(x.due); } }
      if (left > 0.004 && !next) { next = x; nextLeft = left; }
      items.push({ c: x, paid: got, left: left, late: late, status: left <= 0.004 ? 'paid' : (got > 0 ? 'part' : (late ? 'late' : 'open')) });
    });
    total = r2(total);
    c = { items: items, total: total, paid: paid, bal: r2(total - paid), overdue: r2(overdue), maxLate: maxLate, next: next, nextLeft: nextLeft, lastPay: last, oldestLate: oldestLate };
    this.cache[cid] = c; return c;
  };
  L.activeCustomers = function () {
    var cs = this.db.customers; return Object.keys(cs).map(function (k) { return cs[k]; }).filter(function (c) { return !c.arch; });
  };
  L.totals = function () {
    var self = this, t = { out: 0, overdue: 0, lateN: 0, owingN: 0, today: 0, month: 0, todayN: 0 }, td = today(), mo = ymOf(td);
    this.activeCustomers().forEach(function (c) {
      var a = self.acct(c.id);
      if (a.bal > 0.004) { t.out += a.bal; t.owingN++; }
      if (a.overdue > 0.004) { t.overdue += a.overdue; t.lateN++; }
    });
    this.db.pays.forEach(function (p) { if (p.void) return; if (p.d === td) { t.today += p.amt; t.todayN++; } if (ymOf(p.d) === mo) t.month += p.amt; });
    t.out = r2(t.out); t.overdue = r2(t.overdue); t.today = r2(t.today); t.month = r2(t.month);
    return t;
  };
  L.recNo = function (p) { return (this.db.cfg.pre || '') + String(p.no).padStart(5, '0'); };
  L.curTxt = function () { return this.db.cfg.curr ? ' ' + this.db.cfg.curr : ''; };

  // العملاء
  L.findDup = function (phone, exceptId) {
    var k = hKey(phone); if (!k) return null;
    return this.activeCustomers().filter(function (x) { return x.id !== exceptId && hKey(x.phone) === k; })[0] || null;
  };
  L.addCustomer = function (name, phone, note, quiet) {
    var c = { id: this.nid(), name: String(name).trim(), phone: String(phone || '').trim(), note: String(note || '').trim(), created: now().getTime() };
    this.db.customers[c.id] = c; if (!quiet) this.dirty(); return c;
  };
  L.updateCustomer = function (c, name, phone, note) { c.name = String(name).trim(); c.phone = String(phone || '').trim(); c.note = String(note || '').trim(); this.dirty(); };
  L.archive = function (c) { c.arch = 1; this.dirty(); };
  L.matches = function (c, q) {
    var s = norm(q); if (!s) return true;
    if (norm(c.name).indexOf(s) >= 0) return true;
    var qd = s.replace(/\D/g, ''); if (!qd || qd.length !== s.replace(/[\s+\-()]/g, '').length) return false;
    var pd = digits(c.phone);
    return pd.indexOf(qd) >= 0 || (qd.charAt(0) === '0' && qd.length > 1 && pd.indexOf(qd.slice(1)) >= 0);
  };
  L.customerList = function (q, f, sortBy) {
    var self = this, all = this.activeCustomers().map(function (c) { return { c: c, a: self.acct(c.id) }; });
    var cnt = { all: all.length, late: 0, owing: 0, clear: 0 };
    all.forEach(function (x) { if (x.a.overdue > 0.004) cnt.late++; if (x.a.bal > 0.004) cnt.owing++; else cnt.clear++; });
    var list = all.filter(function (x) {
      if (f === 'late' && !(x.a.overdue > 0.004)) return false;
      if (f === 'owing' && !(x.a.bal > 0.004)) return false;
      if (f === 'clear' && x.a.bal > 0.004) return false;
      return self.matches(x.c, q);
    });
    if (sortBy === 'bal') list.sort(function (a, b) { return b.a.bal - a.a.bal || a.c.id - b.c.id; });
    else if (sortBy === 'due') list.sort(function (a, b) { var x = a.a.next ? a.a.next.due : '9999', y = b.a.next ? b.a.next.due : '9999'; return x < y ? -1 : x > y ? 1 : a.c.id - b.c.id; });
    else { var coll = typeof Intl !== 'undefined' ? new Intl.Collator('ar') : null; list.sort(function (a, b) { return coll ? coll.compare(a.c.name, b.c.name) : (a.c.name < b.c.name ? -1 : 1); }); }
    return { list: list, cnt: cnt };
  };

  // المستحقات
  L.addCharge = function (cid, amt, due, desc, extra, quiet) {
    var c = Object.assign({ id: this.nid(), cid: cid, amt: r2(amt), date: today(), due: due || today(), desc: desc || '', kind: 'debt' }, extra || {});
    this.db.charges.push(c); if (!quiet) this.dirtyCid(cid); return c;
  };
  // كل قسط = الإجمالي ÷ العدد مقرّباً للأسفل، والأخير يأخذ الباقي
  L.splitInstallments = function (total, n) {
    var each = Math.floor(r2(total) / n * 100) / 100, out = [];
    for (var i = 0; i < n; i++) out.push(i === n - 1 ? r2(total - r2(each * (n - 1))) : each);
    return out;
  };
  L.addInstallments = function (cid, total, n, firstDue, desc) {
    var amts = this.splitInstallments(total, n), plan = this.nid(), day = +firstDue.slice(8), base = desc || 'قسط', out = [];
    for (var i = 0; i < n; i++) {
      var c = { id: this.nid(), cid: cid, amt: amts[i], date: today(), due: addMonthIso(firstDue, i, day), desc: base + ' ' + (i + 1) + '/' + n, kind: 'inst', plan: plan };
      this.db.charges.push(c); out.push(c);
    }
    this.dirtyCid(cid); return out;
  };
  L.editCharge = function (c, amt, due, desc) { c.amt = r2(amt); if (isIsoDate(due)) c.due = due; c.desc = String(desc || '').trim(); this.dirtyCid(c.cid); };
  L.voidCharge = function (c) { c.void = 1; this.dirtyCid(c.cid); };

  // الاشتراكات: مستحق تلقائي مع بداية كل شهر
  L.addSub = function (cid, amt, day, startYm, desc) {
    var s = { id: this.nid(), cid: cid, amt: r2(amt), day: day, start: startYm, last: null, active: 1, desc: desc || '' };
    this.db.subs.push(s); this.genSubs(true); this.dirty(); return s;
  };
  L.genSubs = function (quiet) {
    var self = this, cm = ymOf(today()), n = 0;
    this.db.subs.forEach(function (s) {
      if (!s.active || !self.db.customers[s.cid]) return;
      var m = s.last ? nextYm(s.last) : s.start;
      while (m <= cm) {
        self.db.charges.push({ id: self.nid(), cid: s.cid, amt: s.amt, date: m + '-01', due: addMonthIso(m + '-01', 0, s.day), desc: s.desc || 'اشتراك شهري', kind: 'sub', sub: s.id });
        s.last = m; m = nextYm(m); n++;
      }
    });
    if (n && !quiet) this.dirty(); else if (n) this.invalidate();
    return n;
  };
  // الاستئناف لا يعوّض الأشهر الفائتة: يولّد الشهر الحالي فقط
  L.toggleSub = function (s) {
    s.active = s.active ? 0 : 1;
    if (s.active) { var pv = prevYm(ymOf(today())); if (!s.last || s.last < pv) s.last = pv; this.genSubs(true); }
    this.dirty();
  };
  L.deleteSub = function (s) { this.db.subs = this.db.subs.filter(function (x) { return x !== s; }); this.dirty(); };

  // التسديدات
  L.addPayment = function (cid, amt, method, note, dateIso) {
    var td = today(), d = dateIso || td;
    if (!isIsoDate(d)) throw new Error('تاريخ غير صالح.');
    if (d > td) throw new Error('لا يمكن اختيار تاريخ مستقبلي.');
    var ts = d === td ? now().getTime() : parseIso(d).getTime() + 12 * 3600000;
    var p = { id: this.nid(), no: ++this.db.seq.rec, cid: cid, amt: r2(amt), ts: ts, d: d, m: method || 'cash', t: String(note || '').trim() };
    this.db.pays.push(p); this.touch(cid);
    p.after = this.acct(cid).bal;          // الرصيد بعد التسديد، يُحفظ للوصل
    this.dirtyCid(cid); return p;
  };
  L.setPayVoid = function (p, v) { p.void = v ? 1 : 0; this.dirtyCid(p.cid); };
  L.paysOf = function (cid) { return (this.ensure().allPy[cid] || []).slice().sort(function (x, y) { return y.ts - x.ts; }); };
  L.movements = function (cid) {
    var self = this, ix = this.ensure(), rows = [];
    (ix.ch[cid] || []).forEach(function (c) { rows.push({ d: c.date, t: c.desc || 'مستحق', a: c.amt, id: c.id }); });
    (ix.py[cid] || []).forEach(function (p) { rows.push({ d: p.d, t: 'تسديد #' + self.recNo(p), a: -p.amt, id: p.id }); });
    rows.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : a.id - b.id; });
    return rows;
  };
  L.suggestions = function (cid) {
    var a = this.acct(cid), out = [];
    if (a.bal > 0.004) out.push({ k: 'all', label: 'كامل المتبقي', v: a.bal });
    if (a.overdue > 0.004 && Math.abs(a.overdue - a.bal) > 0.004) out.push({ k: 'late', label: 'المتأخر', v: a.overdue });
    if (a.nextLeft > 0.004 && Math.abs(a.nextLeft - a.bal) > 0.004 && Math.abs(a.nextLeft - a.overdue) > 0.004) out.push({ k: 'next', label: 'القسط القادم', v: a.nextLeft });
    return out;
  };
  L.defaultPay = function (cid) { var a = this.acct(cid); return a.overdue > 0.004 ? a.overdue : (a.bal > 0.004 ? a.bal : 0); };

  // واتساب والنصوص
  L.reminderText = function (c) {
    var a = this.acct(c.id), cfg = this.db.cfg, amt = a.overdue > 0.004 ? a.overdue : Math.max(a.bal, 0);
    var date = a.oldestLate || (a.next && a.next.due) || today();
    return fill(cfg.tpl || DEF_TPL, { 'الاسم': c.name, 'المبلغ': money(amt), 'العملة': cfg.curr || '', 'التاريخ': date, 'المحل': cfg.shop || '' })
      .replace(/\s+\./g, '.').replace(/ {2,}/g, ' ').trim();
  };
  L.waLink = function (phone, text) { return waLink(phone, text, this.db.cfg.cc); };
  L.afterText = function (after) {
    var cur = this.curTxt();
    return after > 0.004 ? 'المتبقي عليكم: ' + money(after) + cur : (after < -0.004 ? 'رصيد لكم: ' + money(-after) + cur : 'الحساب مسدّد بالكامل');
  };
  L.receiptText = function (p) {
    var c = this.db.customers[p.cid] || { name: '—' }, cur = this.curTxt();
    var out = [this.db.cfg.shop || '', 'سند قبض رقم ' + this.recNo(p), 'التاريخ: ' + p.d + ' ' + hm(p.ts), 'استلمنا من: ' + c.name, 'المبلغ: ' + money(p.amt) + cur, 'طريقة الدفع: ' + methodName(p.m)];
    if (p.t) out.push('ملاحظة: ' + p.t);
    if (p.after != null) out.push(this.afterText(p.after));
    if (this.db.cfg.foot) out.push(this.db.cfg.foot);
    return out.filter(function (x) { return x !== ''; }).join('\n');
  };
  L.statementText = function (c) {
    var a = this.acct(c.id), cur = this.curTxt(), out = ['كشف حساب — ' + c.name, 'بتاريخ: ' + today(), 'إجمالي المستحقات: ' + money(a.total) + cur, 'إجمالي المسدَّد: ' + money(a.paid) + cur,
      (a.bal >= 0 ? 'المتبقي: ' : 'رصيد لكم: ') + money(Math.abs(a.bal)) + cur];
    if (a.overdue > 0.004) out.push('منه متأخر: ' + money(a.overdue) + cur);
    var mv = this.movements(c.id).slice(-22);
    if (mv.length) { out.push('', 'آخر الحركات:'); mv.forEach(function (m) { out.push(m.d + ' | ' + m.t + ' | ' + (m.a < 0 ? '-' : '+') + money(Math.abs(m.a))); }); }
    if (this.db.cfg.shop) out.push('', this.db.cfg.shop);
    return out.join('\n');
  };

  // التقارير
  function rangeOf(v) {
    var td = today(), mo = ymOf(td);
    if (v === 'today') return [td, td];
    if (v === 'yday') { var y = addDays(td, -1); return [y, y]; }
    if (v === 'w7') return [addDays(td, -6), td];
    if (v === 'month') return [mo + '-01', mo + '-31'];
    if (v === 'lmonth') { var pm = prevYm(mo); return [pm + '-01', pm + '-31']; }
    return ['0000-00-00', '9999-99-99'];
  }
  L.aging = function () {
    var self = this, ag = [0, 0, 0, 0], n = [0, 0, 0, 0], td = today();
    this.activeCustomers().forEach(function (c) {
      self.acct(c.id).items.forEach(function (it) { if (!it.late) return; var d = dayDiff(td, it.c.due), k = d <= 30 ? 0 : d <= 60 ? 1 : d <= 90 ? 2 : 3; ag[k] += it.left; n[k]++; });
    });
    return { amt: ag.map(r2), n: n };
  };
  L.report = function (range) {
    var r = rangeOf(range), pays = this.db.pays.filter(function (p) { return !p.void && p.d >= r[0] && p.d <= r[1]; }).sort(function (a, b) { return b.ts - a.ts; });
    var charges = this.db.charges.filter(function (c) { return !c.void && c.date >= r[0] && c.date <= r[1]; });
    var sum = 0, byM = { cash: 0, transfer: 0, other: 0 }, byD = {}, issued = 0;
    pays.forEach(function (p) { sum += p.amt; byM[p.m] = (byM[p.m] || 0) + p.amt; byD[p.d] = (byD[p.d] || 0) + p.amt; });
    charges.forEach(function (c) { issued += c.amt; });
    Object.keys(byM).forEach(function (k) { byM[k] = r2(byM[k]); });
    Object.keys(byD).forEach(function (k) { byD[k] = r2(byD[k]); });
    return { range: r, pays: pays, charges: charges, sum: r2(sum), issued: r2(issued), byM: byM, byD: byD };
  };
  L.receipts = function (range, q) {
    var self = this, r = rangeOf(range), s = norm(q), qd = s.replace(/\D/g, '');
    return this.db.pays.filter(function (p) {
      if (p.d < r[0] || p.d > r[1]) return false;
      if (!s) return true;
      var c = self.db.customers[p.cid] || { name: '', phone: '' };
      return norm(c.name).indexOf(s) >= 0 || norm(self.recNo(p)).indexOf(s) >= 0 || (qd && qd.length === s.replace(/\s/g, '').length && digits(c.phone).indexOf(qd) >= 0);
    }).sort(function (a, b) { return b.ts - a.ts || b.no - a.no; });
  };
  L.receiptRows = function (pays) {
    var self = this, rows = [['رقم السند', 'التاريخ', 'الوقت', 'العميل', 'الهاتف', 'المبلغ', 'طريقة الدفع', 'ملاحظة', 'الحالة']];
    pays.slice().sort(function (a, b) { return a.ts - b.ts; }).forEach(function (p) {
      var c = self.db.customers[p.cid] || {};
      rows.push([self.recNo(p), p.d, hm(p.ts), c.name || '', c.phone || '', p.amt, methodName(p.m), p.t || '', p.void ? 'ملغى' : 'ساري']);
    });
    return rows;
  };
  L.balanceRows = function () {
    var self = this, rows = [['الاسم', 'الهاتف', 'إجمالي المستحقات', 'المسدَّد', 'المتبقي', 'المتأخر', 'أيام التأخر', 'الاستحقاق القادم']];
    var coll = typeof Intl !== 'undefined' ? new Intl.Collator('ar') : null;
    this.activeCustomers().sort(function (a, b) { return coll ? coll.compare(a.name, b.name) : 0; }).forEach(function (c) {
      var a = self.acct(c.id); rows.push([c.name, c.phone, a.total, a.paid, a.bal, a.overdue, a.maxLate || '', a.next ? a.next.due : '']);
    });
    return rows;
  };

  // الاستيراد
  L.planImport = function (rows, cols) {
    var seen = {}, ok = 0, dup = 0, bad = 0, out = [], cs = this.db.customers;
    Object.keys(cs).forEach(function (k) { if (cs[k].arch) return; var kk = hKey(cs[k].phone); if (kk) seen[kk] = 1; });
    rows.slice(1).forEach(function (r) {
      var name = String(r[cols.name] || '').trim(), ph = cols.phone >= 0 ? toEn(String(r[cols.phone] || '').trim()) : '', k = hKey(ph);
      if (!name) { bad++; return; }
      if (k && seen[k]) { dup++; return; }
      if (k) seen[k] = 1;
      ok++; out.push({ name: name, phone: ph, bal: cols.bal >= 0 ? parseAmt(r[cols.bal]) : 0 });
    });
    return { list: out, ok: ok, dup: dup, bad: bad };
  };
  L.applyImport = function (list) {
    var self = this;
    list.forEach(function (x) { var c = self.addCustomer(x.name, x.phone, '', true); if (x.bal > 0) self.addCharge(c.id, x.bal, today(), 'رصيد سابق', { kind: 'debt' }, true); });
    this.dirty(); return list.length;
  };

  return {
    setNow: setNow, now: now, today: today, toEn: toEn, r2: r2, parseAmt: parseAmt, money: money, pad: pad, iso: iso, parseIso: parseIso, addDays: addDays,
    dayDiff: dayDiff, ymOf: ymOf, nextYm: nextYm, prevYm: prevYm, addMonthIso: addMonthIso, hm: hm, isIsoDate: isIsoDate, norm: norm, digits: digits, hKey: hKey, esc: esc,
    DEF_TPL: DEF_TPL, blank: blank, fixDb: fixDb, makeBackup: makeBackup, validateBackup: validateBackup, parseBackupText: parseBackupText,
    intl: intl, waLink: waLink, fill: fill, methodName: methodName, parseCsv: parseCsv, csvString: csvString, detectColumns: detectColumns, cleanRows: cleanRows,
    rangeOf: rangeOf, Ledger: Ledger
  };
});
