// ينزّل خط Noto Sans Arabic (رخصة OFL) ليُضمَّن في الحزمة. يعمل وقت البناء فقط؛ التطبيق نفسه لا يتصل بالإنترنت.
// بدون الخط يستعمل التطبيق Segoe UI المثبّت في كل Windows 10/11 (يدعم العربية جيداً).
const https = require('https');
const fs = require('fs');
const path = require('path');
const optional = process.argv.includes('--optional');
const dest = path.join(__dirname, '..', 'renderer', 'fonts', 'NotoSansArabic.ttf');
const CSS = path.join(path.dirname(dest), 'fonts.css');
const FACE = '@font-face { font-family: "Noto Sans Arabic"; src: url("NotoSansArabic.ttf") format("truetype"); font-weight: 100 900; font-display: swap; }\n';
const URL = 'https://raw.githubusercontent.com/notofonts/notofonts.github.io/main/fonts/NotoSansArabic/full/variable-ttf/NotoSansArabic%5Bwdth%2Cwght%5D.ttf';
if (fs.existsSync(dest) && fs.statSync(dest).size > 100000) { fs.writeFileSync(CSS, FACE); console.log('الخط موجود:', dest); process.exit(0); }
function get(url, n) {
  return new Promise((res, rej) => https.get(url, { timeout: 20000 }, (r) => {
    if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location && n < 5) return res(get(r.headers.location, n + 1));
    if (r.statusCode !== 200) return rej(new Error('HTTP ' + r.statusCode));
    const chunks = []; r.on('data', (c) => chunks.push(c)); r.on('end', () => res(Buffer.concat(chunks)));
  }).on('error', rej).on('timeout', function () { this.destroy(new Error('timeout')); }));
}
get(URL, 0).then((buf) => {
  if (buf.length < 100000 || buf.readUInt32BE(0) !== 0x00010000) throw new Error('ملف غير متوقع');
  fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.writeFileSync(dest, buf); fs.writeFileSync(CSS, FACE);
  console.log('نُزّل الخط (' + Math.round(buf.length / 1024) + ' ك.ب)');
}).catch((e) => {
  console.warn('تعذّر تنزيل الخط: ' + e.message + (optional ? ' — سيُستعمل Segoe UI.' : ''));
  process.exit(optional ? 0 : 1);
});
