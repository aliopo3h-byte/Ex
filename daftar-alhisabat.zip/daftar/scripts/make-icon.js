// يولّد build/icon.png و build/icon.ico من رسم SVG (يحتاج sharp فقط عند إعادة التوليد: npx -p sharp node scripts/make-icon.js)
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024">
<defs>
 <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#14857B"/><stop offset="1" stop-color="#0A4844"/></linearGradient>
 <linearGradient id="coin" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FCD34D"/><stop offset="1" stop-color="#D97706"/></linearGradient>
</defs>
<rect x="40" y="40" width="944" height="944" rx="220" fill="url(#bg)"/>
<path d="M512 300 C430 250 300 238 210 262 V742 C300 718 430 730 512 780 Z" fill="#E6F4F1"/>
<path d="M512 300 C594 250 724 238 814 262 V742 C724 718 594 730 512 780 Z" fill="#FFFFFF"/>
<path d="M512 300 V780" stroke="#0A4844" stroke-width="14" opacity=".35"/>
<g stroke="#0F766E" stroke-width="26" stroke-linecap="round">
 <path d="M582 372 H744"/><path d="M582 452 H744"/><path d="M582 532 H700"/>
 <path d="M280 372 H442" opacity=".55"/><path d="M280 452 H442" opacity=".55"/>
</g>
<circle cx="350" cy="640" r="128" fill="#0A4844" opacity=".25"/>
<circle cx="340" cy="626" r="124" fill="url(#coin)" stroke="#FFFFFF" stroke-width="18"/>
<path d="M290 626 l34 34 l66 -72" fill="none" stroke="#FFFFFF" stroke-width="30" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;
(async () => {
  const out = path.join(__dirname, '..', 'build');
  fs.writeFileSync(path.join(out, 'icon.svg'), svg);
  await sharp(Buffer.from(svg)).resize(512, 512).png().toFile(path.join(out, 'icon.png'));
  const sizes = [16, 24, 32, 48, 64, 128, 256];
  const pngs = await Promise.all(sizes.map((s) => sharp(Buffer.from(svg), { density: 300 }).resize(s, s).png().toBuffer()));
  // ICO بصور PNG مضمّنة (مدعوم منذ Windows Vista)
  const head = Buffer.alloc(6 + 16 * sizes.length);
  head.writeUInt16LE(0, 0); head.writeUInt16LE(1, 2); head.writeUInt16LE(sizes.length, 4);
  let off = head.length;
  sizes.forEach((s, i) => {
    const e = 6 + i * 16;
    head.writeUInt8(s >= 256 ? 0 : s, e); head.writeUInt8(s >= 256 ? 0 : s, e + 1);
    head.writeUInt16LE(1, e + 4); head.writeUInt16LE(32, e + 6); head.writeUInt32LE(pngs[i].length, e + 8); head.writeUInt32LE(off, e + 12);
    off += pngs[i].length;
  });
  fs.writeFileSync(path.join(out, 'icon.ico'), Buffer.concat([head, ...pngs]));
  console.log('icon.png + icon.ico (' + sizes.join(',') + ')');
})();
