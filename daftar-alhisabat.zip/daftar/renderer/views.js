/* الشاشات */
(function () {
  'use strict';
  var A = window.__app, api = window.api, Core = window.Core, Docs = window.Docs, BT = window.BT;
  var h = A.h, ic = A.ic, toast = A.toast, fld = A.fld, inp = A.inp, money = Core.money, today = Core.today, F = A.forms, V = A.VIEWS;
  function L() { return A.L; }
  function cur() { return A.L.curTxt(); }
  function fig(cls, label, value, sub, fn) {
    return h('button', { class: 'fig ' + cls, type: 'button', onclick: fn }, h('small', { text: label }), h('b', { class: 'num', text: value }), h('i', { text: sub || '' }));
  }
  function payRow(p, onClick) {
    var c = L().db.customers[p.cid];
    return h('div', { class: 'line' + (p.void ? ' void' : ''), onclick: onClick || function () { F.receipt(p, false); } },
      h('div', { class: 't' }, h('b', { text: c ? c.name : '—' }), h('small', { class: 'num', text: '#' + L().recNo(p) + '  ' + p.d + ' ' + Core.hm(p.ts) + '  ' + Core.methodName(p.m) })),
      h('div', { class: 'a good' }, h('span', { class: 'num', text: money(p.amt) }), p.void ? h('small', { class: 'muted', text: 'ملغى' }) : null));
  }
  function openCustomer(id) { A.state.cust.sel = id; A.state.cust.q = ''; A.state.cust.f = 'all'; A.go('cust', { focusSel: true }); }
  A.openCustomer = openCustomer;

  /* ================= الرئيسية ================= */
  V.home = function (page) {
    function paint() {
      page.innerHTML = '';
      var Lg = L(), t = Lg.totals(), cs = Lg.activeCustomers(), td = today();
      A.setTop('الرئيسية', [h('button', { class: 'btn soft', type: 'button', onclick: function () { F.customer(null, function (c) { openCustomer(c.id); }); } }, ic('plus'), 'عميل جديد ', h('kbd', { text: 'Ctrl+N' })),
        h('button', { class: 'btn', type: 'button', onclick: newPayment }, ic('receipt'), 'تسديد ', h('kbd', { text: 'Ctrl+P' }))]);
      if (!cs.length) {
        page.appendChild(h('div', { class: 'card empty', style: { maxWidth: '640px', margin: '40px auto' } }, h('b', { text: 'ابدأ بإضافة عملائك' }),
          h('p', { text: 'أضف عميلاً، أو استورد قائمتك من Excel، أو استعد نسخة احتياطية من تطبيق الهاتف.' }),
          h('div', { style: { display: 'flex', gap: '8px', justifyContent: 'center', flexWrap: 'wrap' } },
            h('button', { class: 'btn', type: 'button', onclick: function () { F.customer(null, function (c) { openCustomer(c.id); }); } }, ic('plus'), 'عميل جديد'),
            h('button', { class: 'btn soft', type: 'button', onclick: F.importFile }, ic('upload'), 'استيراد من Excel/CSV'),
            h('button', { class: 'btn ghost', type: 'button', onclick: F.restore }, ic('folder'), 'استعادة نسخة احتياطية'))));
        return;
      }
      var wrap = h('div', { class: 'grid' }); page.appendChild(wrap);
      wrap.appendChild(h('div', { class: 'figs' },
        fig('brand', 'المحصَّل اليوم', money(t.today) + cur(), t.todayN + ' سند', function () { A.state.rec.range = 'today'; A.go('rec'); }),
        fig('good', 'المحصَّل هذا الشهر', money(t.month) + cur(), 'منذ ' + Core.ymOf(td) + '-01', function () { A.state.rep.range = 'month'; A.go('rep'); }),
        fig('warn', 'إجمالي المستحق', money(t.out) + cur(), t.owingN + ' عميل', function () { A.state.cust.f = 'owing'; A.go('cust'); }),
        fig('bad', 'المتأخر', money(t.overdue) + cur(), t.lateN + ' عميل', function () { A.state.cust.f = 'late'; A.go('cust'); })));
      var lb = Lg.db.meta.lastBackup;
      if (cs.length >= 3 && Date.now() - (lb || 0) > 7 * 86400000 && !A.local.backupDir) {
        wrap.appendChild(h('div', { class: 'note' }, h('span', { text: lb ? 'مرّ أكثر من أسبوع على آخر نسخة احتياطية. بياناتك على هذا الحاسوب فقط.' : 'لم تأخذ نسخة احتياطية بعد. بياناتك على هذا الحاسوب فقط.' }),
          h('div', { style: { display: 'flex', gap: '6px' } }, h('button', { class: 'btn sm', type: 'button', text: 'نسخة الآن', onclick: F.backupNow }), h('button', { class: 'btn sm ghost', type: 'button', text: 'تفعيل النسخ التلقائي', onclick: function () { A.go('set'); } }))));
      }
      var late = cs.map(function (c) { return { c: c, a: Lg.acct(c.id) }; }).filter(function (x) { return x.a.overdue > 0.004; }).sort(function (a, b) { return b.a.overdue - a.a.overdue; });
      var cols = h('div', { class: 'grid cols-2' }); wrap.appendChild(cols);
      var lc = h('div', { class: 'card' }, h('h2', { class: 'sec' }, h('span', null, 'المتأخرون ', h('span', { class: 'pill bad num', text: String(late.length) })),
        late.length > 8 ? h('button', { class: 'link', type: 'button', text: 'عرض الكل', onclick: function () { A.state.cust.f = 'late'; A.state.cust.s = 'bal'; A.go('cust'); } }) : null));
      var ll = h('div', { class: 'lines' }); lc.appendChild(ll); cols.appendChild(lc);
      if (!late.length) ll.appendChild(h('div', { class: 'empty', text: 'لا يوجد متأخرون.' }));
      late.slice(0, 8).forEach(function (x) {
        ll.appendChild(h('div', { class: 'line wide', onclick: function () { openCustomer(x.c.id); } },
          h('div', { class: 't' }, h('b', { text: x.c.name }), h('small', { class: 'num', text: x.c.phone || '' })),
          h('div', { class: 'a bad' }, h('span', { class: 'num', text: money(x.a.overdue) }), h('small', { text: 'متأخر ' + x.a.maxLate + ' يوم' })),
          h('div', { class: 'acts', onclick: function (e) { e.stopPropagation(); } },
            x.c.phone ? h('button', { class: 'btn wa sm icon', type: 'button', title: 'تذكير واتساب', 'aria-label': 'تذكير واتساب', onclick: function () { F.remind(x.c); } }, ic('wa')) : null,
            h('button', { class: 'btn sm', type: 'button', onclick: function () { F.pay(x.c.id); } }, 'تسديد'))));
      });
      var right = h('div', { class: 'grid', style: { alignContent: 'start' } }); cols.appendChild(right);
      var soon = cs.map(function (c) { return { c: c, a: Lg.acct(c.id) }; }).filter(function (x) { return x.a.overdue < 0.004 && x.a.next && x.a.next.due >= td && Core.dayDiff(x.a.next.due, td) <= 7; })
        .sort(function (a, b) { return a.a.next.due < b.a.next.due ? -1 : a.a.next.due > b.a.next.due ? 1 : 0; });
      var sc = h('div', { class: 'card' }, h('h2', { class: 'sec' }, h('span', null, 'يستحق خلال 7 أيام ', h('span', { class: 'pill warn num', text: String(soon.length) }))));
      var sl = h('div', { class: 'lines' }); sc.appendChild(sl); right.appendChild(sc);
      if (!soon.length) sl.appendChild(h('div', { class: 'empty', text: 'لا استحقاقات قريبة.' }));
      soon.slice(0, 6).forEach(function (x) {
        sl.appendChild(h('div', { class: 'line wide', onclick: function () { openCustomer(x.c.id); } },
          h('div', { class: 't' }, h('b', { text: x.c.name }), h('small', { text: (x.a.next.desc || 'مستحق') + ' — ' + A.relDays(x.a.next.due) })),
          h('div', { class: 'a warn' }, h('span', { class: 'num', text: money(x.a.nextLeft) }), h('small', { class: 'num', text: x.a.next.due })),
          h('div', { class: 'acts', onclick: function (e) { e.stopPropagation(); } }, x.c.phone ? h('button', { class: 'btn wa sm icon', type: 'button', title: 'تذكير واتساب', 'aria-label': 'تذكير واتساب', onclick: function () { F.remind(x.c); } }, ic('wa')) : null)));
      });
      var rec = Lg.db.pays.filter(function (p) { return !p.void; }).sort(function (a, b) { return b.ts - a.ts; }).slice(0, 6);
      var rc = h('div', { class: 'card' }, h('h2', { class: 'sec' }, h('span', { text: 'آخر التسديدات' }), h('button', { class: 'link', type: 'button', text: 'كل السندات', onclick: function () { A.state.rec.range = 'all'; A.go('rec'); } })));
      var rl = h('div', { class: 'lines' }); rc.appendChild(rl); right.appendChild(rc);
      if (!rec.length) rl.appendChild(h('div', { class: 'empty', text: 'لم تُسجَّل تسديدات بعد.' }));
      rec.forEach(function (p) { rl.appendChild(payRow(p)); });
    }
    paint();
    return { refresh: paint };
  };

  /* ================= العملاء: جدول + تفاصيل ================= */
  V.cust = function (page, opts) {
    var st = A.state.cust; page.className = 'page fill';
    A.setTop('العملاء', [h('button', { class: 'btn ghost', type: 'button', onclick: F.importFile }, ic('upload'), 'استيراد من Excel/CSV'),
      h('button', { class: 'btn', type: 'button', onclick: function () { F.customer(null, function (c) { st.sel = c.id; st.q = ''; st.f = 'all'; q.value = ''; paint(true); }); } }, ic('plus'), 'عميل جديد ', h('kbd', { text: 'Ctrl+N' }))]);
    var q = inp({ type: 'search', placeholder: 'ابحث بالاسم أو الرقم', value: st.q, 'aria-label': 'بحث', id: 'cust-search' });
    var chipBox = h('div'), sortSel = h('select', { class: 'sel', 'aria-label': 'الترتيب' }, h('option', { value: 'name', text: 'ترتيب: الاسم' }), h('option', { value: 'bal', text: 'ترتيب: الأكبر مبلغاً' }), h('option', { value: 'due', text: 'ترتيب: الأقدم استحقاقاً' }));
    sortSel.value = st.s;
    page.appendChild(h('div', { class: 'toolbar' }, h('label', { class: 'search' }, ic('search'), q, h('kbd', { text: 'Ctrl+F' })), chipBox, sortSel));
    var detail = h('aside', { class: 'detail', 'aria-label': 'تفاصيل العميل' });
    var table = new A.VTable({
      cols: 'minmax(130px, 2fr) 136px minmax(92px, 1fr) minmax(92px, 1fr) 100px', rowH: 48, label: 'العملاء',
      head: [['الاسم'], ['الهاتف'], ['المتبقي', 'amt'], ['المتأخر', 'amt'], ['الاستحقاق']],
      render: function (x, row) {
        var a = x.a, bi = A.balInfo(a);
        row.appendChild(h('div', { class: 'who' }, h('b', { text: x.c.name })));
        row.appendChild(h('div', { class: 'num muted', text: x.c.phone || '' }));
        row.appendChild(a.bal > 0.004 ? h('div', { class: 'amt num ' + bi.cls, text: money(a.bal) }) : a.bal < -0.004 ? h('div', { class: 'amt num info', title: 'رصيد له', text: money(-a.bal) + ' له' }) : h('div', { class: 'amt ' + (a.total ? 'good' : 'muted'), text: a.total ? 'مسدّد' : '—' }));
        row.appendChild(h('div', { class: 'amt num ' + (a.overdue > 0.004 ? 'bad' : 'muted'), text: a.overdue > 0.004 ? money(a.overdue) : '—' }));
        row.appendChild(h('div', { class: 'num ' + (a.next && a.next.due < today() ? 'bad' : ''), text: a.next ? a.next.due : '' }));
      },
      onSelect: function (x) { st.sel = x.c.id; paintDetail(); },
      onOpen: function (x) { F.pay(x.c.id); }
    });
    var split = h('div', { class: 'split' }, table.el, detail); page.appendChild(split);
    var listed = [];
    function paint(scrollToSel) {
      var r = L().customerList(st.q, st.f, st.s); listed = r.list;
      chipBox.innerHTML = '';
      chipBox.appendChild(A.chips([['all', 'الكل'], ['late', 'متأخر'], ['owing', 'عليه رصيد'], ['clear', 'مسدّد']], st.f, function (v) { st.f = v; paint(); }, r.cnt));
      var idx = -1; for (var i = 0; i < listed.length; i++) if (listed[i].c.id === st.sel) { idx = i; break; }
      table.sel = idx;
      table.setItems(listed, r.cnt.all ? h('div', null, h('b', { text: 'لا نتائج' }), 'جرّب بحثاً آخر أو فلتراً مختلفاً.') : h('div', null, h('b', { text: 'لا يوجد عملاء بعد' }), 'اضغط «عميل جديد» أو استورد قائمة من Excel.'));
      var tot = 0; listed.forEach(function (x) { if (x.a.bal > 0) tot += x.a.bal; });
      table.foot.innerHTML = ''; table.foot.appendChild(h('span', { text: listed.length + ' عميل' })); table.foot.appendChild(h('span', { class: 'num', text: 'مجموع المتبقي ' + money(Core.r2(tot)) + cur() }));
      if (idx >= 0 && scrollToSel) table.select(idx, true); else paintDetail();
    }
    function paintDetail() {
      detail.innerHTML = '';
      var c = L().db.customers[st.sel];
      if (!c || c.arch) { detail.appendChild(h('div', { class: 'empty', style: { margin: 'auto' } }, h('b', { text: 'اختر عميلاً' }), 'استعمل الأسهم ↑↓ للتنقل، وEnter للتسديد.')); return; }
      var Lg = L(), a = Lg.acct(c.id), bi = A.balInfo(a), pct = a.total ? Math.min(100, Math.round(a.paid / a.total * 100)) : 0;
      var head = h('div', { class: 'dhead' },
        h('div', { class: 'name' }, A.avatar(c), h('div', { style: { flex: '1', minWidth: '0' } }, h('h2', { text: c.name }), h('div', { class: 'ph num', text: c.phone || 'بدون رقم' }))),
        h('div', { class: 'balance ' + bi.cls },
          h('div', { class: 'top-row' }, h('span', { text: a.bal >= -0.004 ? 'المتبقي عليه' : 'رصيد له' }), h('b', { class: 'num', text: a.total ? money(Math.abs(a.bal)) + cur() : '—' })),
          a.total ? h('div', { class: 'meter', title: 'المسدَّد ' + pct + '%' }, h('i', { style: { width: pct + '%' } })) : null,
          h('div', { class: 'kv' }, h('span', { text: 'إجمالي المستحقات' }), h('b', { class: 'num', text: money(a.total) })),
          h('div', { class: 'kv' }, h('span', { text: 'إجمالي المسدَّد' }), h('b', { class: 'num good', text: money(a.paid) })),
          a.overdue > 0.004 ? h('div', { class: 'kv' }, h('span', { text: 'منه متأخر' }), h('b', { class: 'num bad', text: money(a.overdue) + ' • ' + a.maxLate + ' يوم' })) : null,
          a.next ? h('div', { class: 'kv' }, h('span', { text: 'الاستحقاق القادم' }), h('b', { class: 'num', text: a.next.due + ' — ' + money(a.nextLeft) })) : null),
        c.note ? h('p', { class: 'muted small', style: { margin: '10px 0 0' }, text: c.note }) : null);
      detail.appendChild(head);
      detail.appendChild(h('div', { class: 'dacts' },
        h('button', { class: 'btn main', type: 'button', onclick: function () { F.pay(c.id); } }, ic('receipt'), 'تسديد ', h('kbd', { text: 'Ctrl+P' })),
        h('button', { class: 'btn soft', type: 'button', onclick: function () { F.charge(c.id); } }, ic('plus'), 'مستحق جديد'),
        h('button', { class: 'btn wa', type: 'button', disabled: !c.phone, onclick: function () { F.remind(c); } }, ic('wa'), 'تذكير'),
        h('button', { class: 'btn ghost', type: 'button', onclick: function () { F.statement(c); } }, ic('doc'), 'كشف حساب'),
        h('button', { class: 'btn ghost', type: 'button', onclick: function () { F.customer(c); } }, ic('edit'), 'تعديل'),
        A.armed(h('button', { class: 'btn ghost', type: 'button', text: 'أرشفة' }), 'تأكيد الأرشفة؟', function () { L().archive(c); st.sel = null; toast('أُرشف العميل. بياناته محفوظة في النسخ الاحتياطية.'); paint(); A.paintTally(); }),
        h('span')));
      var pays = Lg.paysOf(c.id), subs = Lg.db.subs.filter(function (s) { return s.cid === c.id; });
      var tabs = [['ch', 'المستحقات', a.items.length], ['py', 'التسديدات', pays.length], ['sb', 'الاشتراكات', subs.length]];
      var tb = h('div', { class: 'tabs', role: 'tablist' }), body = h('div', { class: 'tabbody' });
      tabs.forEach(function (t) { tb.appendChild(h('button', { type: 'button', role: 'tab', 'aria-selected': st.tab === t[0] ? 'true' : 'false', onclick: function () { st.tab = t[0]; paintDetail(); } }, t[1] + ' ', h('span', { class: 'num', text: '(' + t[2] + ')' }))); });
      detail.appendChild(tb); detail.appendChild(body);
      if (st.tab === 'ch') {
        if (!a.items.length) body.appendChild(h('div', { class: 'empty' }, h('b', { text: 'لا مستحقات' }), 'أضف ديناً أو أقساطاً أو اشتراكاً شهرياً.'));
        var items = a.items.slice().sort(function (x, y) { return x.c.due < y.c.due ? 1 : x.c.due > y.c.due ? -1 : y.c.id - x.c.id; });
        A.chunked(body, items, function (it) {
          var pill = it.status === 'paid' ? h('span', { class: 'pill good', text: 'مسدّد' }) : it.status === 'part' ? h('span', { class: 'pill info', text: 'جزئي — باقٍ ' + money(it.left) })
            : it.status === 'late' ? h('span', { class: 'pill bad', text: 'متأخر ' + Core.dayDiff(today(), it.c.due) + ' يوم' }) : h('span', { class: 'pill warn', text: 'غير مسدّد' });
          if (it.status === 'part' && it.late) pill = h('span', { class: 'pill bad', text: 'جزئي متأخر — باقٍ ' + money(it.left) });
          return h('div', { class: 'item', role: 'button', tabindex: '0', onclick: function () { F.chargeEdit(it); }, onkeydown: function (e) { if (e.key === 'Enter') F.chargeEdit(it); } },
            h('div', { class: 't' }, h('b', { text: it.c.desc || 'مستحق' }), h('small', { class: 'num', text: 'الاستحقاق ' + it.c.due })),
            h('div', { class: 'a' }, h('span', { class: 'num', text: money(it.c.amt) }), h('small', null, pill)),
            it.status === 'part' ? h('div', { class: 'prog' }, h('i', { style: { width: Math.round(it.paid / it.c.amt * 100) + '%' } })) : null);
        }, 40);
      } else if (st.tab === 'py') {
        if (!pays.length) body.appendChild(h('div', { class: 'empty' }, h('b', { text: 'لا تسديدات بعد' }), 'اضغط «تسديد» لإصدار أول سند.'));
        A.chunked(body, pays, function (p) {
          return h('div', { class: 'item' + (p.void ? ' void' : ''), role: 'button', tabindex: '0', onclick: function () { F.receipt(p, false); }, onkeydown: function (e) { if (e.key === 'Enter') F.receipt(p, false); } },
            h('div', { class: 't' }, h('b', { text: 'سند ' + Lg.recNo(p) }), h('small', { class: 'num', text: p.d + ' ' + Core.hm(p.ts) + ' • ' + Core.methodName(p.m) + (p.t ? ' • ' + p.t : '') })),
            h('div', { class: 'a good' }, h('span', { class: 'num', text: money(p.amt) }), p.void ? h('small', { class: 'muted', text: 'ملغى' }) : null));
        }, 40);
      } else {
        if (!subs.length) body.appendChild(h('div', { class: 'empty' }, h('b', { text: 'لا اشتراكات' }), 'أضف اشتراكاً شهرياً من «مستحق جديد».'));
        subs.forEach(function (s) {
          body.appendChild(h('div', { class: 'subcard' },
            h('div', { class: 'kv' }, h('b', { text: s.desc || 'اشتراك شهري' }), h('span', { class: 'pill ' + (s.active ? 'good' : ''), text: s.active ? 'فعّال' : 'موقوف' })),
            h('div', { class: 'kv' }, h('span', { text: 'يستحق يوم ' + s.day + ' من كل شهر • آخر شهر ' + (s.last || '—') }), h('b', { class: 'num', text: money(s.amt) + cur() })),
            h('div', { class: 'btns' },
              h('button', { class: 'btn soft sm', type: 'button', text: s.active ? 'إيقاف' : 'استئناف', onclick: function () { L().toggleSub(s); toast(s.active ? 'استُؤنف الاشتراك من هذا الشهر.' : 'أُوقف الاشتراك.'); A.refresh(); } }),
              A.armed(h('button', { class: 'btn danger sm', type: 'button', text: 'حذف الاشتراك' }), 'تأكيد؟', function () { L().deleteSub(s); toast('حُذف الاشتراك. المستحقات التي صدرت سابقاً باقية.'); A.refresh(); }))));
        });
      }
    }
    var qT = null;
    q.addEventListener('input', function () { clearTimeout(qT); qT = setTimeout(function () { st.q = q.value; paint(); }, 60); });
    q.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); table.select(table.sel < 0 ? 0 : table.sel + (e.key === 'ArrowDown' ? 1 : -1)); }
      else if (e.key === 'Enter' && table.sel >= 0 && listed[table.sel]) { e.preventDefault(); F.pay(listed[table.sel].c.id); }
    });
    sortSel.addEventListener('change', function () { st.s = sortSel.value; paint(); });
    paint(true);
    if (opts.focusSel) setTimeout(function () { table.body.focus(); }, 30); else setTimeout(function () { q.focus(); }, 30);
    return { refresh: function () { paint(); }, focusSearch: function () { q.focus(); q.select(); }, selected: function () { var c = L().db.customers[st.sel]; return c && !c.arch ? c : null; } };
  };

  /* ================= السندات ================= */
  var RANGES = [['today', 'اليوم'], ['yday', 'أمس'], ['w7', '7 أيام'], ['month', 'هذا الشهر'], ['lmonth', 'الشهر الماضي'], ['all', 'الكل']];
  V.rec = function (page) {
    var st = A.state.rec; page.className = 'page fill';
    A.setTop('السندات', [h('button', { class: 'btn ghost', type: 'button', onclick: function () { exportReceipts('xlsx'); } }, ic('download'), 'تصدير Excel'),
      h('button', { class: 'btn ghost', type: 'button', onclick: function () { exportReceipts('csv'); } }, ic('download'), 'CSV'),
      h('button', { class: 'btn', type: 'button', onclick: newPayment }, ic('receipt'), 'تسديد ', h('kbd', { text: 'Ctrl+P' }))]);
    var q = inp({ type: 'search', placeholder: 'ابحث بالاسم أو رقم السند أو الهاتف', value: st.q, id: 'rec-search', 'aria-label': 'بحث' }), chipBox = h('div'), sum = h('div', { class: 'muted small' });
    page.appendChild(h('div', { class: 'toolbar' }, h('label', { class: 'search' }, ic('search'), q), chipBox, sum));
    var table = new A.VTable({
      cols: '96px 150px minmax(140px, 2fr) 80px minmax(100px, 1fr) 92px', rowH: 46, label: 'السندات', openOnClick: true,
      head: [['رقم السند'], ['التاريخ والوقت'], ['العميل'], ['الطريقة'], ['المبلغ', 'amt'], ['']],
      render: function (p, row) {
        var c = L().db.customers[p.cid];
        if (p.void) row.classList.add('void');
        row.appendChild(h('div', { class: 'num', text: L().recNo(p) }));
        row.appendChild(h('div', { class: 'num muted', text: p.d + '  ' + Core.hm(p.ts) }));
        row.appendChild(h('div', { class: 'who' }, h('b', { text: c ? c.name : '—' }), p.void ? h('span', { class: 'pill', style: { marginInlineStart: '6px' }, text: 'ملغى' }) : null));
        row.appendChild(h('div', { text: Core.methodName(p.m) }));
        row.appendChild(h('div', { class: 'amt num ' + (p.void ? '' : 'good'), text: money(p.amt) }));
        row.appendChild(h('div', { class: 'rowacts' },
          h('button', { class: 'btn ghost sm icon', type: 'button', title: 'إعادة طباعة', 'aria-label': 'إعادة طباعة', onclick: function () { A.printDoc(function (w) { return Docs.receiptDoc(L(), p, w); }); } }, ic('print')),
          A.armed(h('button', { class: 'btn ghost sm', type: 'button', title: p.void ? 'استرجاع' : 'إلغاء', text: p.void ? 'استرجاع' : 'إلغاء' }), 'تأكيد', function () { L().setPayVoid(p, !p.void); toast(p.void ? 'أُلغي السند.' : 'استُرجع السند.'); A.refresh(); })));
      },
      onOpen: function (p) { F.receipt(p, false); }
    });
    page.appendChild(table.el); table.el.style.flex = '1';
    function paint() {
      chipBox.innerHTML = ''; chipBox.appendChild(A.chips(RANGES, st.range, function (v) { st.range = v; paint(); }));
      var list = L().receipts(st.range, st.q), s = 0, n = 0;
      list.forEach(function (p) { if (!p.void) { s += p.amt; n++; } });
      sum.textContent = n + ' سند ساري • المجموع ' + money(Core.r2(s)) + cur();
      table.setItems(list, h('div', null, h('b', { text: 'لا سندات' }), 'لا توجد سندات في هذه الفترة.'));
      table.foot.innerHTML = ''; table.foot.appendChild(h('span', { text: 'Enter أو نقرة لفتح السند' })); table.foot.appendChild(h('span', { class: 'num', text: list.length + ' سطر' }));
    }
    var qT = null;
    q.addEventListener('input', function () { clearTimeout(qT); qT = setTimeout(function () { st.q = q.value; paint(); }, 60); });
    q.addEventListener('keydown', function (e) { if (e.key === 'ArrowDown') { e.preventDefault(); table.body.focus(); table.select(Math.max(0, table.sel)); } });
    function exportReceipts(kind) {
      var rows = L().receiptRows(L().receipts(st.range, st.q)), name = 'receipts-' + today();
      exportRows(kind, name, 'السندات', rows);
    }
    paint();
    return { refresh: paint, focusSearch: function () { q.focus(); q.select(); } };
  };

  function exportRows(kind, name, sheet, rows) {
    var p = kind === 'xlsx' ? api.saveXlsx(name + '.xlsx', [{ name: sheet, rows: rows }]) : api.saveText(name + '.csv', Core.csvString(rows), 'csv');
    p.then(function (r) { if (r.ok) toast('حُفظ الملف: ' + r.path); else if (!r.cancelled) toast(r.error, true); });
  }

  /* ================= التقارير ================= */
  V.rep = function (page) {
    var st = A.state.rep;
    function paint() {
      page.innerHTML = '';
      var Lg = L(), r = Lg.report(st.range), ag = Lg.aging(), t = Lg.totals(), label = (RANGES.filter(function (x) { return x[0] === st.range; })[0] || ['', ''])[1];
      A.setTop('التقارير', [h('button', { class: 'btn ghost', type: 'button', onclick: function () { reportOut('print'); } }, ic('print'), 'طباعة A4'),
        h('button', { class: 'btn', type: 'button', onclick: function () { reportOut('pdf'); } }, ic('doc'), 'حفظ PDF')]);
      var wrap = h('div', { class: 'grid' }); page.appendChild(wrap);
      wrap.appendChild(h('div', { class: 'toolbar', style: { margin: '0' } }, A.chips(RANGES, st.range, function (v) { st.range = v; paint(); }),
        h('span', { class: 'muted small num', text: st.range === 'all' ? 'كل السجلات' : r.range[0] + ' → ' + (r.range[1] > today() ? today() : r.range[1]) })));
      wrap.appendChild(h('div', { class: 'figs' },
        fig('brand', 'المحصَّل', money(r.sum) + cur(), r.pays.length + ' سند', function () { A.state.rec.range = st.range; A.go('rec'); }),
        fig('warn', 'مستحقات صدرت', money(r.issued) + cur(), r.charges.length + ' مستحق'),
        fig('', 'إجمالي المستحق الآن', money(t.out) + cur(), t.owingN + ' عميل', function () { A.state.cust.f = 'owing'; A.go('cust'); }),
        fig('bad', 'المتأخر الآن', money(t.overdue) + cur(), t.lateN + ' عميل', function () { A.state.cust.f = 'late'; A.go('cust'); })));
      var g = h('div', { class: 'grid cols-3' }); wrap.appendChild(g);
      // مخطط التحصيل اليومي
      var days = Object.keys(r.byD).sort(), chart = h('div', { class: 'card span-2' }, h('h2', { text: 'التحصيل اليومي — ' + label }));
      if (days.length) {
        // كل أيام الفترة حتى الأيام بلا تحصيل، ليظهر الانقطاع (حد أقصى 92 يوماً)
        var lastD = r.range[1] > today() ? today() : r.range[1], firstD = st.range === 'all' ? days[0] : r.range[0];
        if (Core.dayDiff(lastD, firstD) > 91) firstD = Core.addDays(lastD, -91);
        days = []; for (var dd = firstD; dd <= lastD; dd = Core.addDays(dd, 1)) { days.push(dd); if (r.byD[dd] == null) r.byD[dd] = 0; }
        var mx = Math.max.apply(null, days.map(function (d) { return r.byD[d]; })) || 1;
        chart.appendChild(h('div', { class: 'bars', role: 'img', 'aria-label': 'مخطط أعمدة للتحصيل اليومي' }, days.map(function (d) { return h('i', { style: { height: (r.byD[d] ? Math.max(3, Math.round(r.byD[d] / mx * 100)) : 0.5) + '%' }, title: d + ': ' + money(r.byD[d]) }); })));
        chart.appendChild(h('div', { class: 'bars-l' }, h('span', { class: 'num', text: days[0] }), h('span', { class: 'num', text: 'الأعلى ' + money(mx) }), h('span', { class: 'num', text: days[days.length - 1] })));
      } else chart.appendChild(h('div', { class: 'empty', text: 'لا تحصيل في هذه الفترة.' }));
      g.appendChild(chart);
      var meth = h('div', { class: 'card' }, h('h2', { text: 'حسب طريقة الدفع' }));
      ['cash', 'transfer', 'other'].forEach(function (m) {
        var v = r.byM[m] || 0, pct = r.sum ? Math.round(v / r.sum * 100) : 0;
        meth.appendChild(h('div', { class: 'agebar' }, h('span', { text: Core.methodName(m) }), h('div', { class: 'track' }, h('i', { style: { width: pct + '%', background: 'var(--brand)' } })), h('b', { class: 'num', text: money(v) })));
      });
      g.appendChild(meth);
      var aging = h('div', { class: 'card' }, h('h2', { text: 'أعمار المتأخرات (كل العملاء)' })), amx = Math.max.apply(null, ag.amt) || 1;
      [['1 - 30 يوماً', 0], ['31 - 60 يوماً', 1], ['61 - 90 يوماً', 2], ['أكثر من 90 يوماً', 3]].forEach(function (x) {
        aging.appendChild(h('div', { class: 'agebar' }, h('span', { text: x[0] }), h('div', { class: 'track' }, h('i', { style: { width: Math.round(ag.amt[x[1]] / amx * 100) + '%' } })), h('b', { class: 'num ' + (ag.amt[x[1]] > 0.004 ? 'bad' : 'muted'), text: money(ag.amt[x[1]]) })));
      });
      g.appendChild(aging);
      var ex = h('div', { class: 'card span-2' }, h('h2', { text: 'تصدير' }),
        h('p', { class: 'muted small', style: { margin: '0 0 10px' }, text: 'ملفات Excel حقيقية (xlsx) أو CSV بترميز UTF-8 تفتح العربية سليمة في Excel.' }),
        h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap' } },
          h('button', { class: 'btn soft', type: 'button', onclick: function () { exportRows('xlsx', 'receipts-' + today(), 'السندات', Lg.receiptRows(Lg.receipts(st.range, ''))); } }, ic('download'), 'سندات الفترة (Excel)'),
          h('button', { class: 'btn ghost', type: 'button', onclick: function () { exportRows('csv', 'receipts-' + today(), 'السندات', Lg.receiptRows(Lg.receipts(st.range, ''))); } }, 'سندات الفترة (CSV)'),
          h('button', { class: 'btn soft', type: 'button', onclick: function () { exportRows('xlsx', 'balances-' + today(), 'أرصدة العملاء', Lg.balanceRows()); } }, ic('download'), 'أرصدة العملاء (Excel)'),
          h('button', { class: 'btn ghost', type: 'button', onclick: function () { exportRows('csv', 'balances-' + today(), 'أرصدة العملاء', Lg.balanceRows()); } }, 'أرصدة العملاء (CSV)')));
      g.appendChild(ex);
      var recent = h('div', { class: 'card' }, h('h2', { class: 'sec' }, h('span', { text: 'سندات الفترة' }), h('button', { class: 'link', type: 'button', text: 'عرض الكل', onclick: function () { A.state.rec.range = st.range; A.go('rec'); } })));
      var rl = h('div', { class: 'lines' }); recent.appendChild(rl);
      if (!r.pays.length) rl.appendChild(h('div', { class: 'empty', text: 'لا سندات.' }));
      r.pays.slice(0, 6).forEach(function (p) { rl.appendChild(payRow(p)); });
      g.appendChild(recent);
    }
    // تقرير A4 كصفحة HTML مستقلة للطباعة أو PDF
    function reportHtml() {
      var Lg = L(), r = Lg.report(st.range), ag = Lg.aging(), t = Lg.totals(), E = Core.esc, c = Lg.db.cfg, label = (RANGES.filter(function (x) { return x[0] === st.range; })[0] || ['', ''])[1];
      var rows = r.pays.slice(0, 1500).map(function (p) { var cu = Lg.db.customers[p.cid] || {}; return '<tr><td>' + E(Lg.recNo(p)) + '</td><td>' + E(p.d) + ' ' + Core.hm(p.ts) + '</td><td>' + E(cu.name || '') + '</td><td>' + E(Core.methodName(p.m)) + '</td><td class="n">' + money(p.amt) + '</td></tr>'; }).join('');
      var bal = Lg.activeCustomers().map(function (cu) { return { c: cu, a: Lg.acct(cu.id) }; }).filter(function (x) { return x.a.overdue > 0.004; }).sort(function (a, b) { return b.a.overdue - a.a.overdue; }).slice(0, 300)
        .map(function (x) { return '<tr><td>' + E(x.c.name) + '</td><td>' + E(x.c.phone || '') + '</td><td class="n">' + money(x.a.bal) + '</td><td class="n">' + money(x.a.overdue) + '</td><td class="n">' + x.a.maxLate + '</td></tr>'; }).join('');
      return '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>' +
        '@page{size:A4;margin:14mm}body{font:12px/1.6 "Noto Sans Arabic","Segoe UI",Tahoma,sans-serif;color:#111}h1{font-size:20px;margin:0}h2{font-size:14px;margin:18px 0 6px;border-bottom:2px solid #0F766E;padding-bottom:3px}' +
        '.hd{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:1px solid #999;padding-bottom:8px}.k{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:10px}.k div{border:1px solid #ccc;border-radius:6px;padding:6px 8px}.k b{display:block;font-size:15px}' +
        'table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #ddd;padding:3px 5px;text-align:right}th{background:#f1f5f4}.n{direction:ltr;text-align:left;font-variant-numeric:tabular-nums}tr{page-break-inside:avoid}.m{color:#555}</style></head><body>' +
        '<div class="hd"><div><h1>تقرير التحصيل — ' + E(label) + '</h1><div class="m">' + E(c.shop || 'دفتر الحسابات') + (c.shopph ? ' — ' + E(c.shopph) : '') + '</div></div><div class="m n">' + E(st.range === 'all' ? 'كل السجلات' : r.range[0] + ' → ' + (r.range[1] > today() ? today() : r.range[1])) + '<br>طُبع ' + today() + '</div></div>' +
        '<div class="k"><div>المحصَّل<b class="n">' + money(r.sum) + E(Lg.curTxt()) + '</b>' + r.pays.length + ' سند</div><div>مستحقات صدرت<b class="n">' + money(r.issued) + '</b>' + r.charges.length + ' مستحق</div><div>إجمالي المستحق الآن<b class="n">' + money(t.out) + '</b>' + t.owingN + ' عميل</div><div>المتأخر الآن<b class="n">' + money(t.overdue) + '</b>' + t.lateN + ' عميل</div></div>' +
        '<h2>حسب طريقة الدفع</h2><table><tr><th>الطريقة</th><th>المبلغ</th></tr>' + ['cash', 'transfer', 'other'].map(function (m) { return '<tr><td>' + Core.methodName(m) + '</td><td class="n">' + money(r.byM[m] || 0) + '</td></tr>'; }).join('') + '</table>' +
        '<h2>أعمار المتأخرات</h2><table><tr><th>الفئة</th><th>عدد المستحقات</th><th>المبلغ</th></tr>' + ['1 - 30 يوماً', '31 - 60 يوماً', '61 - 90 يوماً', 'أكثر من 90 يوماً'].map(function (x, i) { return '<tr><td>' + x + '</td><td class="n">' + ag.n[i] + '</td><td class="n">' + money(ag.amt[i]) + '</td></tr>'; }).join('') + '</table>' +
        (bal ? '<h2>العملاء المتأخرون</h2><table><tr><th>الاسم</th><th>الهاتف</th><th>المتبقي</th><th>المتأخر</th><th>أيام</th></tr>' + bal + '</table>' : '') +
        '<h2>السندات (' + r.pays.length + (r.pays.length > 1500 ? '، أول 1500' : '') + ')</h2><table><tr><th>رقم</th><th>التاريخ</th><th>العميل</th><th>الطريقة</th><th>المبلغ</th></tr>' + rows + '</table></body></html>';
    }
    function reportOut(kind) {
      var html = reportHtml();
      var p = kind === 'pdf' ? api.savePdf(html, 'report-' + st.range + '-' + today() + '.pdf') : api.printHtml(html);
      p.then(function (r) { if (r.ok) toast(kind === 'pdf' ? 'حُفظ التقرير PDF.' : 'أُرسل التقرير للطباعة.'); else if (!r.cancelled) toast(r.error, true); });
    }
    paint();
    return { refresh: paint };
  };

  /* ================= الإعدادات ================= */
  V.set = function (page) {
    function paint() {
      page.innerHTML = '';
      A.setTop('الإعدادات', []);
      var Lg = L(), cfg = Lg.db.cfg, loc = A.local, wrap = h('div', { class: 'settings' }); page.appendChild(wrap);
      function field(label, key, attrs, hint) {
        var i = inp(Object.assign({ value: cfg[key] || '' }, attrs || {}));
        i.addEventListener('change', function () { cfg[key] = i.value.trim(); Lg.dirty(); A.paintTally(); });
        return fld(label, i, hint);
      }
      function setLocal(patch) { return api.setLocal(patch).then(function (l) { A.local = l; return l; }); }
      var pw = h('select'); [['384', '58 ملم (384 نقطة)'], ['576', '80 ملم (576 نقطة)']].forEach(function (o) { pw.appendChild(h('option', { value: o[0], text: o[1] })); });
      pw.value = String(cfg.pw || 384); pw.addEventListener('change', function () { cfg.pw = +pw.value; Lg.dirty(); });
      wrap.appendChild(h('div', { class: 'card' }, h('h2', { text: 'بيانات المحل والوصل' }),
        h('div', { class: 'two' }, field('اسم المحل أو الشركة', 'shop', { placeholder: 'يظهر أعلى الوصل' }), field('هاتف الوصل', 'shopph', { class: 'num', dir: 'ltr' })),
        h('div', { class: 'two' }, field('اسم العملة', 'curr', { placeholder: 'مثال: دينار' }), field('بادئة رقم السند', 'pre', { placeholder: 'اختياري، مثل A-', dir: 'ltr' })),
        field('السطر الأخير في الوصل', 'foot'), fld('عرض الورق', pw, 'عرض صورة الوصل بنقاط الطابعة الحرارية.')));

      // الطباعة
      var pc = h('div', { class: 'card' }, h('h2', { text: 'الطباعة' }));
      pc.appendChild(A.seg([['windows', 'طابعة Windows'], ['bt', 'بلوتوث صغيرة'], ['escpos', 'شبكة ESC/POS']], loc.printVia || 'windows', function (v) { setLocal({ printVia: v }).then(paint); }));
      var via = loc.printVia || 'windows';
      if (via === 'windows') {
        var ps = h('select', null, h('option', { value: '', text: 'اسأل في كل مرة (حوار الطباعة)' }));
        api.listPrinters().then(function (list) {
          list.forEach(function (p) { ps.appendChild(h('option', { value: p.name, text: p.displayName + (p.isDefault ? ' (الافتراضية)' : '') })); });
          if (loc.printerName && !list.some(function (p) { return p.name === loc.printerName; })) ps.appendChild(h('option', { value: loc.printerName, text: loc.printerName + ' (غير متصلة)' }));
          ps.value = loc.printerName || '';
        });
        ps.addEventListener('change', function () { setLocal({ printerName: ps.value }); });
        var paper = A.seg([['roll', 'ورق حراري (رول)'], ['a4', 'ورق A4']], loc.paper || 'roll', function (v) { setLocal({ paper: v }); });
        var auto = h('input', { type: 'checkbox' }); auto.checked = !!loc.autoPrint; auto.addEventListener('change', function () { setLocal({ autoPrint: auto.checked }); });
        pc.appendChild(fld('الطابعة', ps, 'عند اختيار طابعة تتم الطباعة مباشرة دون حوار.'));
        pc.appendChild(h('div', { class: 'fld' }, h('span', { text: 'نوع الورق' }), paper));
        pc.appendChild(h('label', { class: 'check' }, auto, 'طباعة تلقائية بعد حفظ السند'));
      } else if (via === 'bt') {
        var bn = BT.name();
        pc.appendChild(h('p', { class: 'muted small', style: { margin: '0' }, text: BT.supported() ? (bn ? 'متصل بـ ' + bn + '. يُختار الجهاز مرة في كل تشغيل للتطبيق.' : 'طابعات cat printer الصغيرة (MX10 وأمثالها). أغلق تطبيقها الأصلي أولاً.') : 'البلوتوث غير متاح على هذا الحاسوب.' }));
        pc.appendChild(h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', disabled: !BT.supported(), onclick: A.guard(function () { var F = A.forms; F.btOpen(); return BT.choose().then(function (n) { F.btDone(); toast('تم الاتصال بـ ' + n + '.'); paint(); }, function (e) { F.btDone(); var m = BT.explain(e); if (m) toast(m, true, 7000); }); }) }, ic('bt'), bn ? 'تغيير الطابعة' : 'اختيار الطابعة')));
        pc.appendChild(h('div', { class: 'fld' }, h('span', { text: 'كثافة الطباعة' }), A.seg([['light', 'خفيفة'], ['normal', 'عادية'], ['dark', 'غامقة']], loc.btDensity || 'normal', function (v) { setLocal({ btDensity: v }); cfg.dens = v; Lg.dirty(); })));
        var auto2 = h('input', { type: 'checkbox' }); auto2.checked = !!loc.autoPrint; auto2.addEventListener('change', function () { setLocal({ autoPrint: auto2.checked }); });
        pc.appendChild(h('label', { class: 'check' }, auto2, 'طباعة تلقائية بعد حفظ السند'));
      } else {
        var host = inp({ value: loc.escposHost || '', placeholder: '192.168.1.100', dir: 'ltr', class: 'num' }), port = inp({ value: String(loc.escposPort || 9100), dir: 'ltr', class: 'num' });
        host.addEventListener('change', function () { setLocal({ escposHost: host.value.trim() }); });
        port.addEventListener('change', function () { setLocal({ escposPort: parseInt(Core.toEn(port.value), 10) || 9100 }); });
        pc.appendChild(h('div', { class: 'two' }, fld('عنوان الطابعة (IP)', host), fld('المنفذ', port)));
        pc.appendChild(h('p', { class: 'muted small', style: { margin: '0' }, text: 'طابعات الإيصالات المتصلة بالشبكة. طابعات USB تُثبّت عادةً كطابعة Windows فاختر «طابعة Windows».' }));
      }
      pc.appendChild(h('div', { class: 'row' }, h('button', { class: 'btn soft', type: 'button', onclick: function () { A.printDoc(function (w) { return Docs.testDoc(cfg, w, via === 'bt' ? BT.name() : via === 'escpos' ? loc.escposHost : (loc.printerName || 'حوار الطباعة')); }); } }, ic('print'), 'طباعة تجريبية')));
      wrap.appendChild(pc);

      var tpl = h('textarea'); tpl.value = cfg.tpl || Core.DEF_TPL;
      tpl.addEventListener('change', function () { cfg.tpl = tpl.value.trim() || Core.DEF_TPL; Lg.dirty(); });
      wrap.appendChild(h('div', { class: 'card' }, h('h2', { text: 'رسائل واتساب' }),
        field('رمز الدولة', 'cc', { class: 'num', dir: 'ltr', placeholder: 'مثل 964 أو 966' }, 'يُضاف للأرقام التي تبدأ بصفر.'),
        fld('نص التذكير', tpl, 'المتغيرات: {الاسم} {المبلغ} {العملة} {التاريخ} {المحل}'),
        h('div', { class: 'row' }, h('button', { class: 'btn ghost sm', type: 'button', text: 'استرجاع النص الافتراضي', onclick: function () { tpl.value = Core.DEF_TPL; cfg.tpl = Core.DEF_TPL; Lg.dirty(); } }))));

      wrap.appendChild(h('div', { class: 'card' }, h('h2', { text: 'المظهر' }),
        A.seg([['auto', 'تلقائي (حسب Windows)'], ['light', 'فاتح'], ['dark', 'داكن']], cfg.theme || 'auto', function (v) { cfg.theme = v; Lg.dirty(); A.applyTheme(); })));

      var lb = Lg.db.meta.lastBackup;
      var bc = h('div', { class: 'card' }, h('h2', { text: 'النسخ الاحتياطي والبيانات' }),
        h('p', { class: 'muted small', style: { margin: '0' }, text: (lb ? 'آخر نسخة: ' + new Date(lb).toLocaleString('en-GB') : 'لم تؤخذ نسخة بعد') + '. البيانات على هذا الحاسوب فقط ولا تُرسل لأي جهة.' }),
        h('div', { class: 'summary' }, h('b', { text: 'النسخ التلقائي اليومي' }),
          h('div', { class: 'small muted', text: loc.backupDir ? 'إلى: ' + loc.backupDir + ' — يُحتفظ بآخر 14 نسخة.' + (loc.lastAutoBackup ? ' آخرها ' + loc.lastAutoBackup + '.' : '') : 'غير مفعّل. اختر مجلداً (يُفضَّل قرص آخر أو فلاش أو مجلد OneDrive).' }),
          h('div', { class: 'row', style: { marginTop: '6px' } },
            h('button', { class: 'btn sm', type: 'button', onclick: A.guard(function () { return api.chooseBackupDir().then(function (r) { if (r.ok) { A.local = r.local; toast('فُعّل النسخ التلقائي وأُخذت نسخة الآن.'); paint(); } else if (!r.cancelled) toast(r.error, true); }); }) }, ic('folder'), loc.backupDir ? 'تغيير المجلد' : 'اختيار المجلد'),
            loc.backupDir ? h('button', { class: 'btn ghost sm', type: 'button', text: 'فتح المجلد', onclick: function () { api.openBackupDir(); } }) : null,
            loc.backupDir ? h('button', { class: 'btn ghost sm', type: 'button', text: 'إيقاف', onclick: function () { api.clearBackupDir().then(function (l) { A.local = l; paint(); }); } }) : null)),
        h('div', { class: 'row' },
          h('button', { class: 'btn', type: 'button', onclick: F.backupNow }, ic('download'), 'حفظ نسخة احتياطية'),
          h('button', { class: 'btn soft', type: 'button', onclick: F.restore }, ic('upload'), 'استعادة نسخة'),
          h('button', { class: 'btn ghost', type: 'button', onclick: F.importFile }, 'استيراد عملاء من Excel/CSV'),
          h('button', { class: 'btn ghost', type: 'button', onclick: function () { api.openDataDir(); } }, 'مجلد البيانات')),
        h('p', { class: 'muted small', style: { margin: '0' }, text: 'ملف النسخة متوافق مع تطبيق الهاتف: انقله إليه واستعده، أو العكس.' }));
      wrap.appendChild(bc);

      var confirm = inp({ placeholder: 'اكتب: حذف' }), del = h('button', { class: 'btn danger', type: 'button', text: 'حذف كل البيانات', disabled: true });
      confirm.addEventListener('input', function () { del.disabled = confirm.value.trim() !== 'حذف'; });
      del.addEventListener('click', function () {
        if (confirm.value.trim() !== 'حذف') return;
        L().replace(Core.blank()); A.saveNow(); A.applyTheme(); toast('حُذفت كل البيانات.'); A.go('home');
      });
      wrap.appendChild(h('div', { class: 'card danger-zone' }, h('h2', { class: 'bad', text: 'حذف كل البيانات' }),
        h('p', { class: 'muted small', style: { margin: '0' }, text: 'يحذف العملاء والسندات والإعدادات من هذا الحاسوب. خذ نسخة احتياطية أولاً. للتأكيد اكتب كلمة «حذف».' }),
        h('div', { class: 'row' }, h('div', { style: { flex: '1', minWidth: '160px' } }, confirm), del)));
      wrap.appendChild(h('p', { class: 'muted small', text: 'دفتر الحسابات ' + (A.info.version || '') + ' • يعمل بلا إنترنت • البيانات في ' + (A.info.dataDir || '') }));
    }
    paint();
    return { refresh: function () { A.paintTally(); } };
  };

  /* ================= لوحة المفاتيح ================= */
  function newPayment() {
    var v = A.state.page === 'cust' && A.currentView && A.currentView().selected ? A.currentView().selected() : null;
    if (v) { F.pay(v.id); return; }
    F.pick(function (c) { F.pay(c.id); }, 'تسديد — اختر العميل');
  }
  A.newPayment = newPayment;
  document.addEventListener('keydown', function (e) {
    if (!A.ready) return;
    var k = e.key, ctrl = e.ctrlKey || e.metaKey, top = A.topDialog();
    if (k === 'Escape') { if (A.closeTop()) e.preventDefault(); return; }
    if (top) {
      // Enter يحفظ النموذج (إلا داخل نص متعدد الأسطر أو على زر)
      // نتجاهل الضغطة التي فتحت النافذة نفسها حتى لا تحفظها فوراً
      if (e === top.openEv) return;
      if (k === 'Enter' && !e.shiftKey && top.onEnter && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'BUTTON' && e.target.tagName !== 'SELECT') { e.preventDefault(); top.onEnter(); }
      if (ctrl && (k === 'p' || k === 'P')) e.preventDefault();
      return;
    }
    if (!ctrl) return;
    var key = Core.toEn(k).toLowerCase(), code = e.code;
    if (key === 'n' || code === 'KeyN') { e.preventDefault(); F.customer(null, function (c) { A.openCustomer(c.id); }); }
    else if (key === 'p' || code === 'KeyP') { e.preventDefault(); newPayment(); }
    else if (key === 'f' || code === 'KeyF') {
      e.preventDefault();
      if (A.state.page !== 'cust' && A.state.page !== 'rec') A.go('cust');
      var cv = A.currentView(); if (cv && cv.focusSearch) cv.focusSearch();
    }
    else if (/^[1-5]$/.test(key) || /^Digit[1-5]$/.test(code)) { e.preventDefault(); A.go(['home', 'cust', 'rec', 'rep', 'set'][+(key.match(/[1-5]/) || code.slice(-1))[0] - 1]); }
  });

  A.boot = function () { A.go('home'); };
})();
