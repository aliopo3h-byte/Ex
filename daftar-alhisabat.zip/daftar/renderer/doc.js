/* الوصل وكشف الحساب يُرسمان صورةً بعرض الورق بالنقاط، ثم يُحوَّلان لأبيض وأسود صرف (عتبة 170). منقول من تطبيق الهاتف. */
(function (root) {
  'use strict';
  var Core = root.Core;
  var DF = '"Noto Sans Arabic","Segoe UI",Tahoma,"DejaVu Sans",Arial,sans-serif';
  var MAX_H = 6000;

  // الشعار يُحمَّل مرة عند فتح التطبيق؛ data: لا يلوّث الـ canvas
  var logo = null;
  if (root.LOGO_SRC) { logo = new Image(); logo.src = root.LOGO_SRC; }
  function logoReady() { return !!(logo && logo.complete && logo.naturalWidth); }

  function wrapLines(x, text, maxW) {
    var words = String(text).split(/\s+/), lines = [], cur = '';
    words.forEach(function (w) {
      var t = cur ? cur + ' ' + w : w;
      if (cur && x.measureText(t).width > maxW) { lines.push(cur); cur = w; } else cur = t;
    });
    if (cur) lines.push(cur);
    return lines;
  }
  function Doc(cfg, width) {
    this.cfg = cfg; this.W = width || +cfg.pw || 384; this.P = Math.round(this.W * 0.05); this.CW = this.W - this.P * 2;
    this.cv = document.createElement('canvas'); this.cv.width = this.W; this.cv.height = MAX_H;
    this.x = this.cv.getContext('2d', { willReadFrequently: true }); this.x.fillStyle = '#fff'; this.x.fillRect(0, 0, this.W, MAX_H);
    this.x.fillStyle = '#000'; this.x.strokeStyle = '#000'; this.y = this.P;
    this.k = this.W / 384; // نكبّر الخطوط مع عرض 80 ملم
  }
  Doc.prototype.font = function (sz, bold) { this.x.font = (bold ? '700 ' : '500 ') + Math.round(sz * this.k) + 'px ' + DF; };
  Doc.prototype.text = function (txt, sz, bold, align) {
    var x = this.x, self = this, lh = Math.round(sz * this.k * 1.5);
    this.font(sz, bold); x.direction = 'rtl'; x.textBaseline = 'top'; x.textAlign = align || 'right';
    var ax = align === 'center' ? this.W / 2 : this.W - this.P;
    wrapLines(x, txt, this.CW).forEach(function (ln) { x.fillText(ln, ax, self.y); self.y += lh; });
  };
  Doc.prototype.row = function (right, left, sz, bold) {
    var x = this.x; this.font(sz, bold); x.textBaseline = 'top';
    x.direction = 'ltr'; var lw = x.measureText(left).width;
    var r = String(right), maxR = this.CW - lw - 12;
    x.direction = 'rtl';
    if (x.measureText(r).width > maxR) { while (r.length > 1 && x.measureText(r + '…').width > maxR) r = r.slice(0, -1); r += '…'; }
    x.textAlign = 'right'; x.fillText(r, this.W - this.P, this.y);
    x.direction = 'ltr'; x.textAlign = 'left'; x.fillText(left, this.P, this.y);
    this.y += Math.round(sz * this.k * 1.5);
  };
  Doc.prototype.rule = function (dash) {
    var x = this.x; this.y += 6; x.save(); x.lineWidth = 2; if (dash) x.setLineDash([6, 5]);
    x.beginPath(); x.moveTo(this.P, this.y); x.lineTo(this.W - this.P, this.y); x.stroke(); x.restore(); this.y += 14;
  };
  Doc.prototype.gap = function (n) { this.y += Math.round(n * this.k); };
  Doc.prototype.box = function (label, value) {
    var x = this.x, by = this.y, bh = Math.round(118 * this.k), sz = 46;
    x.lineWidth = 3; x.strokeRect(this.P, by, this.CW, bh);
    this.font(20, false); x.direction = 'rtl'; x.textAlign = 'center'; x.textBaseline = 'top'; x.fillText(label, this.W / 2, by + Math.round(10 * this.k));
    this.font(sz, true);
    while (sz > 20 && x.measureText(value).width > this.CW - 24) { sz -= 2; this.font(sz, true); }
    x.fillText(value, this.W / 2, by + Math.round(48 * this.k)); this.y = by + bh + 14;
  };
  Doc.prototype.header = function (title) {
    var shop = String(this.cfg.shop || '').trim(), ph = String(this.cfg.shopph || '').trim();
    this.logo();
    if (shop) this.text(shop, 30, true, 'center');
    if (ph) this.text('هاتف: ' + ph, 20, false, 'center');
    if (shop || ph) this.rule(true);
    this.gap(2); this.text(title, 36, true, 'center'); this.rule(false);
  };
  Doc.prototype.logo = function () {
    if (!logoReady()) return;
    var w = Math.round(Math.min(this.CW, 250 * this.k)), hh = Math.round(w * logo.naturalHeight / logo.naturalWidth);
    this.x.imageSmoothingEnabled = true; this.x.drawImage(logo, Math.round((this.W - w) / 2), this.y, w, hh);
    this.y += hh + Math.round(8 * this.k);
  };
  // «العنوان: القيمة» مع التفاف الأسطر الطويلة
  Doc.prototype.field = function (label, value, sz, bold) {
    if (!String(value || '').trim()) return;
    this.text(label + ': ' + value, sz || 22, !!bold);
  };
  Doc.prototype.footer = function () {
    var foot = String(this.cfg.foot || '').trim();
    if (foot) { this.gap(8); this.text(foot, 20, false, 'center'); }
    this.gap(36);
  };
  // نسخة أبيض وأسود صرف بارتفاع ما رُسم فقط
  Doc.prototype.finish = function () {
    if (this.out) return this.out;
    var W = this.W, H = Math.min(this.y, MAX_H), out = document.createElement('canvas');
    out.width = W; out.height = H;
    var oc = out.getContext('2d', { willReadFrequently: true }); oc.drawImage(this.cv, 0, 0);
    var id = oc.getImageData(0, 0, W, H), d = id.data;
    for (var q = 0; q < d.length; q += 4) {
      var v = (d[q] * 0.3 + d[q + 1] * 0.59 + d[q + 2] * 0.11) < 170 ? 0 : 255;
      d[q] = d[q + 1] = d[q + 2] = v; d[q + 3] = 255;
    }
    oc.putImageData(id, 0, 0);
    this.out = out; return out;
  };
  Doc.prototype.png = function () { return this.finish().toDataURL('image/png'); };
  // صفوف معبّأة لـ ESC/POS: البت 7 = أقصى اليسار
  Doc.prototype.packedMsb = function () {
    var c = this.finish(), W = c.width, H = c.height, bpr = Math.ceil(W / 8), d = c.getContext('2d').getImageData(0, 0, W, H).data, out = new Uint8Array(bpr * H);
    for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) if (d[(y * W + x) * 4] < 128) out[y * bpr + (x >> 3)] |= 0x80 >> (x & 7);
    return { bits: out, width: W, height: H };
  };

  function receiptDoc(L, p, width) {
    var c = L.db.customers[p.cid] || { name: '—', phone: '' }, d = new Doc(L.db.cfg, width);
    d.header('سند قبض');
    d.text('رقم السند: ' + L.recNo(p), 24, true);
    d.text('التاريخ: ' + p.d + '   ' + Core.hm(p.ts), 22, false);
    d.rule(true);
    d.text('استلمنا من السيد/ة:', 20, false);
    d.text(c.name || '—', 28, true);
    if (c.phone) d.text('الهاتف: ' + c.phone, 22, false);
    d.gap(10);
    d.box('المبلغ المستلم', Core.money(p.amt) + L.curTxt());
    d.text('طريقة الدفع: ' + Core.methodName(p.m), 22, false);
    if (p.t) d.text('ملاحظة: ' + p.t, 22, false);
    if (p.after != null) d.text(L.afterText(p.after), 22, true);
    if (p.void) d.text('*** سند ملغى ***', 26, true, 'center');
    d.rule(true);
    d.text('المستلم: ____________________', 22, false);
    d.footer();
    return d;
  }
  function statementDoc(L, c, width) {
    var a = L.acct(c.id), d = new Doc(L.db.cfg, width), mv = L.movements(c.id).slice(-22), cur = L.curTxt();
    d.header('كشف حساب');
    d.text(c.name, 28, true);
    if (c.phone) d.text('الهاتف: ' + c.phone, 22, false);
    d.text('بتاريخ: ' + Core.today(), 20, false);
    d.rule(true);
    d.row('إجمالي المستحقات', Core.money(a.total), 22, false);
    d.row('إجمالي المسدَّد', Core.money(a.paid), 22, false);
    d.row(a.bal >= 0 ? 'المتبقي' : 'رصيد لكم', Core.money(Math.abs(a.bal)) + cur, 26, true);
    if (a.overdue > 0.004) d.row('منها متأخر', Core.money(a.overdue), 22, true);
    d.rule(true);
    if (mv.length) {
      d.text('آخر الحركات', 22, true);
      mv.forEach(function (m) { d.row(m.d.slice(2) + ' ' + m.t, (m.a < 0 ? '-' : '+') + Core.money(Math.abs(m.a)), 20, false); });
    } else d.text('لا توجد حركات.', 20, false);
    d.footer();
    return d;
  }
  // وصل من رسالة ملصوقة: مضغوط، بلا تحية ولا أسطر دعائية؛ الحقول الفارغة تُحذف
  function messageDoc(cfg, m, width) {
    var d = new Doc(cfg, width), x = d.x, k = d.k, has = function (v) { return !!String(v == null ? '' : v).trim(); };
    var cur = String(cfg.curr || '').trim() || 'دينار';
    // أرقام مجردة تُنسَّق بفواصل وتأخذ العملة؛ النص الجاهز («35,000 دينار») يبقى كما هو
    var money = function (v) { v = String(v).trim(); return /^[\d,]+(\.\d+)?$/.test(v) ? Core.money(+v.replace(/,/g, '')) + ' ' + cur : v; };
    var rowN = function (label, value, sz, bold) { if (has(value)) d.row(label, String(value).trim(), sz, bold); };
    var line = function (label, value, sz, bold) { if (has(value)) d.text(label + ': ' + String(value).trim(), sz, bold); };
    // رأس صغير: شعار، المحل إن وُجد، العنوان، التاريخ
    d.logo();
    if (has(cfg.shop)) d.text(String(cfg.shop).trim(), 22, true, 'center');
    d.text(m.kind === 'activate' ? 'وصل تفعيل اشتراك' : 'وصل استلام', 26, true, 'center');
    d.text(Core.today() + '   ' + Core.hm(Date.now()), 16, false, 'center');
    d.rule(false);
    line('الاسم', m.name, 24, true);
    line('اليوزر', m.user, 20, false);
    line('الفئة', m.sub, 20, false);
    line('البطاقة', m.scratch, 20, false);
    line('الهاتف', m.phone, 20, false);
    // المبالغ داخل إطار واحد
    var amts = [['مبلغ الاشتراك', m.total, 20, false], ['المستلم', m.amount, 26, true], ['من أصل', m.total && m.kind !== 'activate' ? m.total : '', 20, false], ['المتبقي', m.remain, 26, true]]
      .filter(function (r) { return has(r[1]); });
    if (m.kind === 'activate') amts = amts.filter(function (r) { return r[0] !== 'من أصل'; }); else amts = amts.filter(function (r) { return r[0] !== 'مبلغ الاشتراك'; });
    if (amts.length) {
      d.gap(4); var by = d.y; d.y += Math.round(4 * k);
      amts.forEach(function (r) { d.row(r[0], money(r[1]), r[2], r[3]); });
      x.lineWidth = 2; x.strokeRect(d.P - 4, by, d.CW + 8, d.y - by + Math.round(2 * k)); d.y += Math.round(8 * k);
    }
    if (has(m.expiry)) d.row('ينتهي الاشتراك', String(m.expiry).trim(), 20, true);
    if (has(m.date)) d.row('التاريخ', String(m.date).trim(), 18, false);
    if (has(m.status)) d.text(String(m.status).trim(), 22, true, 'center');
    line('الموظف', m.emp, 20, false);
    (m.notes || []).forEach(function (n) { if (has(n)) d.text(String(n).trim(), 18, false); });
    // معلومات المكتب بخط صغير
    if (has(m.addr) || has(m.inq) || has(m.collector)) {
      d.rule(true);
      line('العنوان', m.addr, 18, false);
      rowN('للاستفسار', m.inq, 18, false);
      rowN('مندوب الجباية', m.collector, 18, false);
    }
    if (has(m.card) || has(m.holder)) {
      d.rule(true);
      d.text('للتحويل (كي كارد)', 18, true, 'center');
      if (has(m.holder)) { d.font(20, true); x.direction = 'ltr'; x.textAlign = 'center'; x.textBaseline = 'top'; x.fillText(String(m.holder).trim(), d.W / 2, d.y); d.y += Math.round(20 * k * 1.4); }
      if (has(m.card)) {
        var sz = 26; d.font(sz, true); x.direction = 'ltr'; x.textAlign = 'center'; x.textBaseline = 'top';
        while (sz > 14 && x.measureText(m.card).width > d.CW) { sz -= 2; d.font(sz, true); }
        x.fillText(String(m.card).trim(), d.W / 2, d.y); d.y += Math.round(sz * k * 1.4);
      }
    }
    d.gap(30);
    return d;
  }
  function testDoc(cfg, width, label) {
    var d = new Doc(cfg, width);
    d.header('طباعة تجريبية');
    d.text('إذا قرأت هذا فالطابعة تعمل.', 24, true, 'center');
    d.text(Core.today() + '   ' + Core.hm(Date.now()), 20, false, 'center');
    d.rule(true);
    d.row('الطابعة', String(label || '—'), 22, false);
    d.row('عرض الورق', String(d.W) + ' نقطة', 22, false);
    d.row('أرقام', '0123456789', 22, false);
    d.rule(false); d.gap(4);
    for (var i = 0; i < 4; i++) { d.x.fillRect(d.P + i * 40, d.y, 20 + i * 6, 14); d.y += 18; }
    d.footer();
    return d;
  }

  root.Docs = { Doc: Doc, receiptDoc: receiptDoc, messageDoc: messageDoc, statementDoc: statementDoc, testDoc: testDoc };
})(window);
