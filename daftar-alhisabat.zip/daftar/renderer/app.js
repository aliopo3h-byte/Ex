/* دفتر الحسابات — واجهة سطح المكتب */
(function () {
  'use strict';
  var api = window.api, Core = window.Core, Docs = window.Docs, BT = window.BT;
  var money = Core.money, today = Core.today, r2 = Core.r2;
  var L = null, local = {}, info = {};

  /* ================= أدوات ================= */
  function $(id) { return document.getElementById(id); }
  function add(e, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { add(e, x); }); return; }
    e.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c)));
  }
  // اتجاه النص المختلط: الأرقام مع كلمات عربية (مثل «215,000 دينار») تُعرض من اليمين لليسار،
  // والتواريخ داخل جملة عربية تُعزل LTR حتى لا تنقلب إلى 15-11-2026
  var AR = /[\u0600-\u06FF]/, DT = /(\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?)/;
  function setText(e, v) {
    v = String(v);
    if (!AR.test(v)) { e.textContent = v; return; }
    if (/(^| )num( |$)/.test(e.className)) e.classList.add('ar');
    if (!DT.test(v)) { e.textContent = v; return; }
    v.split(DT).forEach(function (part, i) {
      if (!part) return;
      if (i % 2) { var sp = document.createElement('span'); sp.className = 'ltr'; sp.textContent = part; e.appendChild(sp); }
      else e.appendChild(document.createTextNode(part));
    });
  }
  function h(tag, attrs) {
    var e = document.createElement(tag);
    if (attrs && attrs['class']) e.className = attrs['class'];
    if (attrs) for (var k in attrs) {
      var v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'text') setText(e, v);
      else if (k === 'style') Object.assign(e.style, v);
      else if (k === 'value') e.value = v;
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v);
      else if (v === true) e.setAttribute(k, '');
      else e.setAttribute(k, v);
    }
    for (var i = 2; i < arguments.length; i++) add(e, arguments[i]);
    return e;
  }
  var ICONS = {
    home: 'M3 11l9-8 9 8M5 10v10h14V10', users: 'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM2 21c0-4 3-6 7-6s7 2 7 6M17 4a4 4 0 0 1 0 7M19 15c2 1 3 3 3 6',
    receipt: 'M6 3h12v18l-3-2-3 2-3-2-3 2V3zM9 8h6M9 12h6', chart: 'M5 20v-8M12 20V5M19 20v-5', gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9L7 7M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1',
    plus: 'M12 5v14M5 12h14', search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-4.3-4.3', wa: 'M21 12a8.5 8.5 0 0 1-12.6 7.4L3 21l1.7-5.2A8.5 8.5 0 1 1 21 12z',
    close: 'M6 6l12 12M18 6L6 18', edit: 'M4 20h4L19 9l-4-4L4 16v4zM13.5 6.5l4 4', print: 'M7 9V3h10v6M7 17H4v-7h16v7h-3M7 14h10v7H7z',
    doc: 'M7 3h7l5 5v13H7zM14 3v5h5M10 13h6M10 17h6', upload: 'M12 16V4M8 8l4-4 4 4M5 14v6h14v-6', download: 'M12 4v12M8 12l4 4 4-4M5 20h14',
    archive: 'M3 4h18v4H3zM5 8v12h14V8M10 12h4', copy: 'M9 9h11v11H9zM5 15H4V4h11v1', image: 'M4 5h16v14H4zM8 11a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM20 16l-5-5-9 8',
    folder: 'M3 6h6l2 2h10v11H3z', undo: 'M9 14L4 9l5-5M4 9h11a5 5 0 0 1 0 10h-3', ban: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM5.6 5.6l12.8 12.8', bt: 'M7 7l10 10-5 5V2l5 5L7 17'
  };
  function ic(name) {
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true');
    var p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); p.setAttribute('d', ICONS[name] || ''); s.appendChild(p);
    var w = h('span', { class: 'ic' }); w.appendChild(s); return w;
  }
  var toastT = null;
  function toast(msg, bad, ms) {
    var t = $('toast'); t.textContent = msg; t.className = 'toast' + (bad ? ' bad' : ''); t.hidden = false;
    clearTimeout(toastT); toastT = setTimeout(function () { t.hidden = true; }, ms || (bad ? 6000 : 3000));
  }
  // الأزرار الخطرة تطلب ضغطتين: الأولى تغيّر النص، والثانية تؤكد
  function armed(btn, label, fn) {
    var base = null, t = null, on = false;
    btn.addEventListener('click', function () {
      if (on) { clearTimeout(t); on = false; btn.textContent = base; fn(); return; }
      base = btn.textContent; on = true; btn.textContent = label;
      t = setTimeout(function () { on = false; btn.textContent = base; }, 3500);
    });
    return btn;
  }
  function cur() { return L.curTxt(); }
  function fld(label, input, hint) { return h('label', { class: 'fld' }, h('span', { text: label }), input, hint ? h('small', { text: hint }) : null); }
  function inp(attrs) { return h('input', Object.assign({ type: 'text', autocomplete: 'off', spellcheck: 'false' }, attrs || {})); }
  function seg(opts, val, on) {
    var wrap = h('div', { class: 'seg', role: 'group' });
    opts.forEach(function (o) {
      var b = h('button', { type: 'button', 'aria-pressed': o[0] === val ? 'true' : 'false', text: o[1] });
      b.addEventListener('click', function () { val = o[0]; Array.prototype.forEach.call(wrap.children, function (c) { c.setAttribute('aria-pressed', c === b ? 'true' : 'false'); }); on(val); });
      wrap.appendChild(b);
    });
    return wrap;
  }
  function chips(opts, val, on, counts) {
    var wrap = h('div', { class: 'chips', role: 'group' });
    opts.forEach(function (o) {
      var b = h('button', { type: 'button', class: 'chip', 'aria-pressed': o[0] === val ? 'true' : 'false' }, o[1], counts ? h('b', { class: 'num', text: String(counts[o[0]] || 0) }) : null);
      b.addEventListener('click', function () { on(o[0]); });
      wrap.appendChild(b);
    });
    return wrap;
  }
  function avatar(c) {
    var hue = 0, n = c.name || '؟';
    for (var i = 0; i < n.length; i++) hue = (hue * 31 + n.charCodeAt(i)) % 360;
    return h('div', { class: 'av', style: { background: 'linear-gradient(135deg,hsl(' + hue + ' 45% 42%),hsl(' + ((hue + 30) % 360) + ' 45% 30%))' }, text: Array.from(n)[0] });
  }
  function balInfo(a) {
    if (a.bal > 0.004) { var late = a.overdue > 0.004; return { cls: late ? 'bad' : 'warn', txt: money(a.bal), sub: late ? 'متأخر ' + a.maxLate + ' يوم' : (a.next ? 'يستحق ' + a.next.due : 'عليه') }; }
    if (a.bal < -0.004) return { cls: 'info', txt: money(-a.bal), sub: 'رصيد له' };
    return { cls: 'good', txt: a.total ? 'مسدّد' : '—', sub: a.total ? 'مسدّد بالكامل' : 'لا مستحقات' };
  }
  function relDays(d) { var n = Core.dayDiff(d, today()); return n === 0 ? 'اليوم' : n === 1 ? 'غداً' : n === -1 ? 'أمس' : n > 0 ? 'بعد ' + n + ' يوم' : 'منذ ' + (-n) + ' يوم'; }
  function guard(fn) { return function () { try { var r = fn.apply(this, arguments); if (r && r.catch) r.catch(fail); return r; } catch (e) { fail(e); } }; }
  function fail(e) { console.error(e); toast((e && e.message) || 'حدث خطأ غير متوقع.', true); }

  /* ================= الحفظ ================= */
  var saveT = null, saving = false, pending = false;
  function scheduleSave() { pending = true; clearTimeout(saveT); saveT = setTimeout(saveNow, 250); }
  function saveNow() {
    clearTimeout(saveT); saveT = null;
    if (!pending) return;
    if (saving) { saveT = setTimeout(saveNow, 100); return; }
    pending = false; saving = true;
    L.db.meta.saved = Date.now();
    api.saveDb(JSON.stringify(L.db)).then(function (r) {
      saving = false;
      if (!r.ok) { pending = true; toast('لم تُحفظ آخر التعديلات: ' + r.error, true, 8000); }
    }, function () { saving = false; pending = true; toast('تعذّر الحفظ.', true); });
  }
  window.addEventListener('beforeunload', function () {
    if (pending || saving) { L.db.meta.saved = Date.now(); try { api.saveDbSync(JSON.stringify(L.db)); } catch (e) { /* */ } }
  });

  /* ================= نوافذ الحوار ================= */
  var dialogs = [];
  // الضغطة الجارية الآن (مرحلة الالتقاط تسبق كل المعالجات)، لنعرف أي ضغطة فتحت النافذة
  var curKey = null;
  document.addEventListener('keydown', function (e) { curKey = e; setTimeout(function () { if (curKey === e) curKey = null; }, 0); }, true);
  // opts: { title, wide, build(body, close, dlg), primary: {label, fn, cls}, secondary: [...] }
  function openDialog(opts) {
    var layer = h('div', { class: 'layer' }), dlg = h('div', { class: 'dialog' + (opts.wide ? ' wide' : ''), role: 'dialog', 'aria-modal': 'true', 'aria-label': opts.title });
    var body = h('div', { class: 'body' }), entry = { layer: layer, dlg: dlg, onclose: opts.onclose, prevFocus: document.activeElement, onEnter: null, openEv: curKey };
    var close = function () { closeDialog(entry); };
    dlg.appendChild(h('header', null, h('h2', { text: opts.title }), h('button', { class: 'btn ghost icon', type: 'button', 'aria-label': 'إغلاق (Esc)', title: 'إغلاق (Esc)', onclick: close }, ic('close'))));
    dlg.appendChild(body);
    if (opts.primary) {
      var pb = h('button', { class: 'btn ' + (opts.primary.cls || ''), type: 'button', text: opts.primary.label });
      pb.addEventListener('click', guard(function () { opts.primary.fn(close, pb); }));
      entry.onEnter = function () { pb.click(); };
      dlg.appendChild(h('footer', null, pb, h('button', { class: 'btn ghost', type: 'button', text: 'إلغاء', onclick: close })));
    }
    layer.addEventListener('mousedown', function (e) { if (e.target === layer) close(); });
    layer.appendChild(dlg); $('layers').appendChild(layer); dialogs.push(entry);
    opts.build(body, close, entry);
    setTimeout(function () { var f = dlg.querySelector('[autofocus]') || dlg.querySelector('.body input, .body select, .body textarea, .body button'); if (f) f.focus(); }, 30);
    return entry;
  }
  function closeDialog(e) {
    var i = dialogs.indexOf(e); if (i < 0) return;
    dialogs.splice(i, 1); e.layer.remove(); if (e.onclose) e.onclose();
    if (e.prevFocus && document.contains(e.prevFocus)) try { e.prevFocus.focus(); } catch (x) { /* */ }
  }
  function closeTop() { if (!dialogs.length) return false; closeDialog(dialogs[dialogs.length - 1]); return true; }
  function closeAll() { while (dialogs.length) closeDialog(dialogs[dialogs.length - 1]); }
  function topDialog() { return dialogs[dialogs.length - 1] || null; }

  /* ================= جدول بتمرير افتراضي ================= */
  // يعرض فقط الصفوف الظاهرة، فيبقى سريعاً مع آلاف الصفوف
  function VTable(o) {
    var self = this;
    this.o = o; this.items = []; this.sel = -1; this.rowH = o.rowH || 50;
    this.el = h('div', { class: 'table', style: { '--cols': o.cols, '--rh': this.rowH + 'px' } });
    this.el.style.setProperty('--cols', o.cols); this.el.style.setProperty('--rh', this.rowH + 'px');
    this.head = h('div', { class: 'thead' }, o.head.map(function (x) { return h('div', { class: x[1] || '', text: x[0] }); }));
    this.body = h('div', { class: 'vbody', tabindex: '0', role: 'listbox', 'aria-label': o.label || '' });
    this.space = h('div', { class: 'vspace' });
    this.foot = h('div', { class: 'tfoot' });
    this.body.appendChild(this.space);
    this.el.appendChild(this.head); this.el.appendChild(this.body); if (o.foot !== false) this.el.appendChild(this.foot);
    this.empty = h('div', { class: 'empty' });
    var raf = 0;
    this.body.addEventListener('scroll', function () { if (!raf) raf = requestAnimationFrame(function () { raf = 0; self.draw(); }); });
    if (window.ResizeObserver) new ResizeObserver(function () { self.draw(); }).observe(this.body);
    this.body.addEventListener('keydown', function (e) { self.key(e); });
  }
  VTable.prototype.setItems = function (items, emptyNode) {
    this.items = items; this.space.style.height = (items.length * this.rowH) + 'px';
    if (this.sel >= items.length) this.sel = items.length - 1;
    this.empty.remove();
    if (!items.length && emptyNode) { this.empty.innerHTML = ''; add(this.empty, emptyNode); this.body.appendChild(this.empty); }
    this.draw();
  };
  VTable.prototype.draw = function () {
    var b = this.body, rh = this.rowH, n = this.items.length, self = this;
    var start = Math.max(0, Math.floor(b.scrollTop / rh) - 4), end = Math.min(n, Math.ceil((b.scrollTop + (b.clientHeight || 600)) / rh) + 4);
    var fr = document.createDocumentFragment();
    for (var i = start; i < end; i++) (function (i) {
      var row = h('div', { class: 'trow' + (i === self.sel ? ' on' : ''), role: 'option', 'aria-selected': i === self.sel ? 'true' : 'false', style: { top: (i * rh) + 'px' } });
      self.o.render(self.items[i], row, i);
      row.addEventListener('click', function (e) { if (e.target.closest('button')) return; self.select(i, false); if (self.o.onOpen && self.o.openOnClick) self.o.onOpen(self.items[i], i); });
      row.addEventListener('dblclick', function (e) { if (e.target.closest('button')) return; if (self.o.onOpen) self.o.onOpen(self.items[i], i); });
      fr.appendChild(row);
    })(i);
    this.space.innerHTML = ''; this.space.appendChild(fr);
  };
  VTable.prototype.select = function (i, scroll) {
    if (!this.items.length) return;
    i = Math.max(0, Math.min(this.items.length - 1, i)); this.sel = i;
    if (scroll !== false) {
      var top = i * this.rowH, b = this.body;
      if (top < b.scrollTop) b.scrollTop = top; else if (top + this.rowH > b.scrollTop + b.clientHeight) b.scrollTop = top + this.rowH - b.clientHeight;
    }
    this.draw();
    if (this.o.onSelect) this.o.onSelect(this.items[i], i);
  };
  VTable.prototype.key = function (e) {
    var page = Math.max(1, Math.floor(this.body.clientHeight / this.rowH) - 1), k = e.key;
    if (k === 'ArrowDown') this.select(this.sel + 1);
    else if (k === 'ArrowUp') this.select(this.sel - 1);
    else if (k === 'PageDown') this.select(this.sel + page);
    else if (k === 'PageUp') this.select(this.sel - page);
    else if (k === 'Home') this.select(0);
    else if (k === 'End') this.select(this.items.length - 1);
    else if (k === 'Enter' && this.sel >= 0 && this.o.onOpen) this.o.onOpen(this.items[this.sel], this.sel);
    else return;
    e.preventDefault();
  };
  // قوائم قصيرة تُبنى على دفعات
  function chunked(box, items, make, first) {
    var made = 0, more = null;
    function fillTo(n) { var fr = document.createDocumentFragment(); n = Math.min(n, items.length); while (made < n) fr.appendChild(make(items[made++])); if (more) box.insertBefore(fr, more); else box.appendChild(fr); }
    fillTo(first || 50);
    if (made < items.length) {
      more = h('button', { class: 'btn ghost sm', type: 'button', style: { margin: '10px auto 0', display: 'flex' } });
      var upd = function () { more.textContent = 'عرض المزيد (' + (items.length - made) + ')'; };
      more.addEventListener('click', function () { fillTo(made + 100); if (made >= items.length) more.remove(); else upd(); });
      upd(); box.appendChild(more);
    }
  }

  /* ================= الطباعة ================= */
  var printing = false;
  // make(width) يعيد Doc. الطريقة حسب الإعداد: طابعة Windows، أو بلوتوث، أو ESC/POS بالشبكة
  async function printDoc(make, opts) {
    opts = opts || {};
    if (printing) { toast('الطباعة جارية، انتظر قليلاً.'); return false; }
    printing = true;
    try {
      var via = local.printVia || 'windows', r;
      if (via === 'bt') {
        if (!BT.name()) { toast('اختر طابعة البلوتوث من الإعدادات أولاً (تُختار مرة في كل تشغيل).', true); return false; }
        toast('جارٍ الإرسال إلى ' + BT.name() + '…', false, 15000);
        await BT.print(make(384).finish(), local.btDensity || 'normal');
        toast('تمت الطباعة.'); return true;
      }
      var d = make(+L.db.cfg.pw || 384);
      if (via === 'escpos') {
        var pk = d.packedMsb(); r = await api.printEscpos(pk.bits, pk.width, pk.height);
      } else {
        var cv = d.finish();
        r = await api.printImage({ dataUrl: cv.toDataURL('image/png'), width: cv.width, height: cv.height, deviceName: local.printerName || '', paper: local.paper || 'roll', silent: !!local.printerName && opts.dialog !== true });
      }
      if (r.ok) { toast('أُرسل للطباعة.'); return true; }
      if (!r.cancelled) toast(r.error, true);
      return false;
    } catch (e) { fail(e); return false; } finally { printing = false; }
  }

  /* ================= الهيكل والتنقل ================= */
  var PAGES = [['home', 'الرئيسية', 'home', 'Ctrl+1'], ['cust', 'العملاء', 'users', 'Ctrl+2'], ['rec', 'السندات', 'receipt', 'Ctrl+3'], ['rep', 'التقارير', 'chart', 'Ctrl+4'], ['set', 'الإعدادات', 'gear', 'Ctrl+5']];
  var state = { page: 'home', cust: { q: '', f: 'all', s: 'name', sel: null, tab: 'ch' }, rec: { range: 'today', q: '' }, rep: { range: 'month' } };
  var view = null; // { refresh() }

  function buildNav() {
    var n = $('nav'); n.innerHTML = '';
    PAGES.forEach(function (p) { n.appendChild(h('button', { type: 'button', 'data-p': p[0], onclick: function () { closeAll(); go(p[0]); } }, ic(p[2]), h('span', { text: p[1] }), h('kbd', { text: p[3] }))); });
  }
  function paintNav() { Array.prototype.forEach.call($('nav').children, function (b) { if (b.getAttribute('data-p') === state.page) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); }); }
  function paintTally() {
    var t = L.totals(), el = $('tally'), lb = L.db.meta.lastBackup, old = !lb || Date.now() - lb > 7 * 86400000;
    el.innerHTML = '';
    add(el, [h('small', { text: 'المحصَّل اليوم' }), h('b', { class: 'num', text: money(t.today) + cur() }), h('i', { text: t.todayN + ' سند • الشهر ' + money(t.month) }),
      h('div', { class: 'bk' }, h('span', { class: 'dot' + (old ? ' old' : '') }), h('span', { text: lb ? 'آخر نسخة احتياطية ' + relDays(Core.iso(new Date(lb))) : 'لا توجد نسخة احتياطية بعد' }))]);
  }
  function setTop(title, acts) { $('title').textContent = title; var a = $('topacts'); a.innerHTML = ''; add(a, acts || []); }
  function go(p, opts) {
    state.page = p; paintNav();
    var page = $('page'); page.innerHTML = ''; page.className = 'page'; page.scrollTop = 0;
    view = (VIEWS[p] || VIEWS.home)(page, opts || {});
    paintTally();
  }
  // بعد أي تعديل: نحدّث الشاشة الحالية دون فقدان البحث أو التحديد
  function refresh() { if (view && view.refresh) view.refresh(); else go(state.page); paintTally(); }

  var VIEWS = {};
  window.__app = { get L() { return L; }, go: go, currentView: function () { return view; }, refresh: refresh, VIEWS: VIEWS, h: h, ic: ic, toast: toast, armed: armed, openDialog: openDialog, closeAll: closeAll, closeTop: closeTop, topDialog: topDialog,
    fld: fld, inp: inp, seg: seg, chips: chips, avatar: avatar, balInfo: balInfo, relDays: relDays, guard: guard, fail: fail, VTable: VTable, chunked: chunked, printDoc: printDoc,
    setTop: setTop, state: state, scheduleSave: scheduleSave, saveNow: saveNow, paintTally: paintTally, get local() { return local; }, set local(v) { local = v; }, get info() { return info; } };

  /* ================= البدء ================= */
  function applyTheme() {
    var t = L.db.cfg.theme || 'auto';
    if (t === 'auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme', t);
    try { api.setTheme(t); } catch (e) { /* */ }
  }
  window.__app.applyTheme = applyTheme;

  var lastDay = '';
  function tick() {
    var d = today();
    if (d === lastDay) return;
    lastDay = d; L.invalidate();
    if (L.genSubs()) toast('أُضيفت مستحقات الاشتراكات الشهرية.');
    if (!dialogs.length) refresh(); else paintTally();
  }

  // نبدأ بعد تحميل كل السكربتات (forms.js و views.js) حتى لا يسبقها رد التحميل
  function start() { return api.loadDb().then(function (r) {
    info = r; local = r.local || {};
    L = new Core.Ledger(r.db || Core.blank());
    L.onChange = scheduleSave;
    applyTheme(); buildNav();
    lastDay = today(); L.genSubs();
    window.__app.boot();
    window.__app.ready = true;
    if (r.recovered) toast('كان ملف البيانات تالفاً، فاستُعيدت آخر نسخة سليمة منه.', true, 9000);
    if (r.error) toast(r.error, true, 12000);
    setInterval(tick, 60000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) tick(); });
    api.onBackupDone(function (d) { L.db.meta.lastBackup = d.at; scheduleSave(); paintTally(); });
    api.onError(function (m) { toast(m, true, 9000); });
  }).catch(function (e) { document.body.textContent = 'تعذّر تشغيل التطبيق: ' + (e && e.message); }); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
