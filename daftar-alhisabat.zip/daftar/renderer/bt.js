/* طابعات البلوتوث الصغيرة «cat printer» عبر Web Bluetooth.
   الخدمة 0xAE30 أو 0xAF30، الكتابة على 0xAE01 بلا استجابة، والإشعارات على 0xAE02 (إيقاف/متابعة). */
(function (root) {
  'use strict';
  var Cat = root.Cat;
  var SERVICES = [0xAE30, 0xAF30];
  var CHUNK = 180;      // Web Bluetooth لا يكشف MTU؛ 180 بايتاً تناسب MTU الشائع (≥185) لهذه الطابعات
  var DELAY = 20;
  var state = { dev: null, write: null, paused: false, busy: false };
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

  function supported() { return !!(navigator.bluetooth && navigator.bluetooth.requestDevice); }

  // يجب استدعاؤها من نقرة المستخدم
  async function choose() {
    if (!supported()) throw new Error('البلوتوث غير متاح على هذا الجهاز.');
    var dev = await navigator.bluetooth.requestDevice({
      filters: [{ services: [SERVICES[0]] }, { services: [SERVICES[1]] }, { namePrefix: 'MX' }, { namePrefix: 'GB' }, { namePrefix: 'GT' }, { namePrefix: 'YT' }, { namePrefix: 'MXW' }],
      optionalServices: SERVICES
    });
    await disconnect();
    state.dev = dev;
    dev.addEventListener('gattserverdisconnected', function () { state.write = null; });
    await connect();
    return dev.name || 'طابعة بلوتوث';
  }
  async function connect() {
    if (!state.dev) throw new Error('اختر طابعة البلوتوث أولاً.');
    if (state.write && state.dev.gatt.connected) return;
    var server = await state.dev.gatt.connect(), svc = null;
    for (var i = 0; i < SERVICES.length && !svc; i++) { try { svc = await server.getPrimaryService(SERVICES[i]); } catch (e) { /* جرّب التالية */ } }
    if (!svc) throw new Error('هذه ليست طابعة مدعومة (لا توجد خدمة الطباعة).');
    state.write = await svc.getCharacteristic(0xAE01);
    try {
      var nt = await svc.getCharacteristic(0xAE02);
      await nt.startNotifications();
      nt.addEventListener('characteristicvaluechanged', function (e) {
        var v = new Uint8Array(e.target.value.buffer);
        if (Cat.isPause(v)) state.paused = true; else if (Cat.isResume(v)) state.paused = false;
      });
    } catch (e) { /* بعض الطرازات بلا إشعارات */ }
  }
  async function disconnect() { try { if (state.dev && state.dev.gatt.connected) state.dev.gatt.disconnect(); } catch (e) { /* */ } state.write = null; }

  // canvas بعرض 384 نقطة
  async function print(canvas, density, onProgress) {
    if (state.busy) throw new Error('الطباعة جارية، انتظر قليلاً.');
    state.busy = true;
    try {
      await connect();
      var data = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data;
      var bytes = Cat.stream(Cat.rowsFromRgba(data, canvas.width, canvas.height), density), parts = Cat.chunks(bytes, CHUNK);
      for (var i = 0; i < parts.length; i++) {
        var waited = 0;
        while (state.paused) { await sleep(50); waited += 50; if (waited > 15000) throw new Error('توقفت الطابعة عن الاستجابة (ربما نفد الورق أو البطارية).'); }
        var w = state.write;
        if (!w) throw new Error('انقطع الاتصال بالطابعة.');
        if (w.writeValueWithoutResponse) await w.writeValueWithoutResponse(parts[i]); else await w.writeValue(parts[i]);
        if (onProgress && i % 20 === 0) onProgress(i / parts.length);
        await sleep(DELAY);
      }
      return true;
    } finally { state.busy = false; }
  }
  function name() { return state.dev ? (state.dev.name || 'طابعة بلوتوث') : ''; }

  root.BT = { supported: supported, choose: choose, print: print, disconnect: disconnect, name: name };
})(window);
