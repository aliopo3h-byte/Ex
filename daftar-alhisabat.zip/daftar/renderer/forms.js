/* النماذج ونوافذ الحوار */
(function () {
  'use strict';
  var A = window.__app, api = window.api, Core = window.Core, Docs = window.Docs, BT = window.BT;
  var h = A.h, ic = A.ic, toast = A.toast, fld = A.fld, inp = A.inp, seg = A.seg, money = Core.money, today = Core.today;
  var F = A.forms = {};
  function L() { return A.L; }
  function cur() { return A.L.curTxt(); }
  function errLine() { return h('div', { class: 'errline', role: 'alert' }); }

  /* ---------- عميل ---------- */
  F.customer = function (c, after) {
    var name = inp({ value: c ? c.name : '', placeholder: 'الاسم الكامل', autofocus: true }), phone = inp({ value: c ? c.phone : '', placeholder: '07xx xxx xxxx', class: 'num', dir: 'ltr' });
    var note = h('textarea', { placeholder: 'عنوان، ملاحظة…' }); note.value = c ? c.note || '' : '';
    var err = errLine();
    A.openDialog({
      title: c ? 'تعديل بيانات العميل' : 'عميل جديد',
      build: function (b) { b.appendChild(fld('الاسم', name)); b.appendChild(fld('الهاتف', phone, 'الأرقام العربية مقبولة.')); b.appendChild(fld('ملاحظات', note)); b.appendChild(err); },
      primary: { label: 'حفظ العميل', fn: function (close) {
        var n = name.value.trim(); if (!n) { err.textContent = 'اكتب اسم العميل.'; name.focus(); return; }
        var dup = L().findDup(phone.value, c && c.id);
        if (dup) { err.textContent = 'هذا الرقم مسجّل للعميل «' + dup.name + '».'; phone.focus(); return; }
        if (c) { L().updateCustomer(c, n, phone.value, note.value); toast('حُفظت بيانات العميل.'); }
        else { c = L().addCustomer(n, phone.value, note.value); toast('أُضيف العميل.'); }
        close(); if (after) after(c); else A.refresh();
      } }
    });
  };

  /* ---------- مستحق جديد: دين، أقساط، اشتراك ---------- */
  F.charge = function (cid) {
    var td = today(), kind = 'debt', startSel = 'now';
    var amt = inp({ class: 'big num', placeholder: '0', inputmode: 'decimal', autofocus: true }), desc = inp({ placeholder: 'مثال: فاتورة، اشتراك إنترنت، قسط جهاز' });
    var due = inp({ type: 'date', value: td }), count = inp({ value: '6', class: 'num' }), first = inp({ type: 'date', value: Core.addMonthIso(td, 1, +td.slice(8)) });
    var day = inp({ value: String(Math.min(+td.slice(8), 28)), class: 'num' });
    var lab = h('span', { text: 'المبلغ' }), plan = h('div', { class: 'summary small' }), err = errLine();
    var gDebt = h('div', null, fld('تاريخ الاستحقاق', due)),
      gInst = h('div', { class: 'grid' }, h('div', { class: 'two' }, fld('عدد الأقساط (2-120)', count), fld('تاريخ أول قسط', first)), plan),
      gSub = h('div', { class: 'grid' }, fld('يوم الاستحقاق من كل شهر (1-31)', day, 'إن كان الشهر أقصر يُضبط لآخر يوم فيه.'), seg([['now', 'يبدأ هذا الشهر'], ['next', 'يبدأ الشهر القادم']], startSel, function (v) { startSel = v; }));
    function upd() {
      gDebt.hidden = kind !== 'debt'; gInst.hidden = kind !== 'inst'; gSub.hidden = kind !== 'sub';
      lab.textContent = kind === 'sub' ? 'المبلغ كل شهر' : kind === 'inst' ? 'المبلغ الإجمالي' : 'المبلغ';
      plan.innerHTML = '';
      var a = Core.parseAmt(amt.value), n = parseInt(Core.toEn(count.value), 10);
      if (kind === 'inst' && a && n >= 2 && n <= 120 && Core.isIsoDate(first.value)) {
        var parts = L().splitInstallments(a, n), d0 = +first.value.slice(8);
        var show = function (i) { return h('div', { class: 'kv' }, h('span', null, 'قسط ' + (i + 1) + '/' + n + ' — ', h('span', { class: 'ltr', text: Core.addMonthIso(first.value, i, d0) })), h('b', { class: 'num', text: money(parts[i]) })); };
        for (var i = 0; i < Math.min(n, 3); i++) plan.appendChild(show(i));
        if (n > 4) plan.appendChild(h('div', { class: 'kv muted', text: '…' }));
        if (n > 3) plan.appendChild(show(n - 1));
      } else plan.appendChild(h('span', { class: 'muted', text: 'سيظهر جدول الأقساط هنا.' }));
    }
    [amt, count, first].forEach(function (x) { x.addEventListener('input', upd); });
    A.openDialog({
      title: 'مستحق جديد — ' + (L().db.customers[cid] || {}).name,
      build: function (b) {
        b.appendChild(seg([['debt', 'دين / فاتورة'], ['inst', 'أقساط'], ['sub', 'اشتراك شهري']], kind, function (v) { kind = v; upd(); }));
        b.appendChild(h('label', { class: 'fld' }, lab, amt)); b.appendChild(gDebt); b.appendChild(gInst); b.appendChild(gSub); b.appendChild(fld('الوصف', desc)); b.appendChild(err); upd();
      },
      primary: { label: 'حفظ المستحق', fn: function (close) {
        var a = Core.parseAmt(amt.value); err.textContent = '';
        if (!a) { err.textContent = 'اكتب مبلغاً صحيحاً.'; amt.focus(); return; }
        if (kind === 'debt') {
          if (!Core.isIsoDate(due.value)) { err.textContent = 'اختر تاريخ الاستحقاق.'; return; }
          L().addCharge(cid, a, due.value, desc.value.trim(), { kind: 'debt' });
        } else if (kind === 'inst') {
          var n = parseInt(Core.toEn(count.value), 10);
          if (!(n >= 2 && n <= 120)) { err.textContent = 'عدد الأقساط بين 2 و120.'; count.focus(); return; }
          if (!Core.isIsoDate(first.value)) { err.textContent = 'اختر تاريخ أول قسط.'; return; }
          L().addInstallments(cid, a, n, first.value, desc.value.trim());
        } else {
          var dd = parseInt(Core.toEn(day.value), 10);
          if (!(dd >= 1 && dd <= 31)) { err.textContent = 'يوم الاستحقاق بين 1 و31.'; day.focus(); return; }
          var m = Core.ymOf(today()); if (startSel === 'next') m = Core.nextYm(m);
          L().addSub(cid, a, dd, m, desc.value.trim());
        }
        close(); toast('أُضيف المستحق.'); A.refresh();
      } }
    });
  };

  F.chargeEdit = function (it) {
    var c = it.c, amt = inp({ class: 'big num', value: String(c.amt) }), due = inp({ type: 'date', value: c.due }), desc = inp({ value: c.desc || '' }), err = errLine();
    A.openDialog({
      title: 'تفاصيل المستحق',
      build: function (b, close) {
        b.appendChild(h('div', { class: 'summary' },
          h('div', { class: 'kv' }, h('span', { text: 'أُنشئ في' }), h('b', { class: 'num', text: c.date })),
          h('div', { class: 'kv' }, h('span', { text: 'المسدَّد منه' }), h('b', { class: 'num good', text: money(it.paid) + cur() })),
          h('div', { class: 'kv' }, h('span', { text: 'المتبقي' }), h('b', { class: 'num ' + (it.left > 0.004 ? (it.late ? 'bad' : 'warn') : 'good'), text: money(it.left) + cur() }))));
        b.appendChild(fld('المبلغ', amt)); b.appendChild(h('div', { class: 'two' }, fld('تاريخ الاستحقاق', due), fld('الوصف', desc)));
        if (c.kind === 'sub') b.appendChild(h('p', { class: 'muted small', text: 'يتولّد هذا المستحق تلقائياً من اشتراك شهري. لإيقاف الاشتراك افتح تبويب «الاشتراكات».' }));
        b.appendChild(err);
        b.appendChild(A.armed(h('button', { class: 'btn danger', type: 'button', text: 'حذف المستحق' }), 'اضغط مرة أخرى للتأكيد', function () { L().voidCharge(c); close(); toast('حُذف المستحق.'); A.refresh(); }));
      },
      primary: { label: 'حفظ التعديل', fn: function (close) {
        var a = Core.parseAmt(amt.value); if (!a) { err.textContent = 'اكتب مبلغاً صحيحاً.'; return; }
        L().editCharge(c, a, due.value, desc.value); close(); toast('حُفظ التعديل.'); A.refresh();
      } }
    });
  };

  /* ---------- التسديد ---------- */
  F.pay = function (cid, preset) {
    var cu = L().db.customers[cid]; if (!cu) return;
    var a = L().acct(cid), method = 'cash', td = today();
    if (preset == null) preset = L().defaultPay(cid);
    var amt = inp({ class: 'big num', placeholder: '0', value: preset ? String(preset) : '', autofocus: true });
    var date = inp({ type: 'date', value: td, max: td }), note = inp({ placeholder: 'اختياري' }), err = errLine();
    A.openDialog({
      title: 'تسديد جديد',
      build: function (b) {
        b.appendChild(h('div', { class: 'summary' }, h('b', { class: 'name', text: cu.name }),
          h('div', { class: 'kv' }, h('span', { text: a.bal >= -0.004 ? 'المتبقي عليه' : 'رصيد له' }), h('b', { class: 'num', text: money(Math.abs(a.bal)) + cur() })),
          a.overdue > 0.004 ? h('div', { class: 'kv' }, h('span', { text: 'منه متأخر' }), h('b', { class: 'num bad', text: money(a.overdue) + cur() + ' • ' + a.maxLate + ' يوم' })) : null));
        b.appendChild(fld('المبلغ المستلم', amt));
        var sg = L().suggestions(cid);
        if (sg.length) b.appendChild(h('div', { class: 'qk' }, sg.map(function (s) { return h('button', { type: 'button', onclick: function () { amt.value = String(s.v); amt.focus(); } }, s.label + ' ', h('span', { class: 'num', text: money(s.v) })); })));
        b.appendChild(seg([['cash', 'نقداً'], ['transfer', 'تحويل'], ['other', 'أخرى']], method, function (v) { method = v; }));
        b.appendChild(h('div', { class: 'two' }, fld('تاريخ التسديد', date), fld('ملاحظة', note)));
        b.appendChild(err);
        setTimeout(function () { amt.select(); }, 40);
      },
      primary: { label: 'حفظ وإصدار سند', fn: function (close) {
        var v = Core.parseAmt(amt.value); err.textContent = '';
        if (!v) { err.textContent = 'اكتب مبلغاً صحيحاً.'; amt.focus(); return; }
        if (!Core.isIsoDate(date.value)) { err.textContent = 'اختر تاريخ التسديد.'; return; }
        if (date.value > today()) { err.textContent = 'لا يمكن اختيار تاريخ مستقبلي.'; return; }
        var p = L().addPayment(cid, v, method, note.value, date.value);
        close(); A.refresh(); F.receipt(p, true);
      } }
    });
  };

  /* ---------- معاينة السند ---------- */
  F.receipt = function (p, isNew) {
    var Lg = L(), cu = Lg.db.customers[p.cid], w = +Lg.db.cfg.pw || 384;
    var make = function (width) { return Docs.receiptDoc(Lg, p, width); };
    var doc = make(w), url = doc.png();
    A.openDialog({
      title: (isNew ? 'صدر السند ' : 'سند رقم ') + Lg.recNo(p) + (p.void ? ' (ملغى)' : ''), wide: true,
      build: function (b, close) {
        var side = h('div', { class: 'side' });
        var pr = h('button', { class: 'btn lg', type: 'button' }, ic('print'), 'طباعة');
        pr.addEventListener('click', function () { pr.disabled = true; A.printDoc(make).then(function () { pr.disabled = false; }); });
        side.appendChild(pr);
        if ((A.local.printVia || 'windows') === 'windows') side.appendChild(h('button', { class: 'btn ghost', type: 'button', onclick: function () { A.printDoc(make, { dialog: true }); } }, ic('print'), 'طباعة مع اختيار الطابعة'));
        side.appendChild(h('button', { class: 'btn ghost', type: 'button', onclick: A.guard(function () { return api.saveImage('receipt-' + Lg.recNo(p) + '.png', url).then(function (r) { if (r.ok) toast('حُفظت الصورة.'); else if (!r.cancelled) toast(r.error, true); }); }) }, ic('image'), 'حفظ كصورة'));
        side.appendChild(h('button', { class: 'btn ghost', type: 'button', onclick: function () { api.copy(Lg.receiptText(p)); toast('نُسخ نص السند.'); } }, ic('copy'), 'نسخ كنص'));
        var link = cu ? Lg.waLink(cu.phone, Lg.receiptText(p)) : '';
        if (link) side.appendChild(h('button', { class: 'btn wa', type: 'button', onclick: function () { api.openWa(link); } }, ic('wa'), 'إرسال واتساب'));
        side.appendChild(h('hr'));
        side.appendChild(A.armed(h('button', { class: 'btn danger', type: 'button', text: p.void ? 'استرجاع السند' : 'إلغاء السند' }), 'اضغط مرة أخرى للتأكيد', function () {
          Lg.setPayVoid(p, !p.void); close(); toast(p.void ? 'أُلغي السند وأُعيد حساب الرصيد.' : 'استُرجع السند.'); A.refresh();
        }));
        side.appendChild(h('p', { class: 'muted small', text: p.void ? 'السند ملغى ولا يدخل في الحسابات.' : 'الإلغاء لا يحذف السند؛ يبقى في السجل ويمكن استرجاعه.' }));
        b.appendChild(h('div', { class: 'viewer' }, h('div', { class: 'paperwrap' }, h('div', { class: 'paper' + (w >= 576 ? ' w576' : '') }, h('img', { src: url, alt: 'معاينة السند' }))), side));
        if (isNew && A.local.autoPrint) setTimeout(function () { pr.click(); }, 80);
      }
    });
  };

  /* ---------- طباعة رسالة ملصوقة كوصل مرتب ---------- */
  // معلومات المكتب والتحويل تتكرر في كل رسالة: نحفظ آخر قيمة ونقترحها إن غابت عن الرسالة
  var MSG_KEEP = ['emp', 'card', 'holder', 'addr'];
  function msgMem(save) {
    try {
      if (save) localStorage.setItem('daftar.msg', JSON.stringify(save));
      return JSON.parse(localStorage.getItem('daftar.msg') || '{}') || {};
    } catch (e) { return {}; }
  }
  F.message = function () {
    var w = +L().db.cfg.pw || 384, cfg = L().db.cfg, data = null, url = '', t = 0;
    var src = h('textarea', { rows: 9, placeholder: 'الصق الرسالة هنا (Ctrl+V)…\nمثال:\nتحية طيبة عزيزي المشترك\nالاسم: …\nنوع الاشتراك: …\nتم استلام مبلغ …\nوالمتبقي …\nالموظف المستلم: …', autofocus: true });
    var defs = [['name', 'الاسم'], ['sub', 'نوع الاشتراك'], ['amount', 'المبلغ المستلم'], ['remain', 'المتبقي'], ['status', 'الحالة (مثل: تم التسديد والتفعيل)'], ['emp', 'الموظف المستلم'],
      ['phone', 'الهاتف'], ['date', 'تاريخ الاشتراك'], ['card', 'رقم الماستر كارد للتحويل'], ['holder', 'اسم صاحب الماستر كارد'], ['addr', 'عنوان المكتب']];
    var ins = {};
    defs.forEach(function (d) { ins[d[0]] = inp({ dir: d[0] === 'card' ? 'ltr' : 'rtl', class: d[0] === 'card' || d[0] === 'amount' || d[0] === 'remain' ? 'num' : '' }); });
    var notes = h('textarea', { rows: 2, placeholder: 'أسطر أخرى من الرسالة' }), greet = inp({});
    var img = h('img', { alt: 'معاينة الوصل' }), hint = h('p', { class: 'muted small', text: 'الصق الرسالة وسيُرتَّب الوصل تلقائياً. يمكنك تعديل أي حقل قبل الطباعة.' });
    function current() {
      var m = { greet: greet.value, notes: notes.value.split('\n') };
      defs.forEach(function (d) { m[d[0]] = ins[d[0]].value; });
      return m;
    }
    var make = function (width) { return Docs.messageDoc(cfg, data || current(), width); };
    function render() { data = current(); url = make(w).png(); img.src = url; }
    function later() { clearTimeout(t); t = setTimeout(render, 120); }
    function fill() {
      var m = Msg.parse(src.value), mem = msgMem();
      defs.forEach(function (d) { ins[d[0]].value = m[d[0]] || (MSG_KEEP.indexOf(d[0]) >= 0 && src.value.trim() ? mem[d[0]] || '' : ''); });
      greet.value = m.greet || ''; notes.value = m.notes.join('\n');
      render();
    }
    src.addEventListener('input', function () { clearTimeout(t); t = setTimeout(fill, 150); });
    defs.forEach(function (d) { ins[d[0]].addEventListener('input', later); });
    greet.addEventListener('input', later); notes.addEventListener('input', later);
    function remember() { var m = current(), keep = msgMem(); MSG_KEEP.forEach(function (k) { if (m[k].trim()) keep[k] = m[k].trim(); }); msgMem(keep); }
    A.openDialog({
      title: 'طباعة رسالة كوصل', wide: true,
      build: function (b) {
        var form = h('div', { style: { display: 'grid', gap: '8px', alignContent: 'start' } });
        form.appendChild(fld('نص الرسالة', src));
        form.appendChild(hint);
        form.appendChild(fld('التحية', greet));
        for (var i = 0; i < defs.length; i += 2) form.appendChild(h('div', { class: 'two' }, fld(defs[i][1], ins[defs[i][0]]), defs[i + 1] ? fld(defs[i + 1][1], ins[defs[i + 1][0]]) : h('span')));
        form.appendChild(fld('ملاحظات', notes));
        var side = h('div', { class: 'side' });
        var pr = h('button', { class: 'btn lg', type: 'button' }, ic('print'), 'طباعة');
        pr.addEventListener('click', function () { render(); remember(); pr.disabled = true; A.printDoc(make).then(function () { pr.disabled = false; }); });
        side.appendChild(pr);
        if ((A.local.printVia || 'windows') === 'windows') side.appendChild(h('button', { class: 'btn ghost', type: 'button', onclick: function () { render(); remember(); A.printDoc(make, { dialog: true }); } }, ic('print'), 'طباعة مع اختيار الطابعة'));
        side.appendChild(h('button', { class: 'btn ghost', type: 'button', onclick: A.guard(function () { render(); return api.saveImage('wasl-' + Core.today() + '.png', url).then(function (r) { if (r.ok) toast('حُفظت الصورة.'); else if (!r.cancelled) toast(r.error, true); }); }) }, ic('image'), 'حفظ كصورة'));
        side.appendChild(h('button', { class: 'btn ghost', type: 'button', onclick: function () { src.value = ''; fill(); src.focus(); } }, ic('close'), 'مسح'));
        side.appendChild(h('div', { class: 'paperwrap' }, h('div', { class: 'paper' + (w >= 576 ? ' w576' : '') }, img)));
        b.appendChild(h('div', { class: 'viewer msgview' }, form, side));
        render();
      }
    });
  };

  F.statement = function (c) {
    var Lg = L(), w = +Lg.db.cfg.pw || 384, make = function (width) { return Docs.statementDoc(Lg, c, width); }, url = make(w).png();
    A.openDialog({
      title: 'كشف حساب — ' + c.name, wide: true,
      build: function (b) {
        var side = h('div', { class: 'side' });
        side.appendChild(h('button', { class: 'btn lg', type: 'button', onclick: function () { A.printDoc(make); } }, ic('print'), 'طباعة'));
        side.appendChild(h('button', { class: 'btn ghost', type: 'button', onclick: A.guard(function () { return api.saveImage('statement-' + Core.today() + '.png', url).then(function (r) { if (r.ok) toast('حُفظت الصورة.'); else if (!r.cancelled) toast(r.error, true); }); }) }, ic('image'), 'حفظ كصورة'));
        side.appendChild(h('button', { class: 'btn ghost', type: 'button', onclick: function () { api.copy(Lg.statementText(c)); toast('نُسخ نص الكشف.'); } }, ic('copy'), 'نسخ كنص'));
        var link = Lg.waLink(c.phone, Lg.statementText(c));
        if (link) side.appendChild(h('button', { class: 'btn wa', type: 'button', onclick: function () { api.openWa(link); } }, ic('wa'), 'إرسال واتساب'));
        b.appendChild(h('div', { class: 'viewer' }, h('div', { class: 'paperwrap' }, h('div', { class: 'paper' + (w >= 576 ? ' w576' : '') }, h('img', { src: url, alt: 'كشف الحساب' }))), side));
      }
    });
  };

  F.remind = function (c) {
    var link = L().waLink(c.phone, L().reminderText(c));
    if (!link) { toast('لا يوجد رقم هاتف صالح لهذا العميل.', true); return; }
    api.openWa(link).then(function (ok) { if (ok) toast('فُتح واتساب في المتصفح.'); else toast('تعذّر فتح الرابط.', true); });
  };

  /* ---------- اختيار عميل ---------- */
  F.pick = function (cb, title) {
    if (!L().activeCustomers().length) { toast('أضف عميلاً أولاً.'); F.customer(null); return; }
    var q = inp({ type: 'search', placeholder: 'ابحث بالاسم أو الرقم', autofocus: true }), box = h('div', { class: 'lines' }), list = [], sel = 0;
    var dlg = A.openDialog({
      title: title || 'اختر العميل',
      build: function (b, close) {
        function choose(c) { close(); cb(c); }
        function paint() {
          list = L().customerList(q.value, 'all', 'name').list.slice(0, 60); if (sel >= list.length) sel = 0;
          box.innerHTML = '';
          if (!list.length) { box.appendChild(h('div', { class: 'empty', text: 'لا يوجد عميل بهذا الاسم أو الرقم.' })); return; }
          list.forEach(function (x, i) {
            var bi = A.balInfo(x.a);
            box.appendChild(h('div', { class: 'line', role: 'option', 'aria-selected': i === sel ? 'true' : 'false', style: i === sel ? { background: 'var(--row-sel)' } : null, onclick: function () { choose(x.c); } },
              h('div', { class: 't' }, h('b', { text: x.c.name }), h('small', { class: 'num', text: x.c.phone || '' })), h('div', { class: 'a ' + bi.cls }, h('span', { class: 'num', text: bi.txt }), h('small', { text: bi.sub }))));
          });
          var on = box.children[sel]; if (on && on.scrollIntoView) on.scrollIntoView({ block: 'nearest' });
        }
        q.addEventListener('input', function () { sel = 0; paint(); });
        q.addEventListener('keydown', function (e) {
          if (e.key === 'ArrowDown') { sel = Math.min(list.length - 1, sel + 1); paint(); e.preventDefault(); }
          else if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); paint(); e.preventDefault(); }
          else if (e.key === 'Enter' && list[sel]) { e.preventDefault(); e.stopPropagation(); choose(list[sel].c); }
        });
        b.appendChild(q); b.appendChild(h('div', { style: { maxHeight: '52vh', overflow: 'auto' } }, box)); paint();
      }
    });
    return dlg;
  };

  /* ---------- الاستيراد من Excel/CSV ---------- */
  F.importFile = A.guard(async function () {
    var r = await api.openTable();
    if (!r.ok) { if (!r.cancelled) toast(r.error, true); return; }
    var rows = r.rows;
    if (rows.length < 2) { toast('الملف فارغ أو فيه سطر واحد فقط.', true); return; }
    var head = rows[0], cols = Core.detectColumns(head);
    var opt = function (withNone, val) {
      var s = h('select'); if (withNone) s.appendChild(h('option', { value: '-1', text: 'بدون' }));
      head.forEach(function (c, i) { s.appendChild(h('option', { value: String(i), text: c || ('عمود ' + (i + 1)) })); }); s.value = String(val); return s;
    };
    var sName = opt(false, cols.name), sPhone = opt(true, cols.phone), sBal = opt(true, cols.bal), info = h('div', { class: 'note brand' }), prev = h('div', { class: 'summary small' }), planRes = null;
    function plan() {
      var c = { name: +sName.value, phone: +sPhone.value, bal: +sBal.value };
      planRes = L().planImport(rows, c);
      info.textContent = 'سيُضاف ' + planRes.ok + ' عميل جديد' + (planRes.dup ? ' • ' + planRes.dup + ' مكرر سيُتجاهل' : '') + (planRes.bad ? ' • ' + planRes.bad + ' سطر بلا اسم' : '');
      prev.innerHTML = ''; prev.appendChild(h('b', { text: 'معاينة أول الأسطر' }));
      planRes.list.slice(0, 5).forEach(function (x) { prev.appendChild(h('div', { class: 'kv' }, h('span', { text: x.name + (x.phone ? ' — ' + x.phone : '') }), h('b', { class: 'num', text: x.bal ? money(x.bal) : '—' }))); });
    }
    A.openDialog({
      title: 'استيراد العملاء من ' + r.name,
      build: function (b) {
        b.appendChild(h('p', { class: 'muted small', text: 'وجدت ' + (rows.length - 1) + ' سطراً في أول ورقة. تأكد من الأعمدة:' }));
        b.appendChild(h('div', { class: 'two' }, fld('عمود الاسم', sName), fld('عمود الهاتف', sPhone)));
        b.appendChild(fld('عمود الرصيد السابق (اختياري)', sBal, 'يصبح مستحقاً باسم «رصيد سابق» بتاريخ اليوم.'));
        b.appendChild(info); b.appendChild(prev);
        [sName, sPhone, sBal].forEach(function (s) { s.addEventListener('change', plan); }); plan();
      },
      primary: { label: 'استيراد', fn: function (close) {
        if (!planRes || !planRes.list.length) { toast('لا يوجد عملاء جدد لإضافتهم.', true); return; }
        var n = L().applyImport(planRes.list); close(); toast('أُضيف ' + n + ' عميل.', false, 4000); A.go('cust');
      } }
    });
  });

  /* ---------- النسخ الاحتياطي والاستعادة ---------- */
  F.backupNow = A.guard(async function () {
    var Lg = L(), prevB = Lg.db.meta.lastBackup;
    Lg.db.meta.lastBackup = Date.now();
    var r = await api.saveText('ledger-backup-' + today() + '.json', JSON.stringify(Core.makeBackup(Lg.db)), 'json');
    if (r.ok) { A.scheduleSave(); A.paintTally(); toast('حُفظت النسخة الاحتياطية.'); A.refresh(); }
    else { Lg.db.meta.lastBackup = prevB; if (!r.cancelled) toast(r.error, true); }
  });
  F.restore = A.guard(async function () {
    var r = await api.openBackup();
    if (!r.ok) { if (!r.cancelled) toast(r.error, true); return; }
    var v = Core.parseBackupText(r.text);
    if (!v.ok) { toast(v.err, true); return; }
    var curN = L().activeCustomers().length, o = v.obj;
    A.openDialog({
      title: 'استعادة نسخة احتياطية',
      build: function (b, close) {
        b.appendChild(h('div', { class: 'summary' }, h('b', { text: r.name }),
          h('div', { class: 'kv' }, h('span', { text: 'عدد العملاء في النسخة' }), h('b', { class: 'num', text: String(v.n) })),
          h('div', { class: 'kv' }, h('span', { text: 'تاريخ النسخة' }), h('b', { class: 'num', text: o.at ? String(o.at).slice(0, 16).replace('T', ' ') : '—' }))));
        b.appendChild(h('div', { class: 'note bad', text: 'ستحلّ النسخة محل كل البيانات الحالية (' + curN + ' عميل) ولا يمكن التراجع.' }));
        b.appendChild(A.armed(h('button', { class: 'btn danger lg', type: 'button', text: 'استبدال البيانات بالنسخة' }), 'اضغط مرة أخرى للتأكيد', function () {
          L().replace(o.db); L().genSubs(); A.saveNow(); A.closeAll(); A.applyTheme(); toast('تمت الاستعادة: ' + v.n + ' عميل.', false, 4000); A.go('home');
        }));
      }
    });
  });

  /* ---------- اختيار طابعة البلوتوث (القائمة تصل من العملية الرئيسية) ---------- */
  // تُفتح النافذة فور الضغط على الزر حتى يرى المستخدم أن البحث بدأ
  var btDlg = null, btList = null, btHint = null, btTimer = 0;
  var isPrinter = function (n) { return /^(MXW?|GB|GT|YT|MX\d)/i.test(n || ''); };
  function btEmpty(text) { btList.innerHTML = ''; btList.appendChild(h('div', { class: 'empty', text: text })); }
  F.btOpen = function () {
    if (btDlg) return;
    btList = h('div', { class: 'lines' });
    btHint = h('p', { class: 'muted small', hidden: true, text: 'لا تظهر الطابعة؟ تأكد أنها مشحونة ومشغّلة، وأن البلوتوث مفعّل في Windows، وأن تطبيقها على الهاتف مغلق (الطابعة تتصل بجهاز واحد فقط).' });
    btDlg = A.openDialog({
      title: 'اختر طابعة البلوتوث',
      build: function (b) { b.appendChild(h('p', { class: 'muted small', text: 'شغّل الطابعة وقرّبها، وأغلق تطبيقها الأصلي على الهاتف. الأسماء تبدأ غالباً بـ MX أو GB.' })); b.appendChild(btList); b.appendChild(btHint); },
      onclose: function () { clearTimeout(btTimer); if (btDlg && !btDlg.chosen) api.btSelect(''); btDlg = null; }
    });
    btEmpty('جارٍ البحث عن الأجهزة…');
    btTimer = setTimeout(function () { if (btHint) btHint.hidden = false; }, 10000);
  };
  // عند انتهاء الطلب (نجاحاً أو فشلاً) تُغلق النافذة إن بقيت
  F.btDone = function () { if (btDlg) { btDlg.chosen = true; var d = btDlg; btDlg = null; A.closeDialog(d); } };
  api.onBtDevices(function (devs) {
    if (!btDlg) F.btOpen();
    var named = devs.filter(function (d) { return d.name; });
    if (!named.length) { btEmpty('جارٍ البحث عن الأجهزة…'); return; }
    named.sort(function (a, b) { return (isPrinter(b.name) ? 1 : 0) - (isPrinter(a.name) ? 1 : 0) || a.name.localeCompare(b.name); });
    btList.innerHTML = '';
    named.forEach(function (d) {
      btList.appendChild(h('div', { class: 'line', onclick: function () { if (!btDlg) return; btDlg.chosen = true; api.btSelect(d.id); A.closeTop(); } },
        h('div', { class: 't' }, h('b', { text: d.name + (isPrinter(d.name) ? ' — طابعة' : '') }), h('small', { class: 'num', text: d.id })), ic('bt')));
    });
  });
})();
