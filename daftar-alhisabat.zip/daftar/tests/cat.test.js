'use strict';
// 13) بايتات طابعة البلوتوث «cat printer»
const test = require('node:test');
const assert = require('node:assert/strict');
const Cat = require('../shared/cat');

test('ثوابت CRC8 المنشورة', () => {
  assert.equal(Cat.crc8([0x32]), 0x9E);
  assert.equal(Cat.crc8([0x30, 0x00]), 0xF9);
  assert.equal(Cat.crc8(Cat.LATTICE_START), 0xA1);
  assert.equal(Cat.crc8(Cat.LATTICE_END), 0x11);
  assert.equal(Cat.crc8([0x10]), 0x70);
});

test('بنية الإطار', () => {
  assert.deepEqual(Array.from(Cat.frame(0xA4, [0x32])), [0x51, 0x78, 0xA4, 0x00, 0x01, 0x00, 0x32, 0x9E, 0xFF]);
  // إشعار الإيقاف من الطابعة: حمولته 10 وCRC8 لها 70 كما في الإطار المنشور
  assert.deepEqual(Cat.PAUSE.slice(6, 8), [0x10, Cat.crc8([0x10])]);
  const f = Cat.frame(0xA2, new Uint8Array(48));
  assert.equal(f.length, 56); assert.equal(f[4], 48); assert.equal(f[5], 0); assert.equal(f[55], 0xFF);
});

test('الصور: البت 0 أقصى اليسار، وعدد صفوف A2 = الارتفاع + 128', () => {
  const W = 384, H = 10, data = new Uint8Array(W * H * 4).fill(255);
  const setBlack = (x, y) => { const i = (y * W + x) * 4; data[i] = data[i + 1] = data[i + 2] = 0; };
  setBlack(0, 0); setBlack(9, 0); setBlack(383, 9);
  const rows = Cat.rowsFromRgba(data, W, H);
  assert.equal(rows.length, H); assert.equal(rows[0][0], 0b00000001); assert.equal(rows[0][1], 0b00000010); assert.equal(rows[9][47], 0b10000000);
  const frames = Cat.frames(rows, 'normal');
  const cmds = frames.map((f) => f[2]);
  assert.equal(cmds.filter((c) => c === 0xA2).length, H + 128);
  assert.deepEqual(cmds.slice(0, 8), [0xA3, 0xA3, 0xA4, 0xBD, 0xAF, 0xBE, 0xA9, 0xA6]);
  assert.deepEqual(cmds.slice(8 + H, 10 + H), [0xA6, 0xBD]); // نهاية الشبكة ثم السرعة، ثم التغذية
  assert.deepEqual(Array.from(frames[8 + H].slice(6, 17)), Cat.LATTICE_END);
  assert.equal(cmds[cmds.length - 1], 0xA3);
  assert.deepEqual(Array.from(frames[4].slice(6, 8)), [0x00, 0x48]); // طاقة عادية LE
  for (const f of frames) { const n = f[4] | (f[5] << 8); assert.equal(f.length, n + 8); assert.equal(f[6 + n], Cat.crc8(f.slice(6, 6 + n))); assert.equal(f[7 + n], 0xFF); }
  assert.throws(() => Cat.rowsFromRgba(new Uint8Array(576 * 4), 576, 1), /384/);
  assert.ok(Cat.isPause(Uint8Array.from(Cat.PAUSE)) && Cat.isResume(Uint8Array.from(Cat.RESUME)));
  const s = Cat.stream(rows, 'dark'); assert.equal(s.length, frames.reduce((a, f) => a + f.length, 0));
});
