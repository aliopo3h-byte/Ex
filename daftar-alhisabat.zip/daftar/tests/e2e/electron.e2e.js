// اختبار تشغيل فعلي للتطبيق في Electron على Windows: npm run test:e2e
// يشغّل التطبيق بمجلد بيانات مؤقت، ويضيف عميلاً وتسديداً، ويصوّر الشاشات بالوضعين، ويتأكد من حفظ الملف على القرص.
const { _electron: electron } = require('playwright');
const path = require('path');
const fs = require('fs');
const os = require('os');
(async () => {
  const appData = fs.mkdtempSync(path.join(os.tmpdir(), 'daftar-e2e-'));
  const out = path.join(__dirname, 'shots'); fs.mkdirSync(out, { recursive: true });
  const app = await electron.launch({ args: [path.join(__dirname, '..', '..'), '--data-dir=' + path.join(appData, 'DaftarAlHisabat')] });
  const win = await app.firstWindow();
  await win.waitForFunction(() => window.__app && window.__app.ready);
  await win.keyboard.press('Control+n');
  await win.fill('.dialog input >> nth=0', 'عميل تجريبي'); await win.fill('.dialog input >> nth=1', '07811111111');
  await win.keyboard.press('Enter');
  await win.click('.dacts .btn:has-text("مستحق جديد")'); await win.fill('.dialog input.big', '50000'); await win.keyboard.press('Enter');
  await win.keyboard.press('Control+p'); await win.fill('.dialog input.big', '20000'); await win.keyboard.press('Enter');
  await win.waitForSelector('.dialog h2:has-text("صدر السند")');
  await win.screenshot({ path: path.join(out, 'receipt.png') });
  await win.keyboard.press('Escape');
  for (const [k, n] of [['1', 'home'], ['2', 'customers'], ['4', 'reports'], ['5', 'settings']]) { await win.keyboard.press('Control+' + k); await win.waitForTimeout(300); await win.screenshot({ path: path.join(out, n + '.png') }); }
  await win.waitForTimeout(800);
  const file = path.join(appData, 'DaftarAlHisabat', 'ledger.json');
  const db = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (Object.keys(db.customers).length !== 1 || db.pays[0].after !== 30000) throw new Error('البيانات لم تُحفظ كما يجب');
  await app.close();
  console.log('نجح الاختبار. الصور في ' + out);
})().catch((e) => { console.error('فشل:', e); process.exit(1); });
