'use strict';
// مولّد بيانات ضخمة للاختبار: 5,000 عميل و20,000 مستحق و8,000 سند
const Core = require('../../shared/core');
const FIRST = ['أحمد', 'محمد', 'علي', 'حسن', 'حسين', 'زينب', 'فاطمة', 'مريم', 'حمزة', 'إسراء', 'يوسف', 'نور', 'سارة', 'عباس', 'كرار', 'رقية', 'مصطفى', 'هدى'];
const LAST = ['الجبوري', 'العبيدي', 'كاظم', 'الموسوي', 'جاسم', 'الحسيني', 'عبدالله', 'الربيعي', 'التميمي', 'سلمان', 'الخفاجي', 'ناصر'];
function generate(opts = {}) {
  const nC = opts.customers || 5000, nCh = opts.charges || 20000, nP = opts.pays || 8000, td = opts.today || '2026-11-15';
  let seed = 7; const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  const db = Core.blank(); let id = 0;
  db.cfg.shop = 'محل النور للاتصالات'; db.cfg.shopph = '0770 123 4567'; db.cfg.curr = 'دينار'; db.cfg.cc = '964'; db.cfg.pre = 'R-';
  for (let i = 0; i < nC; i++) {
    const c = { id: ++id, name: FIRST[Math.floor(rnd() * FIRST.length)] + ' ' + LAST[Math.floor(rnd() * LAST.length)] + (i > 30 ? ' ' + (i + 1) : ''), phone: '07' + String(700000000 + i * 37).padStart(9, '0'), note: '', created: 0 };
    db.customers[c.id] = c;
  }
  const ids = Object.keys(db.customers).map(Number);
  for (let i = 0; i < nCh; i++) {
    const cid = ids[i % nC], due = Core.addDays(td, Math.floor(rnd() * 240) - 170);
    db.charges.push({ id: ++id, cid, amt: Math.round(5 + rnd() * 95) * 1000, date: Core.addDays(due, -10), due, desc: i % 3 ? 'فاتورة ' + (i + 1) : 'اشتراك شهري', kind: i % 3 ? 'debt' : 'sub' });
  }
  for (let i = 0; i < nP; i++) {
    const cid = ids[Math.floor(rnd() * nC)], d = Core.addDays(td, -Math.floor(rnd() * 90));
    db.pays.push({ id: ++id, no: i + 1, cid, amt: Math.round(5 + rnd() * 60) * 1000, ts: Core.parseIso(d).getTime() + 9 * 3600000 + i * 1000, d, m: ['cash', 'transfer', 'other'][i % 3], t: '', after: 0 });
  }
  db.seq.id = id; db.seq.rec = nP;
  return db;
}
module.exports = { generate };
