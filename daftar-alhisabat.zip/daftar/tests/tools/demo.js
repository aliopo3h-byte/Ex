'use strict';
// بيانات عرض واقعية (للتصوير والتجربة اليدوية) بتاريخ 2026-11-15
const Core = require('../../shared/core');
function demo() {
  Core.setNow(() => new Date(2026, 10, 15, 10, 30));
  const L = new Core.Ledger(Core.blank());
  Object.assign(L.db.cfg, { shop: 'محل النور للاتصالات', shopph: '0770 123 4567', curr: 'دينار', cc: '964', pre: 'R-', foot: 'شكراً لتعاملكم معنا' });
  const names = ['أحمد علي حسن', 'زينب محمد كاظم', 'حمزة عبدالله', 'إسراء جاسم', 'مصطفى الربيعي', 'فاطمة ناصر', 'يوسف التميمي', 'مريم سلمان', 'علي الخفاجي', 'نور الهدى عباس',
    'كرار حسين', 'رقية الموسوي', 'عباس جبار', 'سارة العبيدي', 'محمد باقر', 'هدى الحسيني', 'حسن كاظم', 'دعاء فاضل', 'عمر الجبوري', 'آمنة رحيم', 'سجاد مهدي', 'بنين عادل', 'ليث سعد', 'ضحى قاسم'];
  const back = (n) => Core.addDays('2026-11-15', -n);
  names.forEach((n, i) => {
    const c = L.addCustomer(n, '07' + (7 + (i % 3)) + String(10000000 + i * 7919).slice(0, 8));
    const k = i % 6;
    if (k === 0) { L.addCharge(c.id, 100000 + i * 5000, back(5 + i), 'فاتورة صيانة'); L.addSub(c.id, 25000, 5, '2026-09', 'اشتراك إنترنت'); }
    else if (k === 1) { L.addInstallments(c.id, 600000, 6, '2026-08-01', 'هاتف سامسونج'); }
    else if (k === 2) { L.addSub(c.id, 30000 + (i % 4) * 5000, 18 + (i % 5), '2026-10', 'اشتراك إنترنت'); }
    else if (k === 3) { L.addCharge(c.id, 75000, back(-3 - (i % 5)), 'شاشة'); }
    else if (k === 4) { L.addCharge(c.id, 40000, back(95 + i), 'رصيد قديم'); L.addCharge(c.id, 15000, back(40), 'شاحن'); }
    else { L.addCharge(c.id, 20000, back(20), 'إكسسوارات'); }
  });
  const ids = L.activeCustomers().map((c) => c.id);
  const pays = [[0, 60000, 0], [1, 100000, 0], [2, 30000, 1], [6, 125000, 2], [7, 50000, 3], [8, 30000, 5], [11, 20000, 6], [13, 100000, 8], [17, 20000, 0], [18, 45000, 12], [19, 600000, 20], [23, 30000, 1], [5, 20000, 25], [9, 35000, 0], [12, 10000, 4]];
  pays.forEach(([ci, amt, ago], j) => {
    const now = Core.now; Core.setNow(() => new Date(2026, 10, 15 - ago, 9 + (j % 8), 10 + j * 3));
    L.addPayment(ids[ci], amt, ['cash', 'transfer', 'cash', 'other'][j % 4], j === 3 ? 'تحويل زين كاش' : '', Core.today());
    Core.setNow(() => new Date(2026, 10, 15, 10, 30));
  });
  L.setPayVoid(L.db.pays[12], true);
  L.db.meta.lastBackup = new Date(2026, 10, 13, 18, 0).getTime();
  return L.db;
}
module.exports = { demo };
if (require.main === module) process.stdout.write(JSON.stringify(demo()));
