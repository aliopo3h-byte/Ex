// يولّد tests/fixtures/phone-backup.json باستعمال تطبيق الهاتف المرجعي نفسه (نماذجه وزر النسخة الاحتياطية)
// التشغيل: node tests/tools/make-phone-fixture.js   (يحتاج playwright)
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ acceptDownloads: true, viewport: { width: 420, height: 900 } });
  const page = await ctx.newPage();
  await page.clock.install({ time: new Date(2026, 10, 15, 10, 30) });
  await page.route(/^https?:/, (r) => r.abort());
  await page.goto('file://' + path.join(__dirname, '..', 'fixtures', 'phone-reference.html'));
  await page.waitForFunction(() => window.__ledger);
  const sheetBtn = (t) => page.locator('.sheet button', { hasText: t }).first();
  async function newCustomer(name, phone) {
    await page.click('#fab'); await sheetBtn('عميل جديد').click();
    await page.fill('.sheet input >> nth=0', name); await page.fill('.sheet input >> nth=1', phone);
    await sheetBtn('حفظ').click();
  }
  async function charge(kind, amt, extra) {
    await page.locator('.main button', { hasText: 'مستحق جديد' }).click();
    await sheetBtn(kind).click();
    await page.fill('.sheet input.big', amt);
    if (extra) await extra();
    await sheetBtn('حفظ المستحق').click();
  }
  // العميل الأول: المثال المرجعي
  await newCustomer('أحمد علي', '07701234567');
  await charge('دين / فاتورة', '100000', async () => { await page.fill('.sheet input[type=date] >> visible=true', '2026-11-10'); });
  await charge('أقساط', '600000', async () => {
    await page.locator('.sheet .two input').nth(0).fill('6');
    await page.locator('.sheet .two input[type=date]').fill('2026-12-01');
  });
  await charge('اشتراك شهري', '25000', async () => { await page.locator('.sheet .list:not([hidden]) input').first().fill('5'); });
  await page.locator('.main button', { hasText: 'تسديد' }).first().click();
  await page.fill('.sheet input.big', '50000');
  await sheetBtn('حفظ وإصدار سند').click();
  await page.keyboard.press('Escape');
  await page.evaluate(() => window.onBack() && window.onBack() && window.onBack());
  // العميل الثاني: دفع زائد
  await page.evaluate(() => { while (window.onBack()) {} });
  await newCustomer('حمزة', '0780 000 1111');
  await charge('دين / فاتورة', '1000', null);
  await page.locator('.main button', { hasText: 'تسديد' }).first().click();
  await page.fill('.sheet input.big', '1500.25');
  await sheetBtn('حفظ وإصدار سند').click();
  await page.evaluate(() => { while (window.onBack()) {} });
  await page.evaluate(() => { const d = window.__ledger.db; d.cfg.shop = 'محل الهاتف'; d.cfg.curr = 'دينار'; d.cfg.cc = '964'; d.cfg.pre = 'R-'; window.__ledger.flush(); });
  // النسخة الاحتياطية من زر التطبيق
  await page.locator('#nav button', { hasText: 'الإعدادات' }).click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.locator('.main button', { hasText: 'نسخة احتياطية' }).first().click()]);
  const text = fs.readFileSync(await dl.path(), 'utf8');
  const obj = JSON.parse(text);
  const expect = await page.evaluate(() => ({ today: '2026-11-15', accounts: Object.keys(window.__ledger.db.customers).map((id) => { const a = window.__ledger.acct(+id); return { id: +id, bal: a.bal, overdue: a.overdue, maxLate: a.maxLate }; }) }));
  obj._expect = expect;
  fs.writeFileSync(path.join(__dirname, '..', 'fixtures', 'phone-backup.json'), JSON.stringify(obj, null, 1));
  console.log('customers', Object.keys(obj.db.customers).length, 'charges', obj.db.charges.length, 'pays', obj.db.pays.length, JSON.stringify(expect));
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });
