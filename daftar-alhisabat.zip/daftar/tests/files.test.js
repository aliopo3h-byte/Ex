'use strict';
// xlsx حقيقي، الكتابة الذرّية، النسخ التلقائي، واستيراد الملفات
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { writeXlsx, readXlsx, colName } = require('../main/xlsx');
const { crc32, readZip } = require('../main/zip');
const { Store, autoBackup } = require('../main/store');
const { readTable } = require('../main/importer');
const Core = require('../shared/core');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'daftar-'));
const hasPython = (() => { try { execFileSync('python3', ['-c', 'import openpyxl'], { stdio: 'ignore' }); return true; } catch (e) { return false; } })();

test('crc32 وأسماء الأعمدة', () => {
  assert.equal(crc32(Buffer.from('123456789')), 0xCBF43926);
  assert.equal(colName(0), 'A'); assert.equal(colName(25), 'Z'); assert.equal(colName(26), 'AA'); assert.equal(colName(701), 'ZZ');
});

test('xlsx: كتابة ثم قراءة بنصوص عربية وأرقام', () => {
  const rows = [['الاسم', 'الهاتف', 'المتبقي'], ['حمزة & شركاه <1>', '07700000001', 1250.5], ['زينب', '', -3]];
  const buf = writeXlsx([{ name: 'الأرصدة', rows }]);
  const z = readZip(buf);
  assert.ok(z.has('xl/workbook.xml') && z.has('[Content_Types].xml'));
  assert.match(z.get('xl/worksheets/sheet1.xml').toString(), /rightToLeft="1"/);
  assert.deepEqual(readXlsx(buf), [['الاسم', 'الهاتف', 'المتبقي'], ['حمزة & شركاه <1>', '07700000001', '1250.5'], ['زينب', '', '-3']]);
});

test('xlsx يفتحه openpyxl (قارئ مستقل)', { skip: !hasPython && 'openpyxl غير مثبت' }, () => {
  const dir = tmp(), f = path.join(dir, 'a.xlsx');
  fs.writeFileSync(f, writeXlsx([{ name: 'السندات', rows: [['رقم', 'المبلغ'], ['00001', 50000]] }, { name: 'ثانية', rows: [['x']] }]));
  const out = execFileSync('python3', ['-c', `import openpyxl,json;wb=openpyxl.load_workbook(${JSON.stringify(f)});ws=wb.worksheets[0];print(json.dumps([wb.sheetnames,[[c.value for c in r] for r in ws.iter_rows()],ws.sheet_view.rightToLeft]))`]).toString();
  assert.deepEqual(JSON.parse(out), [['السندات', 'ثانية'], [['رقم', 'المبلغ'], ['00001', 50000]], true]);
});

test('قراءة xlsx أنشأه openpyxl (sharedStrings وخلايا فارغة)', { skip: !hasPython && 'openpyxl غير مثبت' }, async () => {
  const dir = tmp(), f = path.join(dir, 'in.xlsx');
  execFileSync('python3', ['-c', `import openpyxl;wb=openpyxl.Workbook();ws=wb.active;ws.append(['الاسم','موبايل','دين']);ws.append(['حسن',7700000001,1500]);ws.append(['زينب',None,None]);ws['E5']='بعيد';wb.save(${JSON.stringify(f)})`]);
  const rows = await readTable(f);
  assert.deepEqual(rows[0], ['الاسم', 'موبايل', 'دين']);
  assert.deepEqual(rows[1], ['حسن', '7700000001', '1500']);
  assert.equal(rows[2][0], 'زينب');
  assert.equal(rows[3][4], 'بعيد');
  assert.deepEqual(Core.detectColumns(rows[0]), { name: 0, phone: 1, bal: 2 });
});

test('استيراد CSV بترميز UTF-16 وبفواصل تبويب', async () => {
  const dir = tmp(), f = path.join(dir, 'u16.csv');
  fs.writeFileSync(f, Buffer.concat([Buffer.from([0xFF, 0xFE]), Buffer.from('اسم\tهاتف\r\nعلي\t0770\r\n', 'utf16le')]));
  assert.deepEqual(await readTable(f), [['اسم', 'هاتف'], ['علي', '0770']]);
  await assert.rejects(readTable(path.join(dir, 'x.pdf')), /غير مدعوم/);
});

test('التخزين: كتابة ذرّية واسترجاع من .bak عند التلف', () => {
  const dir = tmp(), s = new Store(dir);
  assert.equal(s.load().db, null);
  s.save(JSON.stringify({ v: 1, customers: { 1: { id: 1, name: 'أ' } } }));
  assert.equal(fs.existsSync(path.join(dir, 'ledger.json.tmp')), false);
  const s2 = new Store(dir); assert.equal(s2.load().db.customers[1].name, 'أ'); // ينشئ .bak
  fs.writeFileSync(path.join(dir, 'ledger.json'), '{"v":1,"custo'); // إغلاق مفاجئ أثناء كتابة غير ذرّية مثلاً
  const r = new Store(dir).load();
  assert.equal(r.recovered, true); assert.equal(r.db.customers[1].name, 'أ');
  assert.ok(fs.readdirSync(dir).some((f) => f.startsWith('ledger.json.corrupt-')), 'يحتفظ بالملف التالف');
  const loc = new Store(dir); loc.saveLocal({ printerName: 'XP-58', backupDir: 'D:\\b' });
  assert.equal(loc.loadLocal().printerName, 'XP-58'); assert.equal(loc.loadLocal().paper, 'roll');
});

test('نسخ تلقائي يومي يحتفظ بآخر 14 نسخة، والنسخة صالحة للاستعادة', () => {
  const dir = tmp(), json = JSON.stringify(Core.blank());
  fs.writeFileSync(path.join(dir, 'ملف آخر.json'), '{}');
  for (let d = 1; d <= 20; d++) autoBackup(dir, json, '2026-11-' + String(d).padStart(2, '0'), 14);
  const files = fs.readdirSync(dir).filter((f) => f.startsWith('ledger-auto-')).sort();
  assert.equal(files.length, 14);
  assert.equal(files[0], 'ledger-auto-2026-11-07.json'); assert.equal(files[13], 'ledger-auto-2026-11-20.json');
  assert.ok(fs.existsSync(path.join(dir, 'ملف آخر.json')), 'لا يمس ملفات المستخدم');
  assert.equal(Core.parseBackupText(fs.readFileSync(path.join(dir, files[13]), 'utf8')).ok, true);
});
