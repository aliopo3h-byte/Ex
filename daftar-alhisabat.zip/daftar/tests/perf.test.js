'use strict';
// 12) الأداء: كل عملية تحتاجها شاشة يجب أن تنتهي في أقل من 100 مللي ثانية مع البيانات الضخمة
const test = require('node:test');
const assert = require('node:assert/strict');
const Core = require('../shared/core');
const { generate } = require('./tools/gen');

// الوسيط من 5 تشغيلات بعد تشغيل تمهيدي، حتى لا تؤثر ضوضاء المعالج على النتيجة
const time = (fn, once) => {
  const runs = [], n = once ? 1 : 5; let r;
  if (!once) fn();
  for (let i = 0; i < n; i++) { const t = process.hrtime.bigint(); r = fn(); runs.push(Number(process.hrtime.bigint() - t) / 1e6); }
  runs.sort((a, b) => a - b); return { ms: runs[Math.floor(n / 2)], r };
};

test('أداء مع 5,000 عميل و20,000 مستحق و8,000 سند', () => {
  Core.setNow(() => new Date(2026, 10, 15, 10, 0));
  const db = generate();
  assert.equal(Object.keys(db.customers).length, 5000); assert.equal(db.charges.length, 20000); assert.equal(db.pays.length, 8000);
  const L = new Core.Ledger(JSON.parse(JSON.stringify(db)));
  const res = {};
  res.home = time(() => { L.invalidate(); return L.totals(); });                      // حساب كل الأرصدة من الصفر
  res.list = time(() => L.customerList('', 'all', 'name'));
  res.search = time(() => L.customerList('حمزه', 'late', 'bal'));
  res.phone = time(() => L.customerList('0770001', 'all', 'due'));
  res.receipts = time(() => L.receipts('all', ''));
  res.report = time(() => { L.report('all'); return L.aging(); });
  res.save = time(() => JSON.stringify(L.db));
  res.payment = time(() => L.addPayment(1, 1000, 'cash', '', '2026-11-15'));         // يعيد حساب حساب العميل فقط
  res.afterPay = time(() => L.totals());
  for (const [k, v] of Object.entries(res)) console.log('  ' + k.padEnd(10) + v.ms.toFixed(1) + ' ms');
  for (const [k, v] of Object.entries(res)) assert.ok(v.ms < 100, k + ' أخذ ' + v.ms.toFixed(1) + ' ms');
  assert.ok(res.list.r.list.length === 5000);
  assert.ok(res.search.r.list.length > 0);
});
