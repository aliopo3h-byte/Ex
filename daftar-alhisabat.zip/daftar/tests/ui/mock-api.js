// window.api بديل للتجربة في متصفح عادي (Playwright) بدل Electron. لا يُشحن مع التطبيق.
(function () {
  var saved = null, local = Object.assign({ backupDir: '', lastAutoBackup: '', printerName: '', paper: 'roll', autoPrint: false, btDensity: 'normal', escposHost: '', escposPort: 9100, printVia: 'windows' }, window.__MOCK_LOCAL || {});
  var log = window.__apiLog = [];
  var ok = function (v) { return Promise.resolve(v); };
  window.api = {
    loadDb: function () { return ok({ db: window.__MOCK_DB ? JSON.parse(JSON.stringify(window.__MOCK_DB)) : null, recovered: false, error: null, local: local, version: '1.0.0', dataDir: 'C:\\Users\\me\\AppData\\Roaming\\DaftarAlHisabat' }); },
    saveDb: function (j) { saved = j; window.__saved = j; log.push(['save', j.length]); return ok({ ok: true }); },
    saveDbSync: function (j) { saved = j; window.__saved = j; return true; },
    setLocal: function (p) { Object.assign(local, p); return ok(local); },
    saveText: function (n, t, k) { log.push(['saveText', n, t.length]); window.__lastText = t; return ok({ ok: true, path: 'C:\\Docs\\' + n }); },
    saveXlsx: function (n, s) { log.push(['saveXlsx', n, s[0].rows.length]); window.__lastSheets = s; return ok({ ok: true, path: 'C:\\Docs\\' + n }); },
    saveImage: function (n, d) { log.push(['saveImage', n, d.length]); return ok({ ok: true, path: n }); },
    openBackup: function () { return ok(window.__MOCK_OPEN_BACKUP || { ok: false, cancelled: true }); },
    openTable: function () { return ok(window.__MOCK_OPEN_TABLE || { ok: false, cancelled: true }); },
    chooseBackupDir: function () { local.backupDir = 'D:\\نسخ دفتر الحسابات'; local.lastAutoBackup = '2026-11-15'; return ok({ ok: true, dir: local.backupDir, local: local }); },
    clearBackupDir: function () { local.backupDir = ''; return ok(local); },
    openBackupDir: function () { return ok(true); }, openDataDir: function () { return ok(true); },
    listPrinters: function () { return ok([{ name: 'XP-58', displayName: 'XP-58 (حرارية)', isDefault: false }, { name: 'HP LaserJet', displayName: 'HP LaserJet M404', isDefault: true }]); },
    printImage: function (o) { log.push(['printImage', o.width, o.height, o.deviceName, o.silent]); window.__lastPrint = o; return ok({ ok: true }); },
    printHtml: function (h) { log.push(['printHtml', h.length]); window.__lastHtml = h; return ok({ ok: true }); },
    savePdf: function (h, n) { log.push(['savePdf', n]); window.__lastHtml = h; return ok({ ok: true, path: n }); },
    printEscpos: function (b, w, hh) { log.push(['escpos', w, hh]); return ok({ ok: true }); },
    openWa: function (u) { log.push(['wa', u]); window.__lastWa = u; return ok(true); },
    copy: function (t) { log.push(['copy', t]); return ok(true); },
    setTheme: function () { return ok(true); },
    btSelect: function () {}, onBtDevices: function () {}, onBackupDone: function () {}, onError: function () {}
  };
})();
