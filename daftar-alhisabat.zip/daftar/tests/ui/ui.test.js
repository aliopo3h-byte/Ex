'use strict';
// اختبارات الواجهة في Chromium (بديل window.api): npm run test:ui
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const { openApp } = require('./harness');
const { demo } = require('../tools/demo');
const { generate } = require('../tools/gen');

let browser;
test.before(async () => { browser = await chromium.launch(); });
test.after(async () => { await browser.close(); });

test('10) الوصل: 384 و576 نقطة، أبيض وأسود صرف', async () => {
  const app = await openApp({ db: demo(), browser });
  const r = await app.page.evaluate(() => {
    const A = window.__app, L = A.L, p = L.db.pays[0], out = {};
    for (const w of [384, 576]) {
      const c = window.Docs.receiptDoc(L, p, w).finish(), d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
      let gray = 0, black = 0;
      for (let i = 0; i < d.length; i += 4) { if (d[i] !== 0 && d[i] !== 255) gray++; if (d[i] !== d[i + 1] || d[i] !== d[i + 2]) gray++; if (d[i] === 0) black++; }
      out[w] = { w: c.width, h: c.height, gray, black };
    }
    const bt = window.Docs.receiptDoc(L, p, 384).finish(), rows = window.Cat.rowsFromRgba(bt.getContext('2d').getImageData(0, 0, 384, bt.height).data, 384, bt.height);
    out.catRows = window.Cat.frames(rows, 'normal').filter((f) => f[2] === 0xA2).length - bt.height;
    return out;
  });
  assert.equal(r[384].w, 384); assert.equal(r[576].w, 576);
  assert.equal(r[384].gray, 0); assert.equal(r[576].gray, 0);
  assert.ok(r[384].black > 2000 && r[384].h > 500);
  assert.equal(r.catRows, 128);
  await app.close();
});

test('مسار كامل: عميل جديد ← مستحق ← تسديد ← سند ← طباعة صامتة ← إلغاء', async () => {
  const app = await openApp({ db: null, browser, local: { printerName: 'XP-58' } }), p = app.page;
  await p.keyboard.press('Control+n');
  await p.fill('.dialog input >> nth=0', 'حمزة الجديد'); await p.fill('.dialog input >> nth=1', '٠٧٨١١١١١١١١');
  await p.keyboard.press('Enter');
  await p.waitForSelector('.detail h2:has-text("حمزة الجديد")');
  // رقم مكرر بصيغة أخرى يُرفض
  await p.keyboard.press('Escape'); await p.keyboard.press('Control+n');
  await p.fill('.dialog input >> nth=0', 'آخر'); await p.fill('.dialog input >> nth=1', '+964 781 111 1111'); await p.keyboard.press('Enter');
  assert.match(await p.textContent('.dialog .errline'), /مسجّل للعميل «حمزة الجديد»/);
  await p.keyboard.press('Escape');
  await p.click('.dacts .btn:has-text("مستحق جديد")');
  await p.fill('.dialog input.big', '١٠٠٬٠٠٠'); await p.keyboard.press('Enter');
  await p.waitForSelector('.detail .balance b:has-text("100,000")');
  await p.keyboard.press('Control+p');
  await p.fill('.dialog input.big', '40000'); await p.keyboard.press('Enter');
  await p.waitForSelector('.dialog h2:has-text("صدر السند 00001")');
  await p.click('.dialog .btn:has-text("طباعة") >> nth=0');
  await p.waitForFunction(() => window.__lastPrint);
  const pr = await p.evaluate(() => window.__lastPrint);
  assert.equal(pr.width, 384); assert.equal(pr.deviceName, 'XP-58'); assert.equal(pr.silent, true); assert.equal(pr.paper, 'roll');
  await p.click('.dialog .btn:has-text("إلغاء السند")'); await p.click('.dialog .btn:has-text("اضغط مرة أخرى")');
  await p.waitForSelector('.detail .balance b:has-text("100,000")');
  const saved = JSON.parse(await p.evaluate(() => new Promise((r) => setTimeout(() => r(window.__saved), 400))));
  assert.equal(saved.pays[0].void, 1); assert.equal(saved.pays[0].after, 60000); assert.equal(saved.customers[1].phone, '٠٧٨١١١١١١١١');
  assert.deepEqual(app.errors, []);
  await app.close();
});

test('لوحة المفاتيح: الأسهم في الجدول وEnter للتسديد وCtrl+F', async () => {
  const app = await openApp({ db: demo(), browser }), p = app.page;
  await p.keyboard.press('Control+2'); await p.keyboard.press('Control+f');
  await p.keyboard.type('حمزه');
  await p.waitForFunction(() => document.querySelectorAll('.trow').length === 1); await p.waitForTimeout(150);
  assert.match(await p.textContent('.trow'), /حمزة عبدالله/);
  await p.keyboard.press('ArrowDown');
  assert.match(await p.textContent('.detail h2'), /حمزة عبدالله/);
  await p.keyboard.press('Enter'); // Enter في البحث يفتح التسديد للعميل المحدد
  await p.waitForSelector('.dialog h2:has-text("تسديد جديد")');
  await p.keyboard.press('Escape');
  assert.equal(await p.locator('.dialog').count(), 0);
  await app.close();
});

test('11) واتساب من الواجهة', async () => {
  const app = await openApp({ db: demo(), browser }), p = app.page;
  await p.click('.card:has-text("المتأخرون") .line >> nth=0 >> button[aria-label="تذكير واتساب"]');
  const url = await p.evaluate(() => window.__lastWa);
  assert.match(url, /^https:\/\/wa\.me\/9647\d{9}\?text=/);
  const t = decodeURIComponent(url.split('text=')[1]);
  assert.match(t, /دينار/); assert.match(t, /محل النور للاتصالات/); assert.match(t, /\d{4}-\d{2}-\d{2}/);
  await app.close();
});

test('7) و9) الاستيراد والاستعادة من الواجهة (ونسخة الهاتف)', async () => {
  const csvRows = [['الاسم', 'رقم الجوال', 'الرصيد السابق'], ['حسن كاظم', '07700000001', '150000'], ['حسن ك.', '+964 770 000 0001', '5'], ['زينب', '07811111112', ''], ['', '079', '1'], ['علي', '07500000002', '25000']];
  const app = await openApp({ db: null, browser }), p = app.page;
  await p.evaluate((rows) => { window.__MOCK_OPEN_TABLE = { ok: true, rows, name: 'عملاء.csv' }; }, csvRows);
  await p.click('.btn:has-text("استيراد من Excel/CSV")');
  assert.match(await p.textContent('.dialog .note'), /سيُضاف 3 عميل جديد • 1 مكرر سيُتجاهل • 1 سطر بلا اسم/);
  await p.click('.dialog footer .btn:has-text("استيراد")');
  await p.waitForSelector('.trow:has-text("علي")');
  assert.equal(await p.locator('.trow').count(), 3);
  // ملف خاطئ يُرفض
  await p.evaluate(() => { window.__MOCK_OPEN_BACKUP = { ok: true, name: 'x.json', text: '{"app":"other"}' }; });
  await p.keyboard.press('Control+5'); await p.click('.btn:has-text("استعادة نسخة")');
  await p.waitForSelector('.toast:has-text("ليس نسخة احتياطية")');
  // نسخة الهاتف الحقيقية
  const phone = fs.readFileSync(path.join(__dirname, '..', 'fixtures', 'phone-backup.json'), 'utf8');
  await p.evaluate((t) => { window.__MOCK_OPEN_BACKUP = { ok: true, name: 'ledger-backup.json', text: t }; }, phone);
  await p.click('.btn:has-text("استعادة نسخة")');
  assert.match(await p.textContent('.dialog'), /عدد العملاء في النسخة\s*2/);
  await p.click('.dialog .btn:has-text("استبدال")'); await p.click('.dialog .btn:has-text("اضغط مرة أخرى")');
  await p.waitForSelector('.tally');
  const st = await p.evaluate(() => { const L = window.__app.L; return { n: L.activeCustomers().length, shop: L.db.cfg.shop, bal: L.acct(1).bal }; });
  assert.deepEqual(st, { n: 2, shop: 'محل الهاتف', bal: 675000 });
  // تصدير Excel للأرصدة
  await p.keyboard.press('Control+4'); await p.click('.btn:has-text("أرصدة العملاء (Excel)")');
  const sh = await p.evaluate(() => window.__lastSheets);
  assert.equal(sh[0].rows.length, 3); assert.equal(sh[0].rows[0][0], 'الاسم');
  await app.close();
});

test('12) أداء الواجهة مع 5,000 عميل و20,000 مستحق و8,000 سند', async () => {
  const app = await openApp({ db: generate(), browser, width: 1366, height: 768 }), p = app.page;
  const m = await p.evaluate(async () => {
    const A = window.__app, t = (fn) => { const s = performance.now(); fn(); return performance.now() - s; }, out = {};
    out.home = t(() => A.go('home'));
    out.customers = t(() => A.go('cust'));
    const q = document.getElementById('cust-search');
    out.search = t(() => { A.state.cust.q = 'حمزه'; A.currentView().refresh(); });
    out.rows = document.querySelectorAll('.trow').length;
    out.receipts = t(() => { A.state.rec.range = 'all'; A.go('rec'); });
    out.reports = t(() => { A.state.rep.range = 'all'; A.go('rep'); });
    A.go('cust'); A.state.cust.q = ''; A.currentView().refresh();
    const id = A.L.activeCustomers()[0].id;
    out.payment = t(() => { A.L.addPayment(id, 1000, 'cash', '', window.Core.today()); A.refresh(); });
    return out;
  });
  console.log('  ' + Object.entries(m).map(([k, v]) => k + '=' + (typeof v === 'number' && k !== 'rows' ? v.toFixed(0) + 'ms' : v)).join('  '));
  for (const k of ['home', 'customers', 'search', 'receipts', 'reports', 'payment']) assert.ok(m[k] < 100, k + ' ' + m[k].toFixed(0) + 'ms');
  assert.ok(m.rows < 60, 'التمرير الافتراضي يرسم الصفوف الظاهرة فقط');
  await app.close();
});
