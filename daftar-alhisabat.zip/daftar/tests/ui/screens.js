// تصوير الشاشات الرئيسية بالوضعين: node tests/ui/screens.js <outdir>
const { chromium } = require('playwright');
const { openApp } = require('./harness');
const { demo } = require('../tools/demo');
const out = process.argv[2] || 'shots';
(async () => {
  const browser = await chromium.launch(), db = demo(), allErr = [];
  for (const scheme of ['light', 'dark']) {
    const app = await openApp({ db, scheme, browser, local: { printerName: 'XP-58' } }), p = app.page;
    const shot = (n) => p.screenshot({ path: `${out}/${scheme}-${n}.png` });
    await p.waitForTimeout(150); await shot('1-home');
    await p.keyboard.press('Control+2'); await p.waitForTimeout(100);
    await p.keyboard.press('ArrowDown'); await p.keyboard.press('ArrowDown'); await p.waitForTimeout(100); await shot('2-customers');
    await p.keyboard.press('Control+p'); await p.waitForTimeout(150); await shot('3-pay');
    await p.keyboard.press('Enter'); await p.waitForTimeout(300); await shot('4-receipt');
    await p.keyboard.press('Escape');
    await p.click('.dacts .btn:has-text("مستحق جديد")'); await p.click('.dialog .seg button:has-text("أقساط")');
    await p.fill('.dialog input.big', '600000'); await p.waitForTimeout(100); await shot('5-charge');
    await p.keyboard.press('Escape');
    await p.keyboard.press('Control+3'); await p.click('.chip:has-text("الكل")'); await p.waitForTimeout(100); await shot('6-receipts');
    await p.keyboard.press('Control+4'); await p.click('.chip:has-text("الكل")'); await p.waitForTimeout(100); await shot('7-reports');
    await p.keyboard.press('Control+5'); await p.waitForTimeout(150); await shot('8-settings');
    allErr.push(...app.errors.map((e) => scheme + ' ' + e)); await app.close();
  }
  // شاشة 1920 وحالة البداية الفارغة
  let app = await openApp({ db, browser, width: 1920, height: 1080 }); await app.page.keyboard.press('Control+2'); await app.page.waitForTimeout(100); await app.page.screenshot({ path: `${out}/wide-customers.png` }); allErr.push(...app.errors); await app.close();
  app = await openApp({ db: null, browser }); await app.page.screenshot({ path: `${out}/empty-home.png` }); allErr.push(...app.errors); await app.close();
  await browser.close();
  console.log(allErr.length ? 'ERRORS:\n' + allErr.join('\n') : 'no console errors');
})().catch((e) => { console.error(e); process.exit(1); });
