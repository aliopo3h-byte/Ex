// يشغّل الواجهة في Chromium مع window.api بديل. يُستعمل للتصوير ولاختبارات الواجهة.
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
async function openApp({ db, local, scheme = 'light', width = 1366, height = 768, browser }) {
  const own = !browser; browser = browser || await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width, height }, colorScheme: scheme, deviceScaleFactor: 1, locale: 'en-GB' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.clock.install({ time: new Date(2026, 10, 15, 10, 30) });
  await page.route(/^https?:/, (r) => r.abort());
  await page.addInitScript(({ db, local }) => { window.__MOCK_DB = db; window.__MOCK_LOCAL = local; }, { db, local });
  await page.addInitScript({ path: path.join(__dirname, 'mock-api.js') });
  await page.goto('file://' + path.join(__dirname, '..', '..', 'renderer', 'index.html'));
  await page.waitForFunction(() => window.__app && window.__app.ready);
  return { page, ctx, browser, errors, close: async () => { await ctx.close(); if (own) await browser.close(); } };
}
module.exports = { openApp };
