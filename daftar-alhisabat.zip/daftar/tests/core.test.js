'use strict';
// اختبارات القبول لقواعد العمل (القسم 8): node --test
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const Core = require('../shared/core');

const at = (isoDate, h = 10) => () => { const p = isoDate.split('-'); return new Date(+p[0], +p[1] - 1, +p[2], h, 30, 0); };
function referenceCase() {
  Core.setNow(at('2026-11-15'));
  const L = new Core.Ledger(Core.blank());
  const c = L.addCustomer('أحمد علي', '07701234567');
  L.addCharge(c.id, 100000, '2026-11-10', 'فاتورة');
  L.addInstallments(c.id, 600000, 6, '2026-12-01', 'جهاز');
  L.addSub(c.id, 25000, 5, '2026-11', 'اشتراك إنترنت');
  return { L, c };
}

test('1) المثال المرجعي بتاريخ 2026-11-15', () => {
  const { L, c } = referenceCase();
  const a = L.acct(c.id);
  assert.equal(a.total, 725000);
  assert.equal(a.bal, 725000);
  assert.equal(a.overdue, 125000);
  assert.equal(a.maxLate, 10);
  const inst = L.db.charges.filter((x) => x.kind === 'inst');
  assert.equal(inst.length, 6);
  assert.ok(inst.every((x) => x.amt === 100000));
  assert.equal(inst[5].due, '2027-05-01');
  assert.equal(inst[0].desc, 'جهاز 1/6');
  const sub = L.db.charges.find((x) => x.kind === 'sub');
  assert.equal(sub.due, '2026-11-05');
  assert.equal(a.next.due, '2026-11-05');
  assert.equal(a.oldestLate, '2026-11-05');
});

test('2) تسديد 50,000 يُوزَّع على الأقدم استحقاقاً', () => {
  const { L, c } = referenceCase();
  const p = L.addPayment(c.id, 50000, 'cash', '', '2026-11-15');
  const a = L.acct(c.id);
  const sub = a.items.find((i) => i.c.kind === 'sub'), debt = a.items.find((i) => i.c.kind === 'debt');
  assert.equal(sub.status, 'paid'); assert.equal(sub.paid, 25000);
  assert.equal(debt.status, 'part'); assert.equal(debt.paid, 25000); assert.equal(debt.left, 75000);
  assert.equal(a.bal, 675000);
  assert.equal(a.overdue, 75000);
  assert.equal(p.after, 675000);
  assert.equal(p.no, 1);
  assert.equal(L.afterText(p.after), 'المتبقي عليكم: 675,000');
  assert.match(L.receiptText(p), /المتبقي عليكم: 675,000/);
});

test('3) التسديد الزائد يعطي رصيداً له ويصفّر المتأخر', () => {
  const { L, c } = referenceCase();
  const p = L.addPayment(c.id, 800000, 'transfer', '', '2026-11-15');
  const a = L.acct(c.id);
  assert.equal(a.bal, -75000);
  assert.equal(a.overdue, 0);
  assert.equal(a.maxLate, 0);
  assert.equal(L.afterText(p.after), 'رصيد لكم: 75,000');
});

test('4) إلغاء سند ثم استرجاعه', () => {
  const { L, c } = referenceCase();
  const p = L.addPayment(c.id, 50000, 'cash', '', '2026-11-15');
  L.setPayVoid(p, true);
  assert.equal(L.acct(c.id).bal, 725000);
  assert.equal(L.acct(c.id).overdue, 125000);
  assert.equal(L.totals().today, 0);
  assert.ok(L.db.pays.includes(p), 'الإلغاء لا يحذف السجل');
  L.setPayVoid(p, false);
  assert.equal(L.acct(c.id).bal, 675000);
  assert.equal(L.totals().today, 50000);
});

test('5) الاشتراك الشهري: توليد، إيقاف، واستئناف بلا تعويض', () => {
  const { L, c } = referenceCase();
  const s = L.db.subs[0];
  Core.setNow(at('2026-12-02'));
  assert.equal(L.genSubs(), 1);
  const dec = L.db.charges.filter((x) => x.kind === 'sub').map((x) => x.due);
  assert.deepEqual(dec, ['2026-11-05', '2026-12-05']);
  L.toggleSub(s); assert.equal(s.active, 0);
  Core.setNow(at('2027-02-20'));
  assert.equal(L.genSubs(), 0, 'الموقوف لا يضيف شيئاً');
  Core.setNow(at('2027-03-10'));
  assert.equal(L.genSubs(), 0);
  L.toggleSub(s); assert.equal(s.active, 1);
  const subs = L.db.charges.filter((x) => x.kind === 'sub').map((x) => x.due);
  assert.deepEqual(subs, ['2026-11-05', '2026-12-05', '2027-03-05'], 'مارس فقط، بلا يناير وفبراير');
  // تغيّر التاريخ لا يكرر الشهر نفسه
  assert.equal(L.genSubs(), 0);
  assert.equal(L.acct(c.id).items.length, 10); // دين + 6 أقساط + 3 أشهر اشتراك
});

test('5ب) اشتراك يبدأ الشهر القادم ويوم 31 يُضبط لآخر الشهر', () => {
  Core.setNow(at('2027-01-20'));
  const L = new Core.Ledger(Core.blank());
  const c = L.addCustomer('س', '');
  L.addSub(c.id, 1000, 31, Core.nextYm('2027-01'), '');
  assert.equal(L.db.charges.length, 0);
  Core.setNow(at('2027-02-01'));
  L.genSubs();
  assert.equal(L.db.charges[0].due, '2027-02-28');
});

test('6) تقريب الأقساط وضبط آخر الشهر', () => {
  Core.setNow(at('2026-11-15'));
  const L = new Core.Ledger(Core.blank());
  assert.deepEqual(L.splitInstallments(100000, 3), [33333.33, 33333.33, 33333.34]);
  const c = L.addCustomer('ب', '');
  const out = L.addInstallments(c.id, 100000, 3, '2027-01-31', '');
  assert.deepEqual(out.map((x) => x.due), ['2027-01-31', '2027-02-28', '2027-03-31']);
  assert.deepEqual(out.map((x) => x.desc), ['قسط 1/3', 'قسط 2/3', 'قسط 3/3']);
  assert.equal(Core.r2(out.reduce((s, x) => s + x.amt, 0)), 100000);
});

test('7) استيراد CSV: فاصلة منقوطة وBOM وأرقام عربية ومكرر بصيغة أخرى', () => {
  Core.setNow(at('2026-11-15'));
  const csv = '\uFEFFالاسم;رقم الجوال;الرصيد السابق\r\n' +
    'حسن كاظم;07700000001;١٥٠٬٠٠٠\r\n' +
    'حسن ك.;+964 770 000 0001;5000\r\n' +
    'زينب محمد;٠٧٨١١١١١١١١;\r\n' +
    ';07900000000;100\r\n' +
    'علي حسين;07500000002;25000.5\r\n';
  const rows = Core.cleanRows(Core.parseCsv(csv));
  const cols = Core.detectColumns(rows[0]);
  assert.deepEqual(cols, { name: 0, phone: 1, bal: 2 });
  const L = new Core.Ledger(Core.blank());
  const plan = L.planImport(rows, cols);
  assert.equal(plan.ok, 3); assert.equal(plan.dup, 1); assert.equal(plan.bad, 1);
  assert.equal(L.applyImport(plan.list), 3);
  const names = L.activeCustomers().map((c) => c.name).sort();
  assert.deepEqual(names, ['حسن كاظم', 'زينب محمد', 'علي حسين'].sort());
  const prev = L.db.charges.filter((x) => x.desc === 'رصيد سابق');
  assert.equal(prev.length, 2);
  assert.deepEqual(prev.map((x) => x.amt).sort((a, b) => a - b), [25000.5, 150000]);
  assert.ok(prev.every((x) => x.date === '2026-11-15' && x.due === '2026-11-15' && x.kind === 'debt'));
  // إعادة الاستيراد نفسه: كلها مكررة الآن
  assert.equal(L.planImport(rows, cols).ok, 0);
  // كشف المكرر عند الإضافة اليدوية
  assert.equal(L.findDup('+964 770 000 0001').name, 'حسن كاظم');
});

test('7ب) CSV بفاصلة وتبويب ونصوص بين علامات تنصيص', () => {
  assert.deepEqual(Core.parseCsv('a,b\n"x, y","q""t"\n'), [['a', 'b'], ['x, y', 'q"t']]);
  assert.deepEqual(Core.parseCsv('a\tb\n1\t2'), [['a', 'b'], ['1', '2']]);
});

test('8) البحث يتجاهل الفروق الإملائية ويقبل جزءاً من الرقم', () => {
  const L = new Core.Ledger(Core.blank());
  const c = L.addCustomer('حمزة عبدالله', '0770 123 4567');
  const c2 = L.addCustomer('إسراء', '07811111111');
  L.addCustomer('مُصْطَفَى', '');
  const q = (s) => L.customerList(s, 'all', 'name').list.map((x) => x.c.id);
  assert.deepEqual(q('حمزه'), [c.id]);
  assert.deepEqual(q('اسراء'), [c2.id]);
  assert.deepEqual(q('1234'), [c.id]);
  assert.deepEqual(q('٠٧٧٠١٢'), [c.id]);
  assert.deepEqual(q('781111'), [c2.id]);
  assert.equal(q('مصطفي').length, 1);
  assert.equal(q('ـحمـزة').length, 1);
});

test('9) نسخة احتياطية ← حذف كل شيء ← استعادة', () => {
  const { L } = referenceCase();
  L.db.cfg.shop = 'محل النور'; L.db.cfg.curr = 'دينار'; L.db.cfg.cc = '964';
  L.addPayment(L.activeCustomers()[0].id, 50000, 'cash', 'دفعة', '2026-11-15');
  const snapshot = JSON.parse(JSON.stringify(L.db));
  const text = JSON.stringify(Core.makeBackup(L.db));
  L.replace(Core.blank());
  assert.equal(L.activeCustomers().length, 0);
  const v = Core.parseBackupText(text);
  assert.equal(v.ok, true); assert.equal(v.n, 1);
  L.replace(v.obj.db);
  assert.deepEqual(L.db, snapshot);
  assert.equal(L.acct(L.activeCustomers()[0].id).bal, 675000);
  // ملفات خاطئة تُرفض برسالة واضحة
  assert.match(Core.parseBackupText('not json').err, /تالف/);
  assert.match(Core.parseBackupText('{"app":"other","db":{}}').err, /ليس نسخة/);
  assert.match(Core.parseBackupText('{"app":"ledger","db":{"customers":[]}}').err, /تالفة/);
});

test('9ب) نسخة من تطبيق الهاتف تُستعاد وتُحسب كما في الهاتف', () => {
  const f = path.join(__dirname, 'fixtures', 'phone-backup.json');
  const v = Core.parseBackupText(fs.readFileSync(f, 'utf8'));
  assert.equal(v.ok, true);
  const expect = v.obj._expect; // أرقام حسبها تطبيق الهاتف نفسه عند توليد الملف
  Core.setNow(at(expect.today));
  const L = new Core.Ledger(v.obj.db);
  assert.equal(L.activeCustomers().length, v.n);
  for (const e of expect.accounts) {
    const a = L.acct(e.id);
    assert.equal(a.bal, e.bal); assert.equal(a.overdue, e.overdue); assert.equal(a.maxLate, e.maxLate);
  }
  // وصيغة النسخة المصدّرة من الحاسوب هي نفسها التي يقبلها الهاتف
  const back = Core.makeBackup(L.db);
  assert.deepEqual(Object.keys(back), ['app', 'v', 'at', 'db']);
  assert.deepEqual(Object.keys(back.db), ['v', 'seq', 'customers', 'charges', 'pays', 'subs', 'cfg', 'meta']);
  assert.deepEqual(Object.keys(back.db.cfg).sort(), ['cc', 'curr', 'dens', 'foot', 'pre', 'printer', 'pw', 'shop', 'shopph', 'theme', 'tpl'].sort());
});

test('11) رابط واتساب ونص التذكير', () => {
  const { L, c } = referenceCase();
  L.db.cfg.cc = '964'; L.db.cfg.curr = 'دينار'; L.db.cfg.shop = 'محل النور';
  c.phone = '07811111111';
  const text = L.reminderText(c), link = L.waLink(c.phone, text);
  assert.ok(link.startsWith('https://wa.me/9647811111111?text='));
  const decoded = decodeURIComponent(link.split('?text=')[1]);
  assert.match(decoded, /125,000 دينار/);
  assert.match(decoded, /2026-11-05/);
  assert.match(decoded, /محل النور/);
  assert.match(decoded, /أحمد علي/);
  assert.equal(Core.intl('+964 781 111 1111', '964'), '9647811111111');
  assert.equal(Core.intl('009647811111111', '964'), '9647811111111');
  assert.equal(Core.intl('7811111111', '964'), '9647811111111');
  assert.equal(Core.intl('٠٧٨١١١١١١١١', '964'), '9647811111111');
});

test('المبالغ: أرقام عربية وفواصل', () => {
  assert.equal(Core.parseAmt('١٬٢٥٠٫٥'), 1250.5);
  assert.equal(Core.parseAmt('1,250.555'), 1250.56);
  assert.equal(Core.parseAmt('-5'), 0);
  assert.equal(Core.parseAmt('abc'), 0);
  assert.equal(Core.parseAmt(''), 0);
});

test('لا تسديد بتاريخ مستقبلي', () => {
  const { L, c } = referenceCase();
  assert.throws(() => L.addPayment(c.id, 10, 'cash', '', '2026-11-16'), /مستقبلي/);
  const p = L.addPayment(c.id, 10, 'cash', '', '2026-11-01');
  assert.equal(p.d, '2026-11-01');
});

test('أعمار المتأخرات والتقارير', () => {
  Core.setNow(at('2026-11-15'));
  const L = new Core.Ledger(Core.blank());
  const c = L.addCustomer('أ', '');
  L.addCharge(c.id, 10, '2026-11-01'); L.addCharge(c.id, 20, '2026-09-20'); L.addCharge(c.id, 30, '2026-08-20'); L.addCharge(c.id, 40, '2026-01-01');
  assert.deepEqual(L.aging().amt, [10, 20, 30, 40]);
  L.addPayment(c.id, 5, 'transfer', '', '2026-11-15');
  L.addPayment(c.id, 7, 'cash', '', '2026-11-14');
  const r = L.report('month');
  assert.equal(r.sum, 12); assert.equal(r.byM.transfer, 5); assert.equal(r.byM.cash, 7); assert.equal(r.issued, 100);
  assert.equal(L.report('yday').sum, 7);
  assert.equal(L.receipts('all', '00002').length, 1);
});
