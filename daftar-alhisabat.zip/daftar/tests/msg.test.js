// قراءة رسالة الاشتراك الملصوقة وترتيبها في حقول الوصل
const test = require('node:test');
const assert = require('node:assert');
const Msg = require('../shared/msg.js');

test('رسالة بوسوم كاملة وأخطاء إملائية شائعة', () => {
  const m = Msg.parse('تحيه طيبه عزيزي المشترك\nالاسم: علي حسين\nنوع الاشتراك: باقة 50 ميغا\nتم استلام مبلغ 35,000 دينار\nوالمتبقي 10,000 دينار\nالموضف المستلم: احمد\nعنوان المكتب: بغداد - الكرادة\nرقم الماستر كارد للتحويل: 7123456789101112\nاسم صاحب الماستر كارد: محمد جاسم');
  assert.equal(m.name, 'علي حسين'); assert.equal(m.sub, 'باقة 50 ميغا');
  assert.equal(m.amount, '35,000 دينار'); assert.equal(m.remain, '10,000 دينار');
  assert.equal(m.emp, 'احمد'); assert.equal(m.addr, 'بغداد - الكرادة');
  assert.equal(m.card, '7123 4567 8910 1112'); assert.equal(m.holder, 'محمد جاسم');
});

test('أرقام عربية، مبلغان في سطر، اسم بلا وسم، وسطر تسديد وتفعيل', () => {
  const m = Msg.parse('*تحية طيبة عزيزي المشترك* 🌹\nمحمد عبد الله\nالاشتراك\nشهري 35 ميغا\nتم استلام مبلغ ٢٥٠٠٠ والمتبقي ٠\nتم تسديد وتفعيل الاشتراك ✅\nالموظف: سيف\nماستر كارد\n٧١٢٣٤٥٦٧٨٩١٠١١١٢\nباسم: علي محمد');
  assert.equal(m.name, 'محمد عبد الله'); assert.equal(m.sub, 'شهري 35 ميغا');
  assert.equal(m.amount, '25000'); assert.equal(m.remain, '0');
  assert.equal(m.status, 'تم تسديد وتفعيل الاشتراك'); assert.equal(m.emp, 'سيف');
  assert.equal(m.card, '7123 4567 8910 1112'); assert.equal(m.holder, 'علي محمد');
  assert.deepEqual(m.notes, []);
});
