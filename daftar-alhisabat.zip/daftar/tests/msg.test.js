// قراءة رسالة الاشتراك الملصوقة وترتيبها في حقول الوصل
const test = require('node:test');
const assert = require('node:assert');
const Msg = require('../shared/msg.js');

const RECEIPT = `تحية طيبة عزيزي المشترك
اليوزر : ......
حضرة السيد : أحمد علي
تم استلام مبلغ قدره : *36000*
من اصل : *36000*
والمتبقي : *0*
تم الاستلام بواسطة ......
*الشبكة العراقية الحكومية لخدمات الانترنت الضوئي والهاتف الارضي*
للاستفسار الاتصال على الرقم 07748038682
ــــــــــــ
عنوان المكتب - شارع نعمة الريفي - مقابل حلويات الحمداني
ـــــــــــ
للتواصل مع مندوب الجبايه الاتصال على الرقم 
07703377661`;
const ACTIVATE = `تحية طيبة عزيزي المشترك
تم تفعيل اشتراك الانترنت فئة : ......
البطاقة : .........
اليوزر ..........
حضرة السيد : ......
مبلغ الاشتراك : *36000*
تم استلام مبلغ قدره : *0*
والمبلغ المتبقي : *36000*
تاريخ انتهاء الاشتراك : 2026-12-03
تم التفعيل بواسطة : ابو الحسن 
*الشبكة العراقية الحكومية لخدمات الانترنت الضوئي والهاتف الارضي*
للاستفسار الاتصال على الرقم 07748038682
ــــــــــــــــــ
عنوان المكتب - شارع نعمة الريفي - مقابل حلويات الحمداني
ـــــــــــــــــ
للتواصل مع مندوب الجبايه الاتصال على الرقم 
07703377661
ـــــــــــــ
لتحويل المبلغ عن طريق الكي كارد المدرجه ادناه.... بعد التحويل يرجى ارسال صوة التحويل ....
HASAN HAYDER OWADE

1568890600`;

test('رسالة استلام مبلغ: القيم الفارغة (......) تُهمل والأسطر الدعائية تُحذف', () => {
  const m = Msg.parse(RECEIPT);
  assert.equal(m.kind, 'receipt'); assert.equal(m.name, 'أحمد علي'); assert.equal(m.user, ''); assert.equal(m.emp, '');
  assert.equal(m.amount, '36000'); assert.equal(m.total, '36000'); assert.equal(m.remain, '0');
  assert.equal(m.inq, '07748038682'); assert.equal(m.collector, '07703377661');
  assert.equal(m.addr, 'شارع نعمة الريفي - مقابل حلويات الحمداني');
  assert.deepEqual(m.notes, []);
});

test('رسالة تفعيل اشتراك: التاريخ والموظف والكي كارد', () => {
  const m = Msg.parse(ACTIVATE);
  assert.equal(m.kind, 'activate'); assert.equal(m.total, '36000'); assert.equal(m.amount, '0'); assert.equal(m.remain, '36000');
  assert.equal(m.expiry, '2026-12-03'); assert.equal(m.emp, 'ابو الحسن');
  assert.equal(m.holder, 'HASAN HAYDER OWADE'); assert.equal(m.card, '1568890600');
  assert.equal(m.sub, ''); assert.equal(m.scratch, ''); assert.deepEqual(m.notes, []);
});

test('صيغة أخرى: أرقام عربية ومبلغان في سطر واحد وسطر تسديد وتفعيل', () => {
  const m = Msg.parse('*تحية طيبة عزيزي المشترك* 🌹\nمحمد عبد الله\nالاشتراك\nشهري 35 ميغا\nتم استلام مبلغ ٢٥٠٠٠ والمتبقي ٠\nتم تسديد وتفعيل الاشتراك ✅\nالموضف: سيف\nماستر كارد\n٧١٢٣٤٥٦٧٨٩١٠١١١٢\nباسم: علي محمد');
  assert.equal(m.name, 'محمد عبد الله'); assert.equal(m.sub, 'شهري 35 ميغا');
  assert.equal(m.amount, '25000'); assert.equal(m.remain, '0');
  assert.equal(m.status, 'تم تسديد وتفعيل الاشتراك'); assert.equal(m.emp, 'سيف');
  assert.equal(m.card, '7123 4567 8910 1112'); assert.equal(m.holder, 'علي محمد');
});
