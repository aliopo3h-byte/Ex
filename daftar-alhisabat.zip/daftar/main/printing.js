'use strict';
// الطباعة على Windows: صورة الوصل بمقاس الورق الصحيح عبر نافذة مخفية، أو تقرير A4، أو ESC/POS عبر الشبكة.
const { BrowserWindow } = require('electron');
const fs = require('fs');
const os = require('os');
const path = require('path');
const net = require('net');

// 384 نقطة = 48 ملم مطبوعة على ورق 58 ملم؛ 576 نقطة = 72 ملم على ورق 80 ملم (203 نقطة/بوصة)
function paperFor(widthDots) { return widthDots >= 576 ? { paperMm: 80, imgMm: 72 } : { paperMm: 58, imgMm: 48 }; }

function failText(reason) {
  const r = String(reason || '').toLowerCase();
  if (r.includes('cancel')) return 'أُلغيت الطباعة.';
  if (r.includes('invalid printer') || r.includes('not found')) return 'الطابعة غير موجودة. اخترها مجدداً من الإعدادات.';
  if (r.includes('offline')) return 'الطابعة غير متصلة.';
  return 'تعذّرت الطباعة' + (reason ? ' (' + reason + ')' : '') + '. تأكد أن الطابعة متصلة وفيها ورق.';
}

async function withHiddenPage(html, fn) {
  const file = path.join(os.tmpdir(), 'daftar-print-' + process.pid + '-' + Date.now() + '.html');
  fs.writeFileSync(file, html, 'utf8');
  const win = new BrowserWindow({ show: false, webPreferences: { javascript: false, sandbox: true, contextIsolation: true, nodeIntegration: false } });
  try {
    await win.loadFile(file);
    return await fn(win);
  } finally {
    if (!win.isDestroyed()) win.destroy();
    fs.unlink(file, () => {});
  }
}

function printWith(win, opts) {
  return new Promise((resolve) => {
    win.webContents.print(opts, (ok, reason) => resolve(ok ? { ok: true } : { ok: false, error: failText(reason), cancelled: /cancel/i.test(reason || '') }));
  });
}

// يطبع صورة PNG (data URL) بعرض الورق الحراري، أو على A4
async function printImage({ dataUrl, width, height, deviceName, paper, silent }) {
  if (!/^data:image\/png;base64,/.test(String(dataUrl))) return { ok: false, error: 'صورة غير صالحة.' };
  const p = paperFor(width), hMm = (height / width) * p.imgMm;
  const a4 = paper === 'a4';
  const css = a4
    ? '@page{size:A4;margin:10mm}html,body{margin:0;background:#fff}img{display:block;width:' + p.imgMm + 'mm;margin:0 auto}'
    : '@page{size:' + p.paperMm + 'mm ' + Math.ceil(hMm + 6) + 'mm;margin:0}html,body{margin:0;background:#fff}img{display:block;width:' + p.imgMm + 'mm;margin:2mm auto 0}';
  const html = '<!doctype html><html><head><meta charset="utf-8"><style>' + css + '</style></head><body><img src="' + dataUrl + '"></body></html>';
  return withHiddenPage(html, (win) => {
    const opts = { silent: !!silent, printBackground: false, color: false, margins: { marginType: 'none' } };
    if (deviceName) opts.deviceName = deviceName;
    if (a4) opts.pageSize = 'A4';
    else opts.pageSize = { width: p.paperMm * 1000, height: Math.max(20000, Math.ceil((hMm + 6) * 1000)) };
    return printWith(win, opts);
  });
}

// تقرير A4: طباعة بحوار النظام، أو حفظ PDF
async function printHtml(html, deviceName) {
  return withHiddenPage(html, (win) => printWith(win, Object.assign({ silent: false, printBackground: true, pageSize: 'A4' }, deviceName ? { deviceName } : {})));
}
async function htmlToPdf(html) {
  return withHiddenPage(html, (win) => win.webContents.printToPDF({ pageSize: 'A4', printBackground: true, margins: { marginType: 'default' } }));
}

/* ESC/POS عبر الشبكة (منفذ 9100): صورة نقطية بالأمر GS v 0 على دفعات من 255 سطراً ثم قصّ الورق.
   bits: صفوف معبّأة، البت 7 = أقصى اليسار، 1 = أسود. */
function escposRaster(bits, width, height) {
  const bpr = Math.ceil(width / 8), parts = [Buffer.from([0x1B, 0x40])];
  for (let y = 0; y < height; y += 255) {
    const h = Math.min(255, height - y);
    parts.push(Buffer.from([0x1D, 0x76, 0x30, 0x00, bpr & 255, bpr >> 8, h & 255, h >> 8]));
    parts.push(Buffer.from(bits.subarray(y * bpr, (y + h) * bpr)));
  }
  parts.push(Buffer.from([0x1B, 0x64, 0x04, 0x1D, 0x56, 0x42, 0x00]));
  return Buffer.concat(parts);
}
function sendTcp(host, port, data, timeoutMs = 6000) {
  return new Promise((resolve) => {
    if (!/^[A-Za-z0-9.\-:]+$/.test(String(host || ''))) { resolve({ ok: false, error: 'عنوان الطابعة غير صالح.' }); return; }
    const sock = net.createConnection({ host, port: +port || 9100 });
    let done = false;
    const fin = (r) => { if (done) return; done = true; sock.destroy(); resolve(r); };
    sock.setTimeout(timeoutMs, () => fin({ ok: false, error: 'لا ترد الطابعة على ' + host + '. تأكد من العنوان وأنها على نفس الشبكة.' }));
    sock.on('error', (e) => fin({ ok: false, error: 'تعذّر الاتصال بالطابعة (' + (e.code || e.message) + ').' }));
    sock.on('connect', () => sock.end(Buffer.from(data), () => setTimeout(() => fin({ ok: true }), 150)));
  });
}

module.exports = { paperFor, printImage, printHtml, htmlToPdf, escposRaster, sendTcp, failText };
