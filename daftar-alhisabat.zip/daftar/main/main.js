'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, nativeTheme, session, clipboard, Menu, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const { Store, autoBackup, errText, writeAtomicSync } = require('./store');
const printing = require('./printing');
const { writeXlsx } = require('./xlsx');
const { readTable } = require('./importer');

// البيانات في %APPDATA%/DaftarAlHisabat (يجب ضبطه قبل ready)
// --data-dir=<مجلد> لاختبارات التشغيل فقط، حتى لا تمس بيانات المستخدم الحقيقية
const dataDirArg = process.argv.find((a) => a.startsWith('--data-dir='));
app.setPath('userData', dataDirArg ? dataDirArg.slice(11) : path.join(app.getPath('appData'), 'DaftarAlHisabat'));
app.setAppUserModelId('com.daftar.hisabat');
// حقل التاريخ بأرقام غربية وترتيب يوم/شهر/سنة
app.commandLine.appendSwitch('lang', 'en-GB');

const store = new Store(app.getPath('userData'));
let local = store.loadLocal();
let win = null;
let btCallback = null;

function logError(e) {
  try {
    const dir = path.join(app.getPath('userData'), 'logs'); fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(path.join(dir, 'errors.log'), new Date().toISOString() + ' ' + (e && e.stack ? e.stack : String(e)) + '\n');
  } catch (x) { /* */ }
}
process.on('uncaughtException', logError);
process.on('unhandledRejection', logError);

function localToday() { const d = new Date(), p = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); }
function saveLocal() { try { store.saveLocal(local); } catch (e) { logError(e); } }

function runAutoBackup(force) {
  if (!local.backupDir || !store.lastJson) return { done: false, reason: local.backupDir ? 'empty' : 'nodir' };
  const td = localToday();
  if (!force && local.lastAutoBackup === td) return { done: false, reason: 'today' };
  try {
    const r = autoBackup(local.backupDir, store.lastJson, td, 14);
    local.lastAutoBackup = td; saveLocal();
    if (win && !win.isDestroyed()) win.webContents.send('backup:done', { at: Date.now(), file: r.file });
    return r;
  } catch (e) {
    logError(e);
    const msg = 'تعذّرت النسخة الاحتياطية التلقائية: ' + errText(e);
    if (win && !win.isDestroyed()) win.webContents.send('app:error', msg);
    return { done: false, error: msg };
  }
}

function createWindow() {
  const b = local.winBounds;
  const visible = b && screen.getAllDisplays().some((d) => { const a = d.workArea; return b.x < a.x + a.width && b.x + b.width > a.x && b.y < a.y + a.height && b.y + b.height > a.y; });
  win = new BrowserWindow({
    width: visible ? b.width : 1360, height: visible ? b.height : 840, x: visible ? b.x : undefined, y: visible ? b.y : undefined,
    minWidth: 1024, minHeight: 640, show: false, backgroundColor: nativeTheme.shouldUseDarkColors ? '#0F1716' : '#F4F6F3',
    title: 'دفتر الحسابات', icon: path.join(__dirname, '..', 'build', 'icon.png'), autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, '..', 'preload', 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false, devTools: !app.isPackaged }
  });
  if (visible && b.max) win.maximize();
  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));

  // لا تنقّل ولا نوافذ جديدة: الروابط الخارجية (واتساب فقط) تُفتح في المتصفح عبر IPC
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));

  // اختيار طابعة البلوتوث: نرسل قائمة الأجهزة للواجهة لتعرضها، وهي ترد بالمعرّف
  win.webContents.on('select-bluetooth-device', (event, devices, callback) => {
    event.preventDefault();
    btCallback = callback;
    win.webContents.send('bt:devices', devices.map((d) => ({ id: d.deviceId, name: d.deviceName || '' })));
  });

  const remember = () => { if (!win || win.isDestroyed()) return; const nb = win.getNormalBounds(); local.winBounds = { x: nb.x, y: nb.y, width: nb.width, height: nb.height, max: win.isMaximized() }; };
  win.on('resize', remember); win.on('move', remember);
  win.on('close', () => { remember(); saveLocal(); });
  win.on('closed', () => { win = null; });
}

function lockDownSession() {
  const ses = session.defaultSession;
  // لا اتصال بالإنترنت إطلاقاً من الواجهة
  ses.webRequest.onBeforeRequest((details, cb) => {
    const u = details.url;
    cb({ cancel: !(u.startsWith('file:') || u.startsWith('data:') || u.startsWith('blob:') || u.startsWith('devtools:') || u.startsWith('chrome-extension:')) });
  });
  ses.setPermissionRequestHandler((wc, permission, cb) => cb(false));
  ses.setPermissionCheckHandler((wc, permission) => permission === 'bluetooth');
  ses.setDevicePermissionHandler((d) => d.deviceType === 'bluetooth');
  // بعض الطابعات تطلب إقراناً على Windows: نقبل التأكيد تلقائياً (لا يمكن إدخال رمز PIN)
  if (ses.setBluetoothPairingHandler) ses.setBluetoothPairingHandler((details, cb) => cb({ confirmed: details.pairingKind !== 'providePin' }));
}

/* ---------------- IPC ---------------- */
const dlgFilters = {
  json: [{ name: 'نسخة احتياطية', extensions: ['json'] }],
  csv: [{ name: 'CSV', extensions: ['csv'] }],
  xlsx: [{ name: 'Excel', extensions: ['xlsx'] }],
  pdf: [{ name: 'PDF', extensions: ['pdf'] }],
  png: [{ name: 'صورة PNG', extensions: ['png'] }],
  table: [{ name: 'Excel / CSV', extensions: ['xlsx', 'xls', 'csv', 'txt', 'tsv'] }]
};
async function askSave(name, kind) {
  const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('documents'), name), filters: dlgFilters[kind] });
  return r.canceled || !r.filePath ? null : r.filePath;
}

function registerIpc() {
  ipcMain.handle('db:load', () => {
    const r = store.load();
    return { db: r.db, recovered: r.recovered, error: r.error || null, local, version: app.getVersion(), dataDir: store.dir, isPackaged: app.isPackaged };
  });
  ipcMain.handle('db:save', (e, json) => {
    try { store.save(json); return { ok: true }; } catch (err) { logError(err); return { ok: false, error: errText(err) }; }
  });
  // حفظ متزامن عند إغلاق النافذة حتى لا يضيع آخر تعديل
  ipcMain.on('db:saveSync', (e, json) => {
    try { store.save(json); e.returnValue = true; } catch (err) { logError(err); e.returnValue = false; }
  });
  ipcMain.handle('local:set', (e, patch) => {
    const allowed = ['printerName', 'paper', 'autoPrint', 'btDensity', 'escposHost', 'escposPort', 'printVia'];
    for (const k of allowed) if (patch && Object.prototype.hasOwnProperty.call(patch, k)) local[k] = patch[k];
    saveLocal(); return local;
  });

  ipcMain.handle('file:saveText', async (e, { name, text, kind }) => {
    const fp = await askSave(name, kind || 'csv'); if (!fp) return { ok: false, cancelled: true };
    try { writeAtomicSync(fp, String(text)); return { ok: true, path: fp }; } catch (err) { return { ok: false, error: errText(err) }; }
  });
  ipcMain.handle('file:saveXlsx', async (e, { name, sheets }) => {
    const fp = await askSave(name, 'xlsx'); if (!fp) return { ok: false, cancelled: true };
    try { writeAtomicSync(fp, writeXlsx(sheets)); return { ok: true, path: fp }; } catch (err) { return { ok: false, error: errText(err) }; }
  });
  ipcMain.handle('file:saveImage', async (e, { name, dataUrl }) => {
    const m = /^data:image\/png;base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl)); if (!m) return { ok: false, error: 'صورة غير صالحة.' };
    const fp = await askSave(name, 'png'); if (!fp) return { ok: false, cancelled: true };
    try { writeAtomicSync(fp, Buffer.from(m[1], 'base64')); return { ok: true, path: fp }; } catch (err) { return { ok: false, error: errText(err) }; }
  });
  ipcMain.handle('file:openBackup', async () => {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: dlgFilters.json });
    if (r.canceled || !r.filePaths[0]) return { ok: false, cancelled: true };
    try {
      const st = await fs.promises.stat(r.filePaths[0]);
      if (st.size > 200 * 1024 * 1024) return { ok: false, error: 'الملف كبير جداً ولا يبدو نسخة احتياطية.' };
      return { ok: true, text: await fs.promises.readFile(r.filePaths[0], 'utf8'), name: path.basename(r.filePaths[0]) };
    } catch (err) { return { ok: false, error: 'تعذّرت قراءة الملف: ' + errText(err) }; }
  });
  ipcMain.handle('file:openTable', async () => {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: dlgFilters.table });
    if (r.canceled || !r.filePaths[0]) return { ok: false, cancelled: true };
    try { return { ok: true, rows: await readTable(r.filePaths[0]), name: path.basename(r.filePaths[0]) }; } catch (err) { return { ok: false, error: err.message }; }
  });

  ipcMain.handle('backup:chooseDir', async () => {
    const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'], title: 'مجلد النسخ الاحتياطي التلقائي' });
    if (r.canceled || !r.filePaths[0]) return { ok: false, cancelled: true };
    local.backupDir = r.filePaths[0]; local.lastAutoBackup = ''; saveLocal();
    const res = runAutoBackup(true);
    return { ok: !res.error, dir: local.backupDir, error: res.error || null, local };
  });
  ipcMain.handle('backup:clearDir', () => { local.backupDir = ''; saveLocal(); return local; });
  ipcMain.handle('backup:openDir', () => { if (local.backupDir) shell.openPath(local.backupDir); return true; });
  ipcMain.handle('app:openDataDir', () => { shell.openPath(store.dir); return true; });

  ipcMain.handle('print:list', async () => {
    try { return (await win.webContents.getPrintersAsync()).map((p) => ({ name: p.name, displayName: p.displayName || p.name, isDefault: !!p.isDefault })); }
    catch (e) { return []; }
  });
  ipcMain.handle('print:image', async (e, opts) => {
    try { return await printing.printImage(opts); } catch (err) { logError(err); return { ok: false, error: printing.failText(err.message) }; }
  });
  ipcMain.handle('print:html', async (e, { html }) => {
    try { return await printing.printHtml(String(html), local.paper === 'a4' ? local.printerName : ''); } catch (err) { logError(err); return { ok: false, error: printing.failText(err.message) }; }
  });
  ipcMain.handle('print:pdf', async (e, { html, name }) => {
    const fp = await askSave(name, 'pdf'); if (!fp) return { ok: false, cancelled: true };
    try { writeAtomicSync(fp, await printing.htmlToPdf(String(html))); shell.openPath(fp); return { ok: true, path: fp }; }
    catch (err) { logError(err); return { ok: false, error: errText(err) }; }
  });
  ipcMain.handle('print:escpos', async (e, { bits, width, height }) => {
    if (!local.escposHost) return { ok: false, error: 'اكتب عنوان طابعة الشبكة في الإعدادات.' };
    return printing.sendTcp(local.escposHost, local.escposPort, printing.escposRaster(Buffer.from(bits), width, height));
  });

  ipcMain.handle('shell:openWa', (e, url) => {
    if (typeof url !== 'string' || !/^https:\/\/wa\.me\/\d{6,15}\?text=/.test(url)) return false;
    shell.openExternal(url); return true;
  });
  ipcMain.handle('clip:write', (e, text) => { clipboard.writeText(String(text)); return true; });
  ipcMain.handle('theme:set', (e, mode) => { nativeTheme.themeSource = mode === 'light' || mode === 'dark' ? mode : 'system'; return true; });

  ipcMain.on('bt:select', (e, id) => { if (btCallback) { const cb = btCallback; btCallback = null; cb(String(id || '')); } });
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  Menu.setApplicationMenu(null);
  app.whenReady().then(() => {
    lockDownSession();
    registerIpc();
    createWindow();
    // نسخة احتياطية تلقائية: عند التشغيل ثم كل نصف ساعة (مرة واحدة في اليوم)
    setTimeout(() => runAutoBackup(false), 20000);
    setInterval(() => runAutoBackup(false), 30 * 60 * 1000);
  });
  app.on('before-quit', () => runAutoBackup(false));
  app.on('window-all-closed', () => app.quit());
}
