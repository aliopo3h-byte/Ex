'use strict';
/* التخزين: ملف JSON واحد بكتابة ذرّية.
   لماذا JSON وليس SQLite؟ صيغة النسخة الاحتياطية JSON أصلاً (توافق مع الهاتف)، ولا وحدات أصلية تحتاج إعادة بناء لكل إصدار Electron،
   وحجم 5,000 عميل و20,000 مستحق نحو 3 ميغابايت يُكتب في أجزاء من الثانية.
   الكتابة: ملف مؤقت ← fsync ← إعادة تسمية فوق الأصلي، فلا يبقى الملف نصف مكتوب عند انقطاع الكهرباء.
   ونحتفظ بنسخة .bak من آخر تشغيل ناجح للرجوع إليها إن تلف الملف الأساسي. */
const fs = require('fs');
const path = require('path');

function writeAtomicSync(file, data) {
  const tmp = file + '.tmp';
  const fd = fs.openSync(tmp, 'w');
  try { fs.writeSync(fd, data); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  let lastErr = null;
  // على Windows قد يقفل مضاد الفيروسات الملف لحظياً؛ نعيد المحاولة
  for (let i = 0; i < 6; i++) {
    try { fs.renameSync(tmp, file); return; } catch (e) { lastErr = e; if (e.code !== 'EPERM' && e.code !== 'EBUSY' && e.code !== 'EACCES') break; sleep(40 * (i + 1)); }
  }
  throw lastErr;
}
function sleep(ms) { const end = Date.now() + ms; while (Date.now() < end) { /* انتظار قصير متزامن */ } }

function errText(e) {
  const c = e && e.code;
  if (c === 'ENOSPC') return 'القرص ممتلئ. أفرغ مساحة ثم حاول مجدداً.';
  if (c === 'EACCES' || c === 'EPERM') return 'لا توجد صلاحية للكتابة في هذا المجلد.';
  if (c === 'EROFS') return 'القرص للقراءة فقط.';
  if (c === 'ENOENT') return 'المجلد أو الملف غير موجود.';
  return 'تعذّر الحفظ: ' + (e && e.message ? e.message : String(e));
}

class Store {
  constructor(dir) {
    this.dir = dir;
    fs.mkdirSync(dir, { recursive: true });
    this.file = path.join(dir, 'ledger.json');
    this.bak = path.join(dir, 'ledger.json.bak');
    this.localFile = path.join(dir, 'settings.json');
    this.lastJson = null;
  }
  // يعيد { db, recovered, error }
  load() {
    const tryRead = (f) => { try { if (!fs.existsSync(f)) return null; const o = JSON.parse(fs.readFileSync(f, 'utf8')); return o && typeof o === 'object' ? o : null; } catch (e) { return undefined; } };
    const main = tryRead(this.file);
    if (main) { this.lastJson = JSON.stringify(main); try { fs.copyFileSync(this.file, this.bak); } catch (e) { /* ليست حرجة */ } return { db: main, recovered: false }; }
    const bak = tryRead(this.bak);
    if (main === undefined) {
      // الملف الأساسي تالف: نحتفظ به للتحليل ونرجع للنسخة السابقة
      try { fs.copyFileSync(this.file, this.file + '.corrupt-' + Date.now()); } catch (e) { /* */ }
      if (bak) { this.lastJson = JSON.stringify(bak); return { db: bak, recovered: true }; }
      return { db: null, recovered: false, error: 'ملف البيانات تالف ولا توجد نسخة سابقة. ابدأ من نسخة احتياطية.' };
    }
    if (bak) { this.lastJson = JSON.stringify(bak); return { db: bak, recovered: true }; }
    return { db: null, recovered: false };
  }
  save(json) {
    if (typeof json !== 'string' || json.length < 2) throw new Error('بيانات غير صالحة');
    writeAtomicSync(this.file, json);
    this.lastJson = json;
  }
  loadLocal() {
    try { return Object.assign(defaultsLocal(), JSON.parse(fs.readFileSync(this.localFile, 'utf8'))); } catch (e) { return defaultsLocal(); }
  }
  saveLocal(obj) { writeAtomicSync(this.localFile, JSON.stringify(Object.assign(defaultsLocal(), obj), null, 2)); }
}
function defaultsLocal() {
  return { backupDir: '', lastAutoBackup: '', printerName: '', paper: 'roll', autoPrint: false, btDensity: 'normal', escposHost: '', escposPort: 9100, printVia: 'windows', winBounds: null };
}

const AUTO_RE = /^ledger-auto-(\d{4}-\d{2}-\d{2})\.json$/;
// نسخة احتياطية يومية: ملف واحد لكل يوم، ويبقى آخر 14
function autoBackup(dir, json, dateIso, keep = 14) {
  if (!dir || !json) return { done: false };
  fs.mkdirSync(dir, { recursive: true });
  const name = 'ledger-auto-' + dateIso + '.json';
  const wrapped = '{"app":"ledger","v":1,"at":' + JSON.stringify(new Date().toISOString()) + ',"db":' + json + '}';
  writeAtomicSync(path.join(dir, name), wrapped);
  const files = fs.readdirSync(dir).filter((f) => AUTO_RE.test(f)).sort();
  const removed = [];
  while (files.length > keep) { const f = files.shift(); try { fs.unlinkSync(path.join(dir, f)); removed.push(f); } catch (e) { /* */ } }
  return { done: true, file: name, removed };
}

module.exports = { Store, writeAtomicSync, autoBackup, errText, defaultsLocal };
