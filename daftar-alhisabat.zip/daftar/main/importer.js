'use strict';
const fs = require('fs');
const path = require('path');
const { readXlsx } = require('./xlsx');
const Core = require('../shared/core');

function decodeText(buf) {
  // UTF-8 مع BOM أو بدونه؛ وUTF-16 (يصدّره Excel أحياناً كـ«نص يونيكود»)
  if (buf[0] === 0xFF && buf[1] === 0xFE) return buf.slice(2).toString('utf16le');
  if (buf[0] === 0xFE && buf[1] === 0xFF) { const b = Buffer.from(buf.slice(2)); b.swap16(); return b.toString('utf16le'); }
  return buf.toString('utf8').replace(/^\uFEFF/, '');
}

async function readTable(file) {
  const ext = path.extname(file).toLowerCase();
  if (!['.csv', '.txt', '.tsv', '.xlsx', '.xlsm', '.xls'].includes(ext)) throw new Error('نوع الملف غير مدعوم. استعمل xlsx أو xls أو csv.');
  let buf;
  try { buf = await fs.promises.readFile(file); } catch (e) { throw new Error('تعذّرت قراءة الملف. تأكد أنه غير مفتوح في برنامج آخر.'); }
  if (ext === '.csv' || ext === '.txt' || ext === '.tsv') return Core.cleanRows(Core.parseCsv(decodeText(buf)));
  if (ext === '.xlsx' || ext === '.xlsm') {
    try { return Core.cleanRows(readXlsx(buf)); } catch (e) { throw new Error('ملف Excel تالف أو بصيغة غير مدعومة.'); }
  }
  if (ext === '.xls') {
    // صيغة Excel القديمة (BIFF) تحتاج مكتبة SheetJS الاختيارية
    let XLSX = null;
    try { XLSX = require('xlsx'); } catch (e) { throw new Error('صيغة .xls القديمة غير مدعومة في هذه النسخة. افتح الملف في Excel واحفظه بصيغة .xlsx أو CSV.'); }
    try {
      const wb = XLSX.read(buf, { type: 'buffer' });
      return Core.cleanRows(XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: false, defval: '' }));
    } catch (e) { throw new Error('تعذّرت قراءة ملف Excel.'); }
  }
}

module.exports = { readTable, decodeText };
